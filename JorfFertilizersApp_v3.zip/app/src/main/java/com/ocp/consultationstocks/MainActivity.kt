package com.ocp.consultationstocks

import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val Navy = Color(0xFF12395F)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val Border = Color(0xFFD5E5E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { JorfTheme { JorfHome() } }
    }
}

@Composable
private fun JorfTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Color.White,
            surface = Color.White,
            onSurface = TextDark
        ),
        content = content
    )
}

@Composable
private fun JorfHome() {
    var stockSearch by remember { mutableStateOf("") }
    var movementSearch by remember { mutableStateOf("") }
    var organisationSearch by remember { mutableStateOf("") }
    var stockResult by remember { mutableStateOf<String?>(null) }
    var movementResult by remember { mutableStateOf<String?>(null) }
    var organisationResult by remember { mutableStateOf<String?>(null) }
    var stockError by remember { mutableStateOf<String?>(null) }
    var movementError by remember { mutableStateOf<String?>(null) }

    fun filterCode(input: String): String {
        val filtered = input.filter { it.isDigit() || it == '.' }.take(11)
        return if (filtered.count { it == '.' } <= 1) filtered else filtered.dropLast(1)
    }

    fun searchCode(value: String, movement: Boolean) {
        val v = value.trim()
        val error = when {
            v.isEmpty() -> "Saisissez un code SAP ou un code OCP."
            v.length > 11 -> "Maximum 11 caractères."
            v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
            !v.all { it.isDigit() || it == '.' } -> "Chiffres uniquement et un seul point (.)."
            else -> null
        }
        if (movement) movementError = error else stockError = error
        if (error == null) {
            if (movement) movementResult = "Recherche mouvement matière : $v"
            else stockResult = "Recherche stock : $v"
        } else {
            if (movement) movementResult = null else stockResult = null
        }
    }

    Surface(Modifier.fillMaxSize(), color = Color.White) {
        Column(Modifier.fillMaxSize()) {
            Header()

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(12.dp))
                WelcomeBanner()
                Spacer(Modifier.height(14.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SummaryCard(
                        title = "Nombre d’articles",
                        value = "—",
                        subtitle = "Articles en stock",
                        accent = Green,
                        icon = Icons.Default.Inventory2,
                        modifier = Modifier.weight(1f)
                    )
                    SummaryCard(
                        title = "Valeur de stock global",
                        value = "—",
                        subtitle = "MAD",
                        accent = Blue,
                        icon = Icons.Default.Storage,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(14.dp))

                SearchModule(
                    title = "Synthèse des stocks",
                    description = "Consultez la synthèse de vos stocks et recherchez un article par code SAP ou code OCP.",
                    icon = Icons.Default.Inventory2,
                    accent = Green,
                    background = GreenSoft,
                    value = stockSearch,
                    onValueChange = { stockSearch = filterCode(it); stockError = null; stockResult = null },
                    onSearch = { searchCode(stockSearch, false) },
                    error = stockError,
                    result = stockResult
                )

                Spacer(Modifier.height(12.dp))

                SearchModule(
                    title = "Mouvement matière",
                    description = "Consultez et recherchez les mouvements : entrée, sortie, transfert, migration.",
                    icon = Icons.Default.SwapHoriz,
                    accent = Blue,
                    background = BlueSoft,
                    value = movementSearch,
                    onValueChange = { movementSearch = filterCode(it); movementError = null; movementResult = null },
                    onSearch = { searchCode(movementSearch, true) },
                    error = movementError,
                    result = movementResult
                )

                Spacer(Modifier.height(12.dp))

                SearchModule(
                    title = "Article d’organisation",
                    description = "Recherchez un article par code ou par désignation.",
                    icon = Icons.Default.Business,
                    accent = Purple,
                    background = PurpleSoft,
                    value = organisationSearch,
                    onValueChange = { organisationSearch = it; organisationResult = null },
                    onSearch = {
                        organisationResult = if (organisationSearch.trim().isEmpty())
                            "Saisissez un code ou une désignation."
                        else "Recherche article d’organisation : ${organisationSearch.trim()}"
                    },
                    error = null,
                    result = organisationResult,
                    organisation = true
                )

                Spacer(Modifier.height(8.dp))
                Text(
                    "Word with love ♥",
                    Modifier.fillMaxWidth(),
                    color = GreenDark,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
            }

            BottomNavigationBar()
        }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(GreenSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Eco, null, tint = Green, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("JORF FERTILIZERS COMPANY I", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("MobiStock", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("Gestion des stocks & mouvements", fontSize = 13.sp, color = Grey)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = GreenDark) }
        IconButton(onClick = {}) { Icon(Icons.Default.Menu, null, tint = GreenDark) }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(0.dp, 0.dp, 22.dp, 22.dp))
            .background(
                Brush.horizontalGradient(listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD)))
            )
    ) {
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .size(210.dp)
                .clip(RoundedCornerShape(90.dp, 0.dp, 0.dp, 90.dp))
                .background(Color(0x220B9F55))
        )
        Column(Modifier.padding(start = 22.dp, top = 22.dp, end = 170.dp)) {
            Text("Bonjour,", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("Bienvenue sur MobiStock", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(Modifier.height(5.dp))
            Text("Consultez et gérez vos stocks et mouvements en temps réel.", fontSize = 13.sp, color = Grey)
        }
        Icon(
            Icons.Default.Business,
            null,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 35.dp).size(90.dp),
            tint = Color(0x6675A98A)
        )
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier
) {
    Card(
        modifier = modifier.height(132.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(RoundedCornerShape(29.dp)).background(accent),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(5.dp))
                Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Text(subtitle, fontSize = 11.sp, color = Grey)
            }
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    background: Color,
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    error: String?,
    result: String?,
    organisation: Boolean = false
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = background),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .25f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(58.dp).clip(RoundedCornerShape(29.dp)).background(accent),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(31.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = accent)
                    Spacer(Modifier.height(3.dp))
                    Text(description, fontSize = 12.sp, color = Grey)
                }
                Icon(Icons.Default.ArrowForwardIos, null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f).height(56.dp),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    placeholder = { Text(if (organisation) "Code article ou Désignation" else "Code SAP ou Code OCP", color = Grey) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Grey) },
                    keyboardOptions = KeyboardOptions(keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.height(56.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(7.dp))
                    Text("Rechercher", fontWeight = FontWeight.Bold)
                }
            }
            if (!organisation) {
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, null, tint = Grey, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Code numérique  •  1 seul point (.)  •  Maximum 11 caractères", fontSize = 10.sp, color = Grey)
                }
            }
            error?.let {
                Spacer(Modifier.height(5.dp))
                Text(it, fontSize = 11.sp, color = Color(0xFFB3261E), fontWeight = FontWeight.Medium)
            }
            result?.let {
                Spacer(Modifier.height(7.dp))
                Surface(shape = RoundedCornerShape(10.dp), color = Color.White.copy(alpha = .75f)) {
                    Text(it, Modifier.fillMaxWidth().padding(9.dp), fontSize = 11.sp, color = TextDark)
                }
            }
        }
    }
}

@Composable
private fun BottomNavigationBar() {
    Surface(Modifier.fillMaxWidth(), color = Color.White, shadowElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
            NavigationItem(Icons.Default.Home, "Accueil", true, Green)
            NavigationItem(Icons.Default.Settings, "Paramètres", false, Grey)
        }
    }
}

@Composable
private fun NavigationItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(130.dp)) {
        Icon(icon, null, tint = color, modifier = Modifier.size(27.dp))
        Text(label, fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, color = color)
        if (active) Spacer(Modifier.height(3.dp))
        if (active) Box(Modifier.width(110.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(color))
    }
}
