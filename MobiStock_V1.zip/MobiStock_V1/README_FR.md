# MobiStock 1.1

Application Android de consultation des stocks pour JORF FERTILIZERS COMPANY I.

## Connexion
- Supabase Data API
- Table `public.stock`
- Accès mobile en lecture seule via la clé publishable
- RLS SELECT activé sur `public.stock`

## Recherche
- Code SAP ou Code OCP pour la synthèse des stocks
- Données de stock lues directement depuis Supabase

## Build GitHub
Le workflow GitHub décompresse `MobiStock_V1.zip`, installe Java 17/Gradle 8.9 et génère l'APK debug.
