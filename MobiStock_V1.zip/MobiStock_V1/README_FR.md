# MobiStock V1

Application Android de consultation des stocks pour JORF FERTILIZERS COMPANY I.

## Installation
1. Créer un projet Supabase.
2. Ouvrir SQL Editor et exécuter `supabase/schema.sql`.
3. Importer les données dans les trois tables.
4. Construire l'application Android.
5. Dans **Paramètres**, saisir l'URL Supabase et la clé **anon/public**.

Ne jamais mettre une `service_role key` dans l'application Android.

## Fonctionnalités
- Dashboard : nombre d'articles et valeur globale.
- Synthèse des stocks : recherche SAP/OCP.
- Mouvement matière : recherche SAP/OCP.
- Article d'organisation : recherche code/désignation.
- Popups pour les erreurs et résultats.
- Footer : `Work with love ♥`.
