# MobiStock 1.2

Application Android de consultation des stocks pour JORF FERTILIZERS COMPANY I.

## Modules
- **Synthèse des stocks** : recherche par code SAP ou OCP, affichage détaillé (magasin, emplacement, quantité, prix, valeur, dates)
- **Mouvement matière** : historique des mouvements par code SAP / OCP
- **Article d'organisation** : recherche par code article ou désignation

## Connexion
- Supabase Data API
- Table `public.stock`
- Accès mobile en lecture seule via la clé publishable
- RLS SELECT activé sur `public.stock`

## Recherche
- Code SAP ou Code OCP pour la synthèse des stocks et les mouvements
- Message clair si aucun résultat : « Aucun stock disponible pour cet article »
- Données lues directement depuis Supabase (aucune donnée fictive)

## Build GitHub Actions
Le workflow utilise Java 17, Gradle 8.9 et `gradle :app:assembleDebug`.
