package com.ocp.consultationstocks

import android.content.Context
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

private val Green = Color(0xFF22C55E)
private val GreenDark = Color(0xFF16A34A)
private val Blue = Color(0xFF3B82F6)
private val Purple = Color(0xFFA855F7)
private val HeaderGreen = Color(0xFF15803D)
private val GreenSoft = Color(0xFF14532D)
private val BlueSoft = Color(0xFF1E3A5F)
private val PurpleSoft = Color(0xFF3B0764)

private data class MobiColors(
    val surfaceBg: Color,
    val cardSurface: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val fieldBg: Color,
    val isDark: Boolean
)

private val DarkColors = MobiColors(
    surfaceBg = Color(0xFF0B1220),
    cardSurface = Color(0xFF0F172A),
    textPrimary = Color.White,
    textSecondary = Color(0xFF94A3B8),
    textMuted = Color(0xFF64748B),
    border = Color(0xFF1E293B),
    fieldBg = Color(0xFF0F172A),
    isDark = true
)

private val LightColors = MobiColors(
    surfaceBg = Color(0xFFF8FAFC),
    cardSurface = Color.White,
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    textMuted = Color(0xFF94A3B8),
    border = Color(0xFFE2E8F0),
    fieldBg = Color(0xFFF1F5F9),
    isDark = false
)

private val LocalMobiColors = staticCompositionLocalOf { DarkColors }

private val PrefsName = "mobistock_prefs"
private val PrefDark = "dark_theme"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        val initialDark = prefs.getBoolean(PrefDark, true)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent {
            var isDark by remember { mutableStateOf(initialDark) }
            MobiTheme(isDark) {
                App(
                    isDark = isDark,
                    onThemeChange = { dark ->
                        isDark = dark
                        prefs.edit().putBoolean(PrefDark, dark).apply()
                    }
                )
            }
        }
    }
}

@Composable
private fun MobiTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    CompositionLocalProvider(LocalMobiColors provides colors) {
        MaterialTheme(
            colorScheme = if (darkTheme) darkColorScheme(
                primary = Green,
                background = colors.surfaceBg,
                surface = colors.cardSurface,
                onSurface = colors.textPrimary,
                onPrimary = Color.White
            ) else lightColorScheme(
                primary = Green,
                background = colors.surfaceBg,
                surface = colors.cardSurface,
                onSurface = colors.textPrimary,
                onPrimary = Color.White
            ),
            content = content
        )
    }
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val division: String, val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)

private data class MovementRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val magasin: String,
    val quantite: String,
    val unite: String,
    val montant: String,
    val codeMouvement: String,
    val ordre: String,
    val reservation: String,
    val po: String,
    val docArticle: String,
    val date: String
)

private data class OrgRow(
    val code: String, val designation: String, val unite: String,
    val groupe: String, val organisation: String
)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path: String, query: String): String {
        val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("apikey", key)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
        return body
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,division,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }

    suspend fun movements(code: String): List<MovementRow> = withContext(Dispatchers.IO) {
        // Mb51: code_sap = integer, code_ocp = float
        // PostgREST: filtre simple = "code_ocp=eq.VALUE" (PAS "code_ocp.eq.VALUE")
        //             filtre or    = "or=(code_sap.eq.VALUE,code_ocp.eq.VALUE)"
        val trimmed = code.trim()
        val q = if (trimmed.contains('.')) {
            "code_ocp=eq.${enc(trimmed)}&select=*&limit=200"
        } else {
            "or=(code_sap.eq.${enc(trimmed)},code_ocp.eq.${enc(trimmed)})&select=*&limit=200"
        }
        parseMovements(get("Mb51", q))
    }

    suspend fun organizations(search: String): List<OrgRow> = withContext(Dispatchers.IO) {
        val s = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation&or=(code_article.ilike.*$s*,designation.ilike.*$s*)&limit=100"
        parseOrg(get("articles_organisation", q))
    }

    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }

    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) {
            for (i in 0 until page.length()) {
                page.getJSONObject(i).optString("code_sap").trim()
                    .takeIf { it.isNotEmpty() }?.let(codes::add)
            }
        }
        codes.size
    }

    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        var total = BigDecimal.ZERO
        for (page in pagedValues("valeur_stock")) {
            for (i in 0 until page.length()) {
                total = total.add(
                    page.getJSONObject(i).optString("valeur_stock", "0")
                        .toBigDecimalOrNull() ?: BigDecimal.ZERO
                )
            }
        }
        formatMoney(total)
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun parseStocks(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            StockRow(
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("magasin"), o.optString("division"), o.optString("bin"), o.optString("quantite"),
                o.optString("unite"), o.optString("prix_unitaire"), o.optString("valeur_stock"),
                o.optString("devise"), o.optString("date_em"), o.optString("derniere_sortie")
            )
        }
    }

    private fun parseMovements(s: String) = JSONArray(s).let { a ->
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            fun str(vararg keys: String): String {
                for (k in keys) {
                    if (o.has(k) && !o.isNull(k)) {
                        val v = o.opt(k)?.toString()?.trim().orEmpty()
                        if (v.isNotEmpty() && v != "null") return v
                    }
                }
                return ""
            }
            MovementRow(
                sap = str("code_sap", "Code SAP", "codeSAP", "matnr", "Material"),
                ocp = str("code_ocp", "Code OCP", "codeOCP", "ocp"),
                designation = str("designation", "Designation", "maktx", "Material Description"),
                magasin = str("magasin", "Magasin", "lgort", "Storage Location", "storage_location"),
                quantite = str("quantite", "Quantite", "quantity", "menge", "qty"),
                unite = str("unite", "Unite", "meins", "unit", "uom"),
                montant = str("montant_di", "montant", "Montant", "dmbtr", "amount", "valeur", "amount_lc"),
                codeMouvement = str("code_mouvement", "Code mouvement", "bwart", "movement_type", "type_mouvement"),
                ordre = str("ordre", "Ordre", "aufnr", "order", "order_number"),
                reservation = str("reservation", "Reservation", "rsnum", "réservation"),
                po = str("po", "PO", "ebeln", "purchase_order", "commande"),
                docArticle = str("doc_article", "Doc article", "mblnr", "material_document", "numero_document", "doc"),
                date = str("date", "Date", "budat", "date_mouvement", "posting_date")
            )
        }
    }

    private fun parseOrg(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            OrgRow(
                o.optString("code_article"), o.optString("designation"),
                o.optString("unite"), o.optString("groupe"), o.optString("organisation")
            )
        }
    }
}

private fun formatMoney(value: BigDecimal): String =
    NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
        isGroupingUsed = true
    }.format(value)

private fun formatMoney(raw: String, currency: String): String =
    "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"

private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 3
        isGroupingUsed = true
    }.format(n)
}

private fun dash(s: String): String = if (s.isBlank()) "—" else s

private fun formatCodeNum(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return d.stripTrailingZeros().toPlainString()
}

/** Code OCP : toujours 5 décimales (ex. 10073.00500) */
private fun formatOcp(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return d.setScale(5, java.math.RoundingMode.HALF_UP).toPlainString()
}

/** Code SAP : entier si possible */
private fun formatSap(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return if (d.stripTrailingZeros().scale() <= 0)
        d.toBigInteger().toString()
    else
        d.stripTrailingZeros().toPlainString()
}

private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 ->
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10)
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else
            SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) {
        raw
    }
}

@Composable
private fun App(
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    val c = LocalMobiColors.current
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }
    var movementRows by remember { mutableStateOf<List<MovementRow>?>(null) }
    var subScreen by remember { mutableStateOf<String?>(null) }

    // Stats globales — chargées UNE SEULE FOIS pour toute la session
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    var statsLoaded by remember { mutableStateOf(false) }
    var statsLoading by remember { mutableStateOf(false) }
    var statsError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (!statsLoaded) {
            statsLoading = true
            runCatching {
                articleCount = api.articleCount().toString()
                stockValue = api.stockValue()
                statsLoaded = true
            }.onFailure { statsError = it.message }
            statsLoading = false
        }
    }

    if (stockRows != null) {
        StockResultPage(
            rows = stockRows!!,
            onBack = { stockRows = null },
            onHome = { stockRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (movementRows != null) {
        MovementResultPage(
            rows = movementRows!!,
            onBack = { movementRows = null },
            onHome = { movementRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "movement") {
        MovementSearchPage(
            api = api,
            onBack = { subScreen = null },
            onResult = { movementRows = it }
        )
        return
    }
    if (subScreen == "org") {
        OrgSearchPage(
            api = api,
            onBack = { subScreen = null }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        if (page == 1) {
            SettingsPage(api, isDark = isDark, onThemeChange = onThemeChange)
        } else {
            HomePage(
                api = api,
                articleCount = articleCount,
                stockValue = stockValue,
                statsLoading = statsLoading,
                onStockResult = { stockRows = it },
                onOpenMovement = { subScreen = "movement" },
                onOpenOrg = { subScreen = "org" }
            )
        }
        BottomNavigationBar(
            page = page,
            onPage = { page = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    statsError?.let { msg ->
        AppDialog(msg) { statsError = null }
    }
}

@Composable
private fun HomePage(
    api: SupabaseClient,
    articleCount: String,
    stockValue: String,
    statsLoading: Boolean,
    onStockResult: (List<StockRow>) -> Unit,
    onOpenMovement: () -> Unit,
    onOpenOrg: () -> Unit
) {
    var stock by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Surface(modifier = Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Header()
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SummaryCard(
                            title = "Nombre d'articles",
                            value = articleCount,
                            subtitle = "Articles en stock",
                            accent = Green,
                            icon = Icons.Default.Inventory2,
                            modifier = Modifier.weight(1f)
                        )
                        SummaryCard(
                            title = "Valeur de stock",
                            value = stockValue,
                            subtitle = "MAD",
                            accent = Blue,
                            icon = Icons.Default.AccountBalance,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    StockSearchBlock(
                        value = stock,
                        onValueChange = { stock = codeFilter(it) },
                        onSearch = {
                            keyboard?.hide()
                            val e = validate(stock)
                            if (e != null) dialog = e
                            else scope.launch {
                                loading = true
                                runCatching { api.stocks(stock.trim()) }
                                    .onSuccess { r ->
                                        if (r.isEmpty())
                                            dialog = "Aucun stock disponible pour cet article"
                                        else onStockResult(r)
                                    }
                                    .onFailure { dialog = it.message }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(20.dp))
                }
                item {
                    ModuleNavButton(
                        title = "Mouvement matière",
                        subtitle = "Historique des mouvements",
                        emoji = "🔄",
                        accent = Blue,
                        background = BlueSoft,
                        onClick = onOpenMovement
                    )
                    Spacer(Modifier.height(12.dp))
                }
                item {
                    ModuleNavButton(
                        title = "Article d'organisation",
                        subtitle = "Recherche par code ou désignation",
                        emoji = "🏢",
                        accent = Purple,
                        background = PurpleSoft,
                        onClick = onOpenOrg
                    )
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    Text(
                        "Work with love",
                        Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        color = LocalMobiColors.current.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Overlay uniquement pour les recherches, PAS pour les stats (déjà en cache)
    LoadingOverlay(loading)
    // Petit indicateur discret si stats encore en cours au 1er lancement
    if (statsLoading && !loading) {
        Box(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            contentAlignment = Alignment.Center
        ) { /* stats en arrière-plan, pas de popup bloquant */ }
    }
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun StockSearchBlock(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Green),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📦", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Synthèse des stocks",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary
                    )
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    placeholder = {
                        Text(
                            "Saisir Code SAP ou Code OCP",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.surfaceBg,
                        unfocusedContainerColor = LocalMobiColors.current.surfaceBg,
                        cursorColor = Green,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onSearch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    elevation = ButtonDefaults.buttonElevation(0.dp)
                ) {
                    Text("🔍", fontSize = 15.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "RECHERCHER",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Rechercher un article par son Code SAP ou son Code OCP.",
                    fontSize = 12.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Green)
            )
        }
    }
}

@Composable
private fun ModuleNavButton(
    title: String,
    subtitle: String,
    emoji: String,
    accent: Color,
    background: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(emoji, fontSize = 18.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title.uppercase(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        subtitle,
                        fontSize = 12.sp,
                        color = LocalMobiColors.current.textSecondary
                    )
                }
                Text("→", fontSize = 18.sp, color = Green, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accent)
            )
        }
    }
}

@Composable
private fun MovementSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit,
    onResult: (List<MovementRow>) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }
    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    fun doSearch() {
        keyboard?.hide()
        val e = validate(code)
        if (e != null) dialog = e
        else scope.launch {
            loading = true
            runCatching { api.movements(code.trim()) }
                .onSuccess { r ->
                    if (r.isEmpty()) dialog = "Aucun mouvement trouvé pour cet article."
                    else onResult(r)
                }
                .onFailure { dialog = it.message }
            loading = false
        }
    }

    Surface(Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvement matière",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Blue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🔄", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Mouvement matière",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Blue
                    )
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Saisir Code SAP ou Code OCP",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Rechercher les mouvements par Code SAP ou Code OCP.",
                    fontSize = 13.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun OrgSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit
) {
    var code by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun doSearch() {
        keyboard?.hide()
        val c = code.trim()
        val d = designation.trim()
        if (c.isBlank() && d.isBlank()) {
            dialog = "Veuillez saisir un code ou une désignation."
            return
        }
        scope.launch {
            loading = true
            runCatching {
                val results = mutableListOf<OrgRow>()
                val seen = mutableSetOf<String>()
                if (c.isNotBlank()) {
                    for (r in api.organizations(c)) {
                        if (seen.add(r.code)) results += r
                    }
                }
                if (d.isNotBlank()) {
                    for (r in api.organizations(d)) {
                        if (seen.add(r.code)) results += r
                    }
                }
                results
            }.onSuccess { r ->
                dialog = if (r.isEmpty())
                    "Aucun article d'organisation trouvé."
                else r.joinToString("\n\n") {
                    "Code: ${it.code}\n${it.designation}\nUnité: ${it.unite}\nGroupe: ${it.groupe}\nOrganisation: ${it.organisation}"
                }
            }.onFailure { dialog = it.message }
            loading = false
        }
    }

    Surface(Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Purple)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Article d'organisation",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Purple),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🏢", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Article d'organisation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple
                    )
                }
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. 10067.05422",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )

                Spacer(Modifier.height(14.dp))

                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. MANCHON COMPENSATEUR",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )

                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Saisir un code SAP/OCP et/ou une désignation.",
                    fontSize = 13.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun LoadingOverlay(loading: Boolean) {
    if (!loading) return
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Green, strokeWidth = 3.dp)
                Spacer(Modifier.height(12.dp))
                Text("Chargement…", color = LocalMobiColors.current.textPrimary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun AppDialog(msg: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        containerColor = LocalMobiColors.current.cardSurface,
        title = {
            Text(
                "MobiStock",
                fontWeight = FontWeight.Bold,
                color = Green,
                fontSize = 18.sp
            )
        },
        text = {
            Text(msg, color = LocalMobiColors.current.textPrimary, fontSize = 14.sp, lineHeight = 20.sp)
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("OK", fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
private fun StockResultPage(
    rows: List<StockRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.qty.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val totalValue = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.valeur.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val currency = first?.devise?.takeIf { it.isNotBlank() } ?: "MAD"
    val WaGreen = Green

    Surface(modifier = Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Détail du stock",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Code SAP : ${formatSap(first.sap)}",
                            fontSize = 14.sp,
                            color = LocalMobiColors.current.textPrimary,
                            lineHeight = 18.sp
                        )
                        Text(
                            "Code OCP : ${formatOcp(first.ocp)}",
                            fontSize = 14.sp,
                            color = LocalMobiColors.current.textPrimary,
                            lineHeight = 18.sp
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    StockDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item {
                    Spacer(Modifier.height(6.dp))
                    HorizontalDivider(color = LocalMobiColors.current.border, thickness = 1.dp)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📦", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "TOTAL EN STOCK : ${formatQty(totalQty.toPlainString())}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💰", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "VALEUR GLOBALE : ${formatMoney(totalValue)} $currency",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun StockDetailBlock(row: StockRow, showDivider: Boolean) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${dash(row.magasin)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
            if (row.division.isNotBlank()) {
                Spacer(Modifier.width(14.dp))
                Text("🏭", fontSize = 16.sp)
                Spacer(Modifier.width(4.dp))
                Text(
                    "OL : ${row.division}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalMobiColors.current.textPrimary
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📍", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "BIN : ${dash(row.emplacement)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
        }
        Spacer(Modifier.height(2.dp))
        val devise = row.devise.ifBlank { "MAD" }
        val qtyText = "Quantité : ${formatQty(row.qty)} ${row.unite}"
        val puText = "Prix unitaire : ${formatMoney(row.pu, devise)}"
        val valText = "Valeur : ${formatMoney(row.valeur, devise)}"
        val emText = "Date EM : ${formatDate(row.dateEm)}"
        val outText = "Dernière sortie : ${formatDate(row.derniereSortie)}"
        Text(qtyText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(puText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(valText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(emText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(outText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        if (showDivider) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = LocalMobiColors.current.border, thickness = 1.dp)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun StockCard(row: StockRow, index: Int) {
    StockDetailBlock(row, showDivider = false)
}

@Composable
private fun StockField(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, color = LocalMobiColors.current.textSecondary, modifier = Modifier.width(110.dp))
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = LocalMobiColors.current.textPrimary,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CodeChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "$label : ",
                fontSize = 11.sp,
                color = LocalMobiColors.current.textSecondary,
                fontWeight = FontWeight.Medium
            )
            Text(
                value.ifBlank { "—" },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
        }
    }
}

@Composable
private fun MovementResultPage(
    rows: List<MovementRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val c = LocalMobiColors.current

    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvements matière",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                // En-tête unique : désignation + SAP / OCP
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth()) {
                            Text(
                                "Code SAP : ${formatSap(first.sap)}",
                                fontSize = 14.sp,
                                color = c.textPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                "Code OCP : ${formatOcp(first.ocp)}",
                                fontSize = 14.sp,
                                color = c.textPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = c.border, thickness = 1.dp)
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    MovementDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun MovementDetailBlock(row: MovementRow, showDivider: Boolean) {
    val c = LocalMobiColors.current
    val qtyNum = row.quantite.replace(" ", "").replace(",", ".").toBigDecimalOrNull()
    val isPositive = qtyNum != null && qtyNum > java.math.BigDecimal.ZERO
    val accent = if (isPositive) Blue else c.textPrimary
    val qtyLabel = buildString {
        append(formatQty(row.quantite))
        if (row.unite.isNotBlank()) {
            append(' ')
            append(row.unite)
        }
    }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${dash(row.magasin)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = accent,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Quantité : ${dash(qtyLabel)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = accent
            )
        }
        Spacer(Modifier.height(4.dp))
        val montantText = when {
            row.montant.isBlank() -> "—"
            row.montant.toBigDecimalOrNull() != null -> formatMoney(row.montant.toBigDecimal())
            else -> row.montant
        }
        Text(
            "Montant : $montantText",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Text(
            "Code mouvement : ${dash(row.codeMouvement)}",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                "Ordre : ${dash(row.ordre)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Réservation : ${dash(row.reservation)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
        }
        Text(
            "PO : ${dash(row.po)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Text(
            "Doc article : ${dash(row.docArticle)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Text(
            "Date : ${formatDate(row.date)}",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        if (showDivider) {
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = c.border, thickness = 1.dp)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SummaryLine(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = LocalMobiColors.current.textSecondary, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
    }
}

@Composable
private fun Header() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(HeaderGreen)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "JORF FERTILIZERS COMPANY I",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.5.sp
            )
            Text(
                "MobiStock",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD))
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Bonjour,",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GreenDark
                )
                Text(
                    "Bienvenue sur MobiStock",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalMobiColors.current.textPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Consultez et gérez vos stocks et mouvements en temps réel.",
                    fontSize = 11.sp,
                    color = LocalMobiColors.current.textSecondary,
                    lineHeight = 15.sp
                )
            }
            Icon(
                Icons.Default.Business,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color(0x6675A98A)
            )
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LocalMobiColors.current.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        value,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        subtitle,
                        fontSize = 10.sp,
                        color = LocalMobiColors.current.textMuted
                    )
                }
            }
            // bande colorée en bas
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accent)
            )
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    subtitle: String,
    accent: Color,
    background: Color,
    icon: ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    organisation: Boolean,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                    Text(
                        subtitle,
                        fontSize = 11.sp,
                        color = LocalMobiColors.current.textSecondary
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            placeholder,
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = LocalMobiColors.current.textPrimary
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = accent
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Rechercher",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(
    api: SupabaseClient,
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit
) {
    val c = LocalMobiColors.current
    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .padding(top = 24.dp, bottom = 80.dp)
        ) {
            Text(
                "Paramètres",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary
            )
            Spacer(Modifier.height(24.dp))
            Text(
                "Apparence",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.textSecondary
            )
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(c.cardSurface),
                border = BorderStroke(1.dp, c.border)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Mode sombre",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.textPrimary
                            )
                            Text(
                                "Fond sombre, texte clair",
                                fontSize = 12.sp,
                                color = c.textSecondary
                            )
                        }
                        Switch(
                            checked = isDark,
                            onCheckedChange = { onThemeChange(true) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                    HorizontalDivider(color = c.border, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Mode clair",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.textPrimary
                            )
                            Text(
                                "Fond clair, texte sombre",
                                fontSize = 12.sp,
                                color = c.textSecondary
                            )
                        }
                        Switch(
                            checked = !isDark,
                            onCheckedChange = { onThemeChange(false) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("MobiStock 1.2", color = c.textSecondary, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text("JORF FERTILIZERS COMPANY I", color = c.textSecondary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BottomNavigationBar(
    page: Int,
    onPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = LocalMobiColors.current.cardSurface,
        shadowElevation = 8.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            NavigationItem(
                icon = Icons.Default.Home,
                label = "Accueil",
                active = page == 0,
                onClick = { onPage(0) }
            )
            NavigationItem(
                icon = Icons.Default.Settings,
                label = "Paramètres",
                active = page == 1,
                onClick = { onPage(1) }
            )
        }
    }
}

@Composable
private fun NavigationItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val color = if (active) Green else LocalMobiColors.current.textMuted
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(120.dp)
            .padding(vertical = 2.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(24.dp))
        }
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = color
        )
        Spacer(Modifier.height(3.dp))
        Box(
            Modifier
                .width(if (active) 28.dp else 0.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(if (active) Green else Color.Transparent)
        )
    }
}
