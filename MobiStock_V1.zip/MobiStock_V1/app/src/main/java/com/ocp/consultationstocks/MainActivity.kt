package com.ocp.consultationstocks

import android.content.Context
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

// ---------- Design tokens ----------
private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF076B49)
private val GreenDeep = Color(0xFF054A34)
private val GreenSoft = Color(0xFFE7F7EF)
private val GreenSurface = Color(0xFFF4FBF8)
private val Blue = Color(0xFF1487E3)
private val BlueSoft = Color(0xFFE9F4FE)
private val Purple = Color(0xFF7B3FD1)
private val PurpleSoft = Color(0xFFF3EDFC)
private val TextDark = Color(0xFF0D271F)
private val TextMuted = Color(0xFF5E7369)
private val Outline = Color(0xFFDCE8E2)
private val PageBg = Color(0xFFF6FAF8)

private val MobiTypography = Typography(
    headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp, color = TextDark),
    titleLarge = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextDark),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextDark),
    titleSmall = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp, color = TextDark),
    bodyLarge = TextStyle(fontSize = 15.sp, color = TextDark),
    bodyMedium = TextStyle(fontSize = 13.sp, color = TextDark),
    bodySmall = TextStyle(fontSize = 12.sp, color = TextMuted),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextDark),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, color = TextMuted)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(5, 74, 52)
        setContent { MobiTheme { App() } }
    }
}

@Composable
private fun MobiTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Green, onPrimary = Color.White,
        primaryContainer = GreenSoft, onPrimaryContainer = GreenDeep,
        secondary = Blue, secondaryContainer = BlueSoft,
        tertiary = Purple, tertiaryContainer = PurpleSoft,
        background = PageBg, surface = Color.White,
        surfaceVariant = GreenSurface, onSurface = TextDark, onSurfaceVariant = TextMuted,
        outline = Outline, error = Color(0xFFD1483F)
    )
    val shapes = Shapes(
        extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(28.dp)
    )
    MaterialTheme(colorScheme = colors, typography = MobiTypography, shapes = shapes, content = content)
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)
private data class MovementRow(val date: String, val type: String, val sap: String, val ocp: String, val designation: String, val qty: String, val unite: String, val source: String, val destination: String, val doc: String, val valeur: String)
private data class OrgRow(val code: String, val designation: String, val unite: String, val groupe: String, val organisation: String)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path: String, query: String): String {
        val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("apikey", key)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
        return body
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }
    suspend fun movements(code: String): List<MovementRow> = withContext(Dispatchers.IO) {
        val q = "select=date_mouvement,type_mouvement,code_sap,code_ocp,designation,quantite,unite,magasin_source,magasin_destination,numero_document,valeur&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&order=date_mouvement.desc&limit=100"
        parseMovements(get("mouvements", q))
    }
    suspend fun organizations(search: String): List<OrgRow> = withContext(Dispatchers.IO) {
        val s = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation&or=(code_article.ilike.*$s*,designation.ilike.*$s*)&limit=100"
        parseOrg(get("articles_organisation", q))
    }
    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }
    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) for (i in 0 until page.length()) page.getJSONObject(i).optString("code_sap").trim().takeIf { it.isNotEmpty() }?.let(codes::add)
        codes.size
    }
    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        var total = BigDecimal.ZERO
        for (page in pagedValues("valeur_stock")) for (i in 0 until page.length()) total = total.add(page.getJSONObject(i).optString("valeur_stock", "0").toBigDecimalOrNull() ?: BigDecimal.ZERO)
        formatMoney(total)
    }
    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")
    private fun parseStocks(s: String) = JSONArray(s).let { a -> List(a.length()) { i -> val o = a.getJSONObject(i); StockRow(o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"), o.optString("magasin"), o.optString("bin"), o.optString("quantite"), o.optString("unite"), o.optString("prix_unitaire"), o.optString("valeur_stock"), o.optString("devise"), o.optString("date_em"), o.optString("derniere_sortie")) } }
    private fun parseMovements(s: String) = JSONArray(s).let { a -> List(a.length()) { i -> val o = a.getJSONObject(i); MovementRow(o.optString("date_mouvement"), o.optString("type_mouvement"), o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"), o.optString("quantite"), o.optString("unite"), o.optString("magasin_source"), o.optString("magasin_destination"), o.optString("numero_document"), o.optString("valeur")) } }
    private fun parseOrg(s: String) = JSONArray(s).let { a -> List(a.length()) { i -> val o = a.getJSONObject(i); OrgRow(o.optString("code_article"), o.optString("designation"), o.optString("unite"), o.optString("groupe"), o.optString("organisation")) } }
}

private fun formatMoney(value: BigDecimal): String = NumberFormat.getNumberInstance(Locale.FRANCE).apply { minimumFractionDigits = 2; maximumFractionDigits = 2; isGroupingUsed = true }.format(value)
private fun formatMoney(raw: String, currency: String): String = "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"
private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply { minimumFractionDigits = 0; maximumFractionDigits = 3; isGroupingUsed = true }.format(n)
}
private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 -> SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10) SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) { raw }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }

    if (stockRows != null) {
        StockResultPage(rows = stockRows!!, onBack = { stockRows = null }, onHome = { stockRows = null; page = 0 })
        return
    }

    Scaffold(
        containerColor = PageBg,
        bottomBar = { BottomNavigationBar(page) { page = it } }
    ) { innerPadding ->
        Box(Modifier.padding(innerPadding).fillMaxSize()) {
            if (page == 1) SettingsPage(api) else HomePage(api, onStockResult = { stockRows = it })
        }
    }
}

@Composable
private fun HomePage(api: SupabaseClient, onStockResult: (List<StockRow>) -> Unit) {
    var stock by remember { mutableStateOf("") }
    var movement by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        loading = true
        runCatching {
            articleCount = api.articleCount().toString()
            stockValue = api.stockValue()
        }.onFailure { dialog = it.message }
        loading = false
    }

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }
        .let { if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11) }

    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(Color.White)) {
            Header()
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Spacer(Modifier.height(2.dp))
                WelcomeBanner()
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryCard("Articles", articleCount, "Références en stock", Green, Icons.Default.Inventory2, Modifier.weight(1f))
                    SummaryCard("Valeur globale", stockValue, "MAD", Blue, Icons.Default.Storage, Modifier.weight(1f))
                }
                Text(
                    "Modules de recherche",
                    style = MaterialTheme.typography.titleSmall.copy(color = TextMuted),
                    modifier = Modifier.padding(top = 4.dp)
                )
                SearchModule(
                    title = "Synthèse des stocks", subtitle = "Quantité, valeur et emplacement",
                    accent = Green, background = GreenSoft, value = stock,
                    onValueChange = { stock = codeFilter(it) },
                    onSearch = {
                        val e = validate(stock)
                        if (e != null) dialog = e else scope.launch {
                            loading = true
                            runCatching { api.stocks(stock.trim()) }
                                .onSuccess { r -> if (r.isEmpty()) dialog = "Aucun stock disponible pour cet article." else onStockResult(r) }
                                .onFailure { dialog = it.message }
                            loading = false
                        }
                    }
                )
                SearchModule(
                    title = "Mouvement matière", subtitle = "Historique des entrées / sorties",
                    accent = Blue, background = BlueSoft, value = movement,
                    onValueChange = { movement = codeFilter(it) },
                    onSearch = {
                        val e = validate(movement)
                        if (e != null) dialog = e else scope.launch {
                            loading = true
                            runCatching { api.movements(movement.trim()) }
                                .onSuccess { r ->
                                    dialog = if (r.isEmpty()) "Aucun mouvement trouvé pour cet article."
                                    else r.joinToString("\n\n") { "${it.date} — ${it.type}\nSAP: ${it.sap} / OCP: ${it.ocp}\n${it.designation}\nQté: ${it.qty} ${it.unite}\n${it.source} → ${it.destination}\nDoc: ${it.doc}\nValeur: ${it.valeur}" }
                                }
                                .onFailure { dialog = it.message }
                            loading = false
                        }
                    }
                )
                SearchModule(
                    title = "Article d’organisation", subtitle = "Recherche par code ou désignation",
                    accent = Purple, background = PurpleSoft, value = org,
                    onValueChange = { org = it },
                    onSearch = {
                        if (org.trim().isBlank()) dialog = "Veuillez saisir un code ou une désignation." else scope.launch {
                            loading = true
                            runCatching { api.organizations(org.trim()) }
                                .onSuccess { r ->
                                    dialog = if (r.isEmpty()) "Aucun article d’organisation trouvé."
                                    else r.joinToString("\n\n") { "Code: ${it.code}\n${it.designation}\nUnité: ${it.unite}\nGroupe: ${it.groupe}\nOrganisation: ${it.organisation}" }
                                }
                                .onFailure { dialog = it.message }
                            loading = false
                        }
                    },
                    organisation = true
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Work with love ♥",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    color = GreenDark,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    textAlign = TextAlign.Center
                )
            }
        }
        if (loading) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Green)
            }
        }
        dialog?.let { msg ->
            AlertDialog(
                onDismissRequest = { dialog = null },
                shape = RoundedCornerShape(20.dp),
                title = { Text("MobiStock", style = MaterialTheme.typography.titleMedium) },
                text = { Text(msg, style = MaterialTheme.typography.bodyMedium) },
                confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK", color = Green, fontWeight = FontWeight.Bold) } }
            )
        }
    }
}

@Composable private fun StockResultPage(rows: List<StockRow>, onBack: () -> Unit, onHome: () -> Unit) {
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO) { acc, r -> acc + (r.qty.toBigDecimalOrNull() ?: BigDecimal.ZERO) }
    val totalValue = rows.fold(BigDecimal.ZERO) { acc, r -> acc + (r.valeur.toBigDecimalOrNull() ?: BigDecimal.ZERO) }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            Surface(color = Green, shadowElevation = 4.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Retour", tint = Color.White, modifier = Modifier.size(26.dp)) }
                    Column(Modifier.weight(1f)) {
                        Text("Détail du stock", style = MaterialTheme.typography.titleLarge.copy(color = Color.White))
                        first?.let { Text(it.designation, style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f)), maxLines = 1) }
                    }
                    IconButton(onClick = onHome) { Icon(Icons.Default.Home, contentDescription = "Accueil", tint = Color.White, modifier = Modifier.size(24.dp)) }
                }
            }
        },
        bottomBar = {
            Surface(color = Color.White, shadowElevation = 8.dp) {
                Button(
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Retour à la recherche", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    first?.let {
                        Text(it.designation, style = MaterialTheme.typography.headlineSmall.copy(color = GreenDeep))
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CodeChip("SAP", it.sap)
                            CodeChip("OCP", it.ocp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("${rows.size} emplacement(s) trouvé(s)", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            items(rows) { row -> StockDetailBlock(row) }
            item { SummaryCalloutCard(formatQty(totalQty.toPlainString()), formatMoney(totalValue)) }
        }
    }
}

@Composable private fun CodeChip(label: String, value: String) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier.clip(RoundedCornerShape(50)).background(GreenSoft).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall.copy(color = GreenDark, fontWeight = FontWeight.Bold))
        Spacer(Modifier.width(4.dp))
        Text(value, style = MaterialTheme.typography.labelSmall.copy(color = TextDark))
    }
}

@Composable private fun StockDetailBlock(row: StockRow) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = GreenSurface),
        border = BorderStroke(1.dp, Outline)
    ) {
        Column(Modifier.padding(14.dp)) {
            DetailRow(Icons.Default.Store, "Magasin", row.magasin)
            DetailRow(Icons.Default.LocationOn, "Emplacement (bin)", row.emplacement)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Outline)
            DetailRow(Icons.Default.Inventory2, "Quantité", "${formatQty(row.qty)} ${row.unite}", emphasize = true)
            DetailRow(Icons.Default.AttachMoney, "Prix unitaire", formatMoney(row.pu, row.devise))
            DetailRow(Icons.Default.MonetizationOn, "Valeur", formatMoney(row.valeur, row.devise), emphasize = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Outline)
            DetailRow(Icons.Default.DateRange, "Date d’entrée", formatDate(row.dateEm))
            DetailRow(Icons.Default.ExitToApp, "Dernière sortie", formatDate(row.derniereSortie))
        }
    }
}

@Composable private fun DetailRow(icon: ImageVector, label: String, value: String, emphasize: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Text(
            value,
            style = if (emphasize) MaterialTheme.typography.titleSmall.copy(color = GreenDeep) else MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.End
        )
    }
}

@Composable private fun SummaryCalloutCard(totalQty: String, totalValue: String) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = GreenDeep)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryLine(Icons.Default.Inventory2, "Total en stock", totalQty)
            SummaryLine(Icons.Default.AttachMoney, "Valeur globale", "$totalValue MAD")
        }
    }
}

@Composable private fun SummaryLine(icon: ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(label.uppercase(), style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.75f)))
            Text(value, style = MaterialTheme.typography.titleLarge.copy(color = Color.White))
        }
    }
}

@Composable private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Green, GreenDark))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Eco, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("JORF FERTILIZERS COMPANY I", style = MaterialTheme.typography.labelSmall.copy(color = GreenDark, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp))
            Text("MobiStock", style = MaterialTheme.typography.headlineSmall.copy(color = GreenDeep))
            Text("Gestion des stocks & mouvements", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable private fun WelcomeBanner() {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFFEFFAF5), Color(0xFFDCF3E9), Color(0xFFC9EADA))))
    ) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp).fillMaxWidth(0.72f)) {
            Text("Bonjour 👋", style = MaterialTheme.typography.titleSmall.copy(color = GreenDark))
            Spacer(Modifier.height(2.dp))
            Text("Bienvenue sur MobiStock", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text("Consultez et gérez vos stocks et mouvements en temps réel.", style = MaterialTheme.typography.bodySmall)
        }
        Icon(
            Icons.Default.Business, contentDescription = null,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 20.dp).size(64.dp),
            tint = Color(0x552F6E52)
        )
    }
}

@Composable private fun SummaryCard(title: String, value: String, subtitle: String, accent: Color, icon: ImageVector, modifier: Modifier) {
    Card(
        modifier = modifier.fillMaxHeight(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.22f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.labelSmall)
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable private fun SearchModule(
    title: String, subtitle: String, accent: Color, background: Color, value: String,
    onValueChange: (String) -> Unit, onSearch: () -> Unit, organisation: Boolean = false
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = background),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(Modifier.padding(horizontal = 14.dp, vertical = 14.dp).fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (organisation) Icons.Default.Business else Icons.Default.Search,
                            contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(title, style = MaterialTheme.typography.titleSmall.copy(color = accent))
                        Text(subtitle, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier.weight(1f).height(52.dp),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        placeholder = {
                            Text(
                                if (organisation) "Code ou désignation" else "Code SAP / OCP",
                                color = TextMuted, style = MaterialTheme.typography.bodySmall
                            )
                        },
                        textStyle = MaterialTheme.typography.bodyMedium,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal,
                            imeAction = ImeAction.Search
                        ),
                        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accent, unfocusedBorderColor = Outline,
                            focusedContainerColor = Color.White, unfocusedContainerColor = Color.White
                        )
                    )
                    Button(
                        onClick = onSearch,
                        modifier = Modifier.height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = accent)
                    ) { Icon(Icons.Default.Search, contentDescription = "Rechercher", modifier = Modifier.size(18.dp)) }
                }
            }
        }
    }
}

@Composable private fun SettingsPage(api: SupabaseClient) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Paramètres", style = MaterialTheme.typography.headlineSmall.copy(color = GreenDeep))
        Spacer(Modifier.height(4.dp))
        Text("Connexion Supabase", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = GreenSoft),
            border = BorderStroke(1.dp, Green.copy(alpha = 0.2f))
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(Green))
                    Spacer(Modifier.width(8.dp))
                    Text("Supabase connecté", style = MaterialTheme.typography.titleSmall.copy(color = GreenDeep))
                }
                Spacer(Modifier.height(14.dp))
                SettingsField("Base de données", "kbztwijnoyifbmtoanps.supabase.co")
                Spacer(Modifier.height(10.dp))
                SettingsField("Accès", "Lecture seule des stocks")
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("MobiStock 1.1", style = MaterialTheme.typography.bodySmall)
        Text("JORF FERTILIZERS COMPANY I", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun SettingsField(label: String, value: String) {
    Column {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall)
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium, color = TextDark))
    }
}

@Composable private fun BottomNavigationBar(page: Int, onPage: (Int) -> Unit) {
    NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
        NavigationBarItem(
            selected = page == 0, onClick = { onPage(0) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Accueil") },
            label = { Text("Accueil", style = MaterialTheme.typography.labelSmall) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Green, selectedTextColor = Green, indicatorColor = GreenSoft,
                unselectedIconColor = TextMuted, unselectedTextColor = TextMuted
            )
        )
        NavigationBarItem(
            selected = page == 1, onClick = { onPage(1) },
            icon = { Icon(Icons.Default.Settings, contentDescription = "Paramètres") },
            label = { Text("Paramètres", style = MaterialTheme.typography.labelSmall) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Green, selectedTextColor = Green, indicatorColor = GreenSoft,
                unselectedIconColor = TextMuted, unselectedTextColor = TextMuted
            )
        )
    }
}
