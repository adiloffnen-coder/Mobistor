package com.ocp.consultationstocks

import android.content.Context
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val WhatsAppGreen = Color(0xFF25D366)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val Border = Color(0xFFD5E5E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { MobiTheme { App() } }
    }
}

@Composable
private fun MobiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Color.White, surface = Color.White, onSurface = TextDark), content = content)
}

private data class StockRow(val sap:String,val ocp:String,val designation:String,val magasin:String,val division:String,val emplacement:String,val qty:String,val unite:String,val pu:String,val valeur:String,val devise:String,val dateEm:String,val derniereSortie:String)
private data class MovementRow(val date:String,val type:String,val sap:String,val ocp:String,val designation:String,val qty:String,val unite:String,val source:String,val destination:String,val doc:String,val valeur:String)
private data class OrgRow(val code:String,val designation:String,val unite:String,val groupe:String,val organisation:String)

private class SupabaseClient(context: Context) {
    // Supabase mobile configuration: publishable key is intended for client applications.
    // RLS on public.stock allows read-only access for the anon role.
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path:String, query:String): String {
        if (url.isBlank() || key.isBlank()) throw IllegalStateException("Supabase n'est pas configuré. Ouvrez Paramètres.")
        val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        c.requestMethod = "GET"; c.setRequestProperty("apikey", key); c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000; c.readTimeout = 20000
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
        return body
    }

    suspend fun stocks(code:String):List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,division,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock",q))
    }
    suspend fun movements(code:String):List<MovementRow> = withContext(Dispatchers.IO) {
        val q = "select=date_mouvement,type_mouvement,code_sap,code_ocp,designation,quantite,unite,magasin_source,magasin_destination,numero_document,valeur&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&order=date_mouvement.desc&limit=100"
        parseMovements(get("mouvements",q))
    }
    suspend fun organizations(search:String):List<OrgRow> = withContext(Dispatchers.IO) {
        val s = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation&or=(code_article.ilike.*$s*,designation.ilike.*$s*)&limit=100"
        parseOrg(get("articles_organisation",q))
    }
    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val q = "select=$select&limit=$pageSize&offset=$offset"
            val page = JSONArray(get("stock", q))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }
    suspend fun articleCount():Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) {
            for (i in 0 until page.length()) {
                page.getJSONObject(i).optString("code_sap").trim().takeIf { it.isNotEmpty() }?.let(codes::add)
            }
        }
        codes.size
    }
    suspend fun stockValue():String = withContext(Dispatchers.IO) {
        var total=0.0
        for (page in pagedValues("valeur_stock")) {
            for (i in 0 until page.length()) total += page.getJSONObject(i).optDouble("valeur_stock",0.0)
        }
        "%.2f".format(total)
    }
    private fun enc(v:String)=URLEncoder.encode(v,"UTF-8")
    private fun parseStocks(s:String)=JSONArray(s).let { a -> List(a.length()){i-> val o=a.getJSONObject(i); StockRow(o.optString("code_sap"),o.optString("code_ocp"),o.optString("designation"),o.optString("magasin"),o.optString("division"),o.optString("bin"),o.optString("quantite"),o.optString("unite"),o.optString("prix_unitaire"),o.optString("valeur_stock"),o.optString("devise"),o.optString("date_em"),o.optString("derniere_sortie")) } }
    private fun parseMovements(s:String)=JSONArray(s).let { a -> List(a.length()){i-> val o=a.getJSONObject(i); MovementRow(o.optString("date_mouvement"),o.optString("type_mouvement"),o.optString("code_sap"),o.optString("code_ocp"),o.optString("designation"),o.optString("quantite"),o.optString("unite"),o.optString("magasin_source"),o.optString("magasin_destination"),o.optString("numero_document"),o.optString("valeur")) } }
    private fun parseOrg(s:String)=JSONArray(s).let { a -> List(a.length()){i-> val o=a.getJSONObject(i); OrgRow(o.optString("code_article"),o.optString("designation"),o.optString("unite"),o.optString("groupe"),o.optString("organisation")) } }
}

@Composable
private fun App() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val api = remember { SupabaseClient(context) }
    var page by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (page == 1) SettingsPage(api) else HomePage(api, onDetailChanged = { detail = it })
        }
        if (!detail) {
            BottomNavigationBar(page) { newPage -> page = newPage; detail = false }
        }
    }
}

@Composable
private fun HomePage(api: SupabaseClient, onDetailChanged: (Boolean) -> Unit) {
    var stock by remember { mutableStateOf("") }
    var movement by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    var stockResults by remember { mutableStateOf<List<StockRow>?>(null) }
    var movementResults by remember { mutableStateOf<List<MovementRow>?>(null) }
    var orgResults by remember { mutableStateOf<List<OrgRow>?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(stockResults, movementResults, orgResults) {
        onDetailChanged(stockResults != null || movementResults != null || orgResults != null)
    }

    LaunchedEffect(Unit) {
        if (api.url.isNotBlank() && api.key.isNotBlank()) {
            loading = true
            runCatching {
                articleCount = api.articleCount().toString()
                stockValue = api.stockValue()
            }.onFailure {
                dialog = it.message ?: "Erreur Supabase"
            }
            loading = false
        }
    }

    fun codeFilter(s: String): String {
        val filtered = s.filter { it.isDigit() || it == '.' }
        return if (filtered.count { it == '.' } <= 1) {
            filtered.take(11)
        } else {
            filtered.dropLast(1).take(11)
        }
    }

    fun validate(v: String): String? = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    if (stockResults != null) {
        StockResultPage(rows = stockResults!!, onBack = { stockResults = null })
        return
    }
    if (movementResults != null) {
        MovementResultPage(rows = movementResults!!, onBack = { movementResults = null })
        return
    }
    if (orgResults != null) {
        OrgResultPage(rows = orgResults!!, onBack = { orgResults = null })
        return
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(Modifier.fillMaxSize()) {
            Header()
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Spacer(Modifier.height(2.dp))
                WelcomeBanner()
                Spacer(Modifier.height(10.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    SummaryCard(
                        "Nombre d’articles",
                        articleCount,
                        "Articles en stock",
                        Green,
                        Icons.Default.Inventory2,
                        Modifier.weight(1f)
                    )
                    SummaryCard(
                        "Valeur de stock global",
                        stockValue,
                        "MAD",
                        Blue,
                        Icons.Default.Storage,
                        Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))

                SearchModule(
                    title = "Synthèse des stocks",
                    accent = Green,
                    background = GreenSoft,
                    value = stock,
                    onValueChange = { stock = codeFilter(it) },
                    onSearch = {
                        val error = validate(stock)
                        if (error != null) {
                            dialog = error
                        } else {
                            scope.launch {
                                loading = true
                                runCatching { api.stocks(stock.trim()) }
                                    .onSuccess { rows ->
                                        if (rows.isEmpty()) {
                                            dialog = "Aucun stock disponible pour cet article."
                                        } else {
                                            stockResults = rows
                                        }
                                    }
                                    .onFailure {
                                        dialog = it.message ?: "Erreur Supabase"
                                    }
                                loading = false
                            }
                        }
                    }
                )

                Spacer(Modifier.height(10.dp))

                SearchModule(
                    title = "Mouvement matière",
                    accent = Blue,
                    background = BlueSoft,
                    value = movement,
                    onValueChange = { movement = codeFilter(it) },
                    onSearch = {
                        val error = validate(movement)
                        if (error != null) {
                            dialog = error
                        } else {
                            scope.launch {
                                loading = true
                                runCatching { api.movements(movement.trim()) }
                                    .onSuccess { rows ->
                                        if (rows.isEmpty()) {
                                            dialog = "Aucun mouvement trouvé pour cet article."
                                        } else {
                                            movementResults = rows
                                        }
                                    }
                                    .onFailure {
                                        dialog = it.message ?: "Erreur Supabase"
                                    }
                                loading = false
                            }
                        }
                    }
                )

                Spacer(Modifier.height(10.dp))

                SearchModule(
                    title = "Article d’organisation",
                    accent = Purple,
                    background = PurpleSoft,
                    value = org,
                    onValueChange = { org = it },
                    onSearch = {
                        if (org.trim().isBlank()) {
                            dialog = "Veuillez saisir un code ou une désignation."
                        } else {
                            scope.launch {
                                loading = true
                                runCatching { api.organizations(org.trim()) }
                                    .onSuccess { rows ->
                                        if (rows.isEmpty()) {
                                            dialog = "Aucun article d’organisation trouvé."
                                        } else {
                                            orgResults = rows
                                        }
                                    }
                                    .onFailure {
                                        dialog = it.message ?: "Erreur Supabase"
                                    }
                                loading = false
                            }
                        }
                    },
                    organisation = true
                )

                Spacer(Modifier.weight(1f))
                Text(
                    "Work with love ♥",
                    Modifier.fillMaxWidth(),
                    color = GreenDark,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (loading) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Green)
        }
    }

    dialog?.let { message ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("MobiStock") },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { dialog = null }) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
private fun ResultTopBar(title: String, subtitle: String, onBack: () -> Unit, accent: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = accent,
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", tint = Color.White, modifier = Modifier.size(27.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White)
                if (subtitle.isNotBlank()) {
                    Text(subtitle, fontSize = 11.sp, color = Color.White.copy(alpha = .88f))
                }
            }
            IconButton(onClick = onBack) {
                Icon(Icons.Default.Home, contentDescription = "Accueil", tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }
    }
}

private fun displayNumber(value: String): String {
    val n = value.replace(" ", "").replace(",", ".").toDoubleOrNull() ?: return value.ifBlank { "—" }
    return if (n % 1.0 == 0.0) {
        "%,.0f".format(n).replace(',', ' ').replace('.', ',')
    } else {
        "%,.2f".format(n).replace(',', ' ').replace('.', ',')
    }
}

@Composable
private fun StockResultPage(rows: List<StockRow>, onBack: () -> Unit) {
    val first = rows.firstOrNull()
    val designation = first?.designation?.ifBlank { "Article" } ?: "Article"
    val sap = first?.sap.orEmpty()
    val ocp = first?.ocp.orEmpty()
    val devise = first?.devise?.ifBlank { "MAD" } ?: "MAD"
    val totalQty = rows.sumOf { it.qty.replace(" ", "").replace(",", ".").toDoubleOrNull() ?: 0.0 }
    val totalValue = rows.sumOf { it.valeur.replace(" ", "").replace(",", ".").toDoubleOrNull() ?: 0.0 }
    val totalQtyText = "%,.2f".format(totalQty)
    val totalValueText = "%,.2f".format(totalValue)

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF7FCFA))
    ) {
        ResultTopBar("Détail du stock", "", onBack, Green)

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE0EEE8)),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(62.dp),
                                shape = RoundedCornerShape(50),
                                color = Green
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Inventory2,
                                        contentDescription = "Article",
                                        tint = Color.White,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.width(14.dp))
                            Text(
                                designation,
                                fontSize = 27.sp,
                                lineHeight = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = WhatsAppGreen
                            )
                        }

                        Spacer(Modifier.height(14.dp))
                        Text("Code SAP : $sap", fontSize = 18.sp, color = TextDark)
                        Text("Code OCP : $ocp", fontSize = 18.sp, color = TextDark)

                        Spacer(Modifier.height(18.dp))

                        rows.forEachIndexed { index, row ->
                            if (index > 0) Spacer(Modifier.height(20.dp))

                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Store,
                                    contentDescription = "Magasin",
                                    tint = Green,
                                    modifier = Modifier.size(31.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("MAGASIN : ", fontSize = 18.sp, color = Grey)
                                Text(
                                    row.magasin.ifBlank { "—" },
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextDark
                                )
                                Spacer(Modifier.weight(1f))
                                Icon(
                                    Icons.Default.Business,
                                    contentDescription = "OL",
                                    tint = Green,
                                    modifier = Modifier.size(29.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("OL : ", fontSize = 17.sp, color = Grey)
                                Text(
                                    row.division.ifBlank { "—" },
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextDark
                                )
                            }

                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.LocationOn,
                                    contentDescription = "Bin",
                                    tint = Color(0xFFE53935),
                                    modifier = Modifier.size(31.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("BIN : ", fontSize = 18.sp, color = Grey)
                                Text(
                                    row.emplacement.ifBlank { "—" },
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextDark
                                )
                            }

                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = Green, modifier = Modifier.size(29.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Quantité : ", fontSize = 18.sp, color = Grey)
                                Text("${displayNumber(row.qty)} ${row.unite}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            }

                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Paid, contentDescription = null, tint = Green, modifier = Modifier.size(29.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Prix unitaire : ", fontSize = 18.sp, color = Grey)
                                Text("${displayNumber(row.pu)} ${row.devise}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            }

                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AttachMoney, contentDescription = null, tint = GreenDark, modifier = Modifier.size(30.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Valeur : ", fontSize = 18.sp, color = Grey)
                                Text("${displayNumber(row.valeur)} ${row.devise}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            }

                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Green, modifier = Modifier.size(29.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Date EM : ", fontSize = 18.sp, color = Grey)
                                Text(row.dateEm.ifBlank { "—" }, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            }

                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = GreenDark, modifier = Modifier.size(29.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Dernière sortie : ", fontSize = 18.sp, color = Grey)
                                Text(row.derniereSortie.ifBlank { "—" }, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            }
                        }

                        Spacer(Modifier.height(18.dp))

                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(GreenSoft),
                            border = BorderStroke(1.dp, Color(0xFFD0EEE0))
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = GreenDark, modifier = Modifier.size(48.dp))
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("TOTAL EN STOCK : $totalQtyText", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = WhatsAppGreen)
                                    Spacer(Modifier.height(6.dp))
                                    Text("VALEUR GLOBALE : $totalValueText $devise", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = WhatsAppGreen)
                                }
                            }
                        }
                    }
                }
            }
        }

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Text("Retour", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}
