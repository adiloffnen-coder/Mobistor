package com.ocp.consultationstocks

import android.content.Context
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val GreenLight = Color(0xFFF5FCF8)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val GreyLight = Color(0xFF8A9BA5)
private val Border = Color(0xFFD5E5E0)
private val CardBg = Color(0xFFFFFFFF)
private val SurfaceBg = Color(0xFFF7FAF9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { MobiTheme { App() } }
    }
}

@Composable
private fun MobiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            background = Color.White,
            surface = Color.White,
            onSurface = TextDark,
            onPrimary = Color.White
        ),
        content = content
    )
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val division: String, val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)

private data class MovementRow(
    val date: String, val type: String, val sap: String, val ocp: String,
    val designation: String, val qty: String, val unite: String, val source: String,
    val destination: String, val doc: String, val valeur: String
)

private data class OrgRow(
    val code: String, val designation: String, val unite: String,
    val groupe: String, val organisation: String
)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path: String, query: String): String {
        val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("apikey", key)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
        return body
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,division,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }

    suspend fun movements(code: String): List<MovementRow> = withContext(Dispatchers.IO) {
        val q = "select=date_mouvement,type_mouvement,code_sap,code_ocp,designation,quantite,unite,magasin_source,magasin_destination,numero_document,valeur&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&order=date_mouvement.desc&limit=100"
        parseMovements(get("mouvements", q))
    }

    suspend fun organizations(search: String): List<OrgRow> = withContext(Dispatchers.IO) {
        val s = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation&or=(code_article.ilike.*$s*,designation.ilike.*$s*)&limit=100"
        parseOrg(get("articles_organisation", q))
    }

    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }

    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) {
            for (i in 0 until page.length()) {
                page.getJSONObject(i).optString("code_sap").trim()
                    .takeIf { it.isNotEmpty() }?.let(codes::add)
            }
        }
        codes.size
    }

    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        var total = BigDecimal.ZERO
        for (page in pagedValues("valeur_stock")) {
            for (i in 0 until page.length()) {
                total = total.add(
                    page.getJSONObject(i).optString("valeur_stock", "0")
                        .toBigDecimalOrNull() ?: BigDecimal.ZERO
                )
            }
        }
        formatMoney(total)
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun parseStocks(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            StockRow(
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("magasin"), o.optString("division"), o.optString("bin"), o.optString("quantite"),
                o.optString("unite"), o.optString("prix_unitaire"), o.optString("valeur_stock"),
                o.optString("devise"), o.optString("date_em"), o.optString("derniere_sortie")
            )
        }
    }

    private fun parseMovements(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            MovementRow(
                o.optString("date_mouvement"), o.optString("type_mouvement"),
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("quantite"), o.optString("unite"), o.optString("magasin_source"),
                o.optString("magasin_destination"), o.optString("numero_document"),
                o.optString("valeur")
            )
        }
    }

    private fun parseOrg(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            OrgRow(
                o.optString("code_article"), o.optString("designation"),
                o.optString("unite"), o.optString("groupe"), o.optString("organisation")
            )
        }
    }
}

private fun formatMoney(value: BigDecimal): String =
    NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
        isGroupingUsed = true
    }.format(value)

private fun formatMoney(raw: String, currency: String): String =
    "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"

private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 3
        isGroupingUsed = true
    }.format(n)
}

private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 ->
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10)
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else
            SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) {
        raw
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }
    var movementRows by remember { mutableStateOf<List<MovementRow>?>(null) }
    // null = home content, "movement" / "org" = dedicated search screens
    var subScreen by remember { mutableStateOf<String?>(null) }

    if (stockRows != null) {
        StockResultPage(
            rows = stockRows!!,
            onBack = { stockRows = null },
            onHome = { stockRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (movementRows != null) {
        MovementResultPage(
            rows = movementRows!!,
            onBack = { movementRows = null },
            onHome = { movementRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "movement") {
        MovementSearchPage(
            api = api,
            onBack = { subScreen = null },
            onResult = { movementRows = it }
        )
        return
    }
    if (subScreen == "org") {
        OrgSearchPage(
            api = api,
            onBack = { subScreen = null }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        if (page == 1) {
            SettingsPage(api)
        } else {
            HomePage(
                api = api,
                onStockResult = { stockRows = it },
                onOpenMovement = { subScreen = "movement" },
                onOpenOrg = { subScreen = "org" }
            )
        }
        BottomNavigationBar(
            page = page,
            onPage = { page = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun HomePage(
    api: SupabaseClient,
    onStockResult: (List<StockRow>) -> Unit,
    onOpenMovement: () -> Unit,
    onOpenOrg: () -> Unit
) {
    var stock by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        loading = true
        runCatching {
            articleCount = api.articleCount().toString()
            stockValue = api.stockValue()
        }.onFailure { dialog = it.message }
        loading = false
    }

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Surface(modifier = Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Header()
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SummaryCard(
                            title = "Nombre d'articles",
                            value = articleCount,
                            subtitle = "Articles en stock",
                            accent = Green,
                            icon = Icons.Default.Inventory2,
                            modifier = Modifier.weight(1f)
                        )
                        SummaryCard(
                            title = "Valeur de stock",
                            value = stockValue,
                            subtitle = "MAD",
                            accent = Blue,
                            icon = Icons.Default.AccountBalance,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    // Synthèse des stocks — style écran dédié
                    StockSearchBlock(
                        value = stock,
                        onValueChange = { stock = codeFilter(it) },
                        onSearch = {
                            keyboard?.hide()
                            val e = validate(stock)
                            if (e != null) dialog = e
                            else scope.launch {
                                loading = true
                                runCatching { api.stocks(stock.trim()) }
                                    .onSuccess { r ->
                                        if (r.isEmpty())
                                            dialog = "Aucun stock disponible pour cet article"
                                        else onStockResult(r)
                                    }
                                    .onFailure { dialog = it.message }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(20.dp))
                }
                item {
                    // Bouton Mouvement matière → écran dédié
                    ModuleNavButton(
                        title = "Mouvement matière",
                        subtitle = "Historique des mouvements",
                        emoji = "🔄",
                        accent = Blue,
                        background = BlueSoft,
                        onClick = onOpenMovement
                    )
                    Spacer(Modifier.height(12.dp))
                }
                item {
                    // Bouton Article d'organisation → écran dédié
                    ModuleNavButton(
                        title = "Article d'organisation",
                        subtitle = "Recherche par code ou désignation",
                        emoji = "🏢",
                        accent = Purple,
                        background = PurpleSoft,
                        onClick = onOpenOrg
                    )
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    Text(
                        "Work with love ♥",
                        Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        color = GreenDark.copy(alpha = 0.7f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun StockSearchBlock(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📦", fontSize = 22.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                "Synthèse des stocks",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Green
            )
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(0.dp),
            placeholder = {
                Text(
                    "Saisir Code SAP ou Code OCP",
                    color = GreyLight,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            textStyle = LocalTextStyle.current.copy(
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextDark,
                textAlign = TextAlign.Center
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Decimal,
                imeAction = ImeAction.Search
            ),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green,
                unfocusedBorderColor = Border,
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                cursorColor = Green
            )
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onSearch,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) {
            Text("🔍", fontSize = 16.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                "RECHERCHER",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Rechercher un article par son Code SAP ou son Code OCP.",
            fontSize = 13.sp,
            color = Grey,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
            lineHeight = 18.sp
        )
    }
}

@Composable
private fun ModuleNavButton(
    title: String,
    subtitle: String,
    emoji: String,
    accent: Color,
    background: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(0.dp))
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 20.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = accent
                )
                Text(
                    subtitle,
                    fontSize = 12.sp,
                    color = Grey
                )
            }
            Text("›", fontSize = 28.sp, color = accent, fontWeight = FontWeight.Light)
        }
    }
}

@Composable
private fun MovementSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit,
    onResult: (List<MovementRow>) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }
    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Surface(Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvement matière",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔄", fontSize = 22.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Mouvement matière",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Blue
                    )
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(0.dp),
                    placeholder = {
                        Text("Saisir Code SAP ou Code OCP", color = GreyLight, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDark,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = {
                        keyboard?.hide()
                        val e = validate(code)
                        if (e != null) dialog = e
                        else scope.launch {
                            loading = true
                            runCatching { api.movements(code.trim()) }
                                .onSuccess { r ->
                                    if (r.isEmpty()) dialog = "Aucun mouvement trouvé pour cet article."
                                    else onResult(r)
                                }
                                .onFailure { dialog = it.message }
                            loading = false
                        }
                    }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = Blue
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        keyboard?.hide()
                        val e = validate(code)
                        if (e != null) dialog = e
                        else scope.launch {
                            loading = true
                            runCatching { api.movements(code.trim()) }
                                .onSuccess { r ->
                                    if (r.isEmpty()) dialog = "Aucun mouvement trouvé pour cet article."
                                    else onResult(r)
                                }
                                .onFailure { dialog = it.message }
                            loading = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Rechercher les mouvements par Code SAP ou Code OCP.",
                    fontSize = 13.sp,
                    color = Grey,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun OrgSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit
) {
    var code by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun doSearch() {
        keyboard?.hide()
        val c = code.trim()
        val d = designation.trim()
        if (c.isBlank() && d.isBlank()) {
            dialog = "Veuillez saisir un code ou une désignation."
            return
        }
        // Prefer code if filled, else designation; if both, search by code first then designation merge unique
        scope.launch {
            loading = true
            runCatching {
                val results = mutableListOf<OrgRow>()
                val seen = mutableSetOf<String>()
                if (c.isNotBlank()) {
                    for (r in api.organizations(c)) {
                        if (seen.add(r.code)) results += r
                    }
                }
                if (d.isNotBlank()) {
                    for (r in api.organizations(d)) {
                        if (seen.add(r.code)) results += r
                    }
                }
                results
            }.onSuccess { r ->
                dialog = if (r.isEmpty())
                    "Aucun article d'organisation trouvé."
                else r.joinToString("\n\n") {
                    "Code: ${it.code}\n${it.designation}\nUnité: ${it.unite}\nGroupe: ${it.groupe}\nOrganisation: ${it.organisation}"
                }
            }.onFailure { dialog = it.message }
            loading = false
        }
    }

    Surface(Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Purple)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Article d'organisation",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🏢", fontSize = 22.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Article d'organisation",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple
                    )
                }
                Spacer(Modifier.height(16.dp))

                // Barre 1 : code SAP / OCP — numérique, un seul point
                Text(
                    "Code SAP ou Code OCP",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Grey
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(0.dp),
                    placeholder = {
                        Text(
                            "Ex. 10067.05422",
                            color = GreyLight,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDark,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = Purple
                    )
                )

                Spacer(Modifier.height(14.dp))

                // Barre 2 : désignation — alphanumérique
                Text(
                    "Désignation",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Grey
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(0.dp),
                    placeholder = {
                        Text(
                            "Ex. MANCHON COMPENSATEUR",
                            color = GreyLight,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextDark,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = Purple
                    )
                )

                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Saisir un code SAP/OCP et/ou une désignation.",
                    fontSize = 13.sp,
                    color = Grey,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun LoadingOverlay(loading: Boolean) {
    if (!loading) return
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(Color.White),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Green, strokeWidth = 3.dp)
                Spacer(Modifier.height(12.dp))
                Text("Chargement…", color = TextDark, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun AppDialog(msg: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(0.dp),
        containerColor = Color.White,
        title = {
            Text(
                "MobiStock",
                fontWeight = FontWeight.Bold,
                color = GreenDark,
                fontSize = 18.sp
            )
        },
        text = {
            Text(msg, color = TextDark, fontSize = 14.sp, lineHeight = 20.sp)
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("OK", fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
private fun StockResultPage(
    rows: List<StockRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.qty.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val totalValue = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.valeur.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val currency = first?.devise?.takeIf { it.isNotBlank() } ?: "MAD"
    val WaGreen = Color(0xFF25D366)

    Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Green)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Détail du stock",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Code SAP : ${first.sap.ifBlank { "—" }}",
                            fontSize = 14.sp,
                            color = TextDark,
                            lineHeight = 16.sp
                        )
                        Text(
                            "Code OCP : ${first.ocp.ifBlank { "—" }}",
                            fontSize = 14.sp,
                            color = TextDark,
                            lineHeight = 16.sp
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    StockDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item {
                    Spacer(Modifier.height(6.dp))
                    HorizontalDivider(color = Color(0xFFCCCCCC), thickness = 1.dp)
                    Spacer(Modifier.height(14.dp))
                    // TOTAL EN STOCK — emoji 📦 uniquement
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📦", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "TOTAL EN STOCK : ${formatQty(totalQty.toPlainString())}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💰", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "VALEUR GLOBALE : ${formatMoney(totalValue)} $currency",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun StockDetailBlock(row: StockRow, showDivider: Boolean) {
    Column(Modifier.fillMaxWidth()) {
        // MAGASIN + OL — emojis comme sur WhatsApp
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${row.magasin.ifBlank { "—" }}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
            if (row.division.isNotBlank()) {
                Spacer(Modifier.width(14.dp))
                Text("🏢", fontSize = 16.sp)
                Spacer(Modifier.width(4.dp))
                Text(
                    "OL : ${row.division}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        // BIN — pin rouge emoji
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📍", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "BIN : ${row.emplacement.ifBlank { "—" }}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
        }
        Spacer(Modifier.height(2.dp))
        // Lignes sans icônes
        Text(
            "Quantité : ${formatQty(row.qty)} ${row.unite}",
            fontSize = 14.sp,
            color = TextDark,
            lineHeight = 18.sp
        )
        Text(
            "Prix unitaire : ${formatMoney(row.pu, row.devise.ifBlank { "MAD" })}",
            fontSize = 14.sp,
            color = TextDark,
            lineHeight = 18.sp
        )
        Text(
            "Valeur : ${formatMoney(row.valeur, row.devise.ifBlank { "MAD" })}",
            fontSize = 14.sp,
            color = TextDark,
            lineHeight = 18.sp
        )
        Text(
            "Date EM : ${formatDate(row.dateEm)}",
            fontSize = 14.sp,
            color = TextDark,
            lineHeight = 18.sp
        )
        Text(
            "Dernière sortie : ${formatDate(row.derniereSortie)}",
            fontSize = 14.sp,
            color = TextDark,
            lineHeight = 18.sp
        )
        if (showDivider) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFB7C9C2), thickness = 1.dp)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun StockCard(row: StockRow, index: Int) {
    StockDetailBlock(row, showDivider = false)
}

@Composable
private fun StockField(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, color = Grey, modifier = Modifier.width(110.dp))
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextDark,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CodeChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "$label : ",
                fontSize = 11.sp,
                color = Grey,
                fontWeight = FontWeight.Medium
            )
            Text(
                value.ifBlank { "—" },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
        }
    }
}

@Composable
private fun MovementResultPage(
    rows: List<MovementRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Blue)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Text(
                    "Mouvements matière",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                item {
                    Text(
                        "${rows.size} mouvement${if (rows.size > 1) "s" else ""}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Grey,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
                itemsIndexed(rows) { index, row ->
                    MovementCard(row, index + 1)
                    Spacer(Modifier.height(12.dp))
                }
            }

            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Blue)
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text("Retour", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MovementCard(row: MovementRow, index: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(CardBg),
        elevation = CardDefaults.cardElevation(1.dp),
        border = BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Blue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "$index",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        row.type.ifBlank { "Mouvement" },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark
                    )
                    Text(
                        formatDate(row.date),
                        fontSize = 12.sp,
                        color = Grey
                    )
                }
            }
            if (row.designation.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    row.designation,
                    fontSize = 13.sp,
                    color = TextDark,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            HorizontalDivider(
                Modifier.padding(vertical = 10.dp),
                color = Border,
                thickness = 1.dp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CodeChip("SAP", row.sap)
                CodeChip("OCP", row.ocp)
            }
            Spacer(Modifier.height(8.dp))
            StockField(Icons.Default.Inventory2, "Quantité", "${formatQty(row.qty)} ${row.unite}")
            StockField(Icons.Default.Store, "Source", row.source.ifBlank { "—" })
            StockField(Icons.Default.LocalShipping, "Destination", row.destination.ifBlank { "—" })
            StockField(Icons.Default.Description, "Document", row.doc.ifBlank { "—" })
            if (row.valeur.isNotBlank()) {
                StockField(Icons.Default.AttachMoney, "Valeur", row.valeur)
            }
        }
    }
}

@Composable
private fun SummaryLine(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = Grey, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
    }
}

@Composable
private fun Header() {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(0.dp))
                .background(GreenSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Eco,
                contentDescription = null,
                tint = Green,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "JORF FERTILIZERS COMPANY I",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = GreenDark.copy(alpha = 0.8f)
            )
            Text(
                "MobiStock",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = GreenDark
            )
            Text(
                "Gestion des stocks & mouvements",
                fontSize = 11.sp,
                color = Grey
            )
        }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD))
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Bonjour,",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GreenDark
                )
                Text(
                    "Bienvenue sur MobiStock",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Consultez et gérez vos stocks et mouvements en temps réel.",
                    fontSize = 11.sp,
                    color = Grey,
                    lineHeight = 15.sp
                )
            }
            Icon(
                Icons.Default.Business,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color(0x6675A98A)
            )
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(CardBg),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f)),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(0.dp))
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Grey,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    value,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    subtitle,
                    fontSize = 10.sp,
                    color = GreyLight
                )
            }
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    subtitle: String,
    accent: Color,
    background: Color,
    icon: ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    organisation: Boolean,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                    Text(
                        subtitle,
                        fontSize = 11.sp,
                        color = Grey
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            placeholder,
                            color = GreyLight,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextDark
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = accent
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Rechercher",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(api: SupabaseClient) {
    Surface(modifier = Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .padding(top = 24.dp, bottom = 80.dp)
        ) {
            Text(
                "Paramètres",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = GreenDark
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "Connexion Supabase",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
            Spacer(Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(GreenSoft),
                border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Green)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Supabase connecté",
                            fontWeight = FontWeight.Bold,
                            color = GreenDark,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Base de données", fontSize = 11.sp, color = Grey)
                    Text(
                        "kbztwijnoyifbmtoanps.supabase.co",
                        fontSize = 13.sp,
                        color = TextDark,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Accès : lecture seule des stocks",
                        fontSize = 12.sp,
                        color = Grey
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("MobiStock 1.2", color = Grey, fontSize = 13.sp)
            Text("JORF FERTILIZERS COMPANY I", color = Grey, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BottomNavigationBar(
    page: Int,
    onPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 8.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            NavigationItem(
                icon = Icons.Default.Home,
                label = "Accueil",
                active = page == 0,
                onClick = { onPage(0) }
            )
            NavigationItem(
                icon = Icons.Default.Settings,
                label = "Paramètres",
                active = page == 1,
                onClick = { onPage(1) }
            )
        }
    }
}

@Composable
private fun NavigationItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val color = if (active) Green else Grey
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(120.dp)
            .padding(vertical = 4.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(24.dp))
        }
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            color = color
        )
        if (active) {
            Spacer(Modifier.height(2.dp))
            Box(
                Modifier
                    .width(40.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Green)
            )
        }
    }
}
