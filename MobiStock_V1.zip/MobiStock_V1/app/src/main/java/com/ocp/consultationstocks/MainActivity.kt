package com.ocp.consultationstocks

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

private val Green = Color(0xFF22C55E)
private val GreenDark = Color(0xFF16A34A)
private val Blue = Color(0xFF3B82F6)
private val Purple = Color(0xFFA855F7)
private val HeaderGreen = Color(0xFF15803D)
private val GreenSoft = Color(0xFF14532D)
private val BlueSoft = Color(0xFF1E3A5F)
private val PurpleSoft = Color(0xFF3B0764)

private data class MobiColors(
    val surfaceBg: Color,
    val cardSurface: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val fieldBg: Color,
    val isDark: Boolean
)

private val DarkColors = MobiColors(
    surfaceBg = Color(0xFF0B1220),
    cardSurface = Color(0xFF0F172A),
    textPrimary = Color.White,
    textSecondary = Color(0xFF94A3B8),
    textMuted = Color(0xFF64748B),
    border = Color(0xFF1E293B),
    fieldBg = Color(0xFF0F172A),
    isDark = true
)

private val LightColors = MobiColors(
    surfaceBg = Color(0xFFF8FAFC),
    cardSurface = Color.White,
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    textMuted = Color(0xFF94A3B8),
    border = Color(0xFFE2E8F0),
    fieldBg = Color(0xFFF1F5F9),
    isDark = false
)

private val LocalMobiColors = staticCompositionLocalOf { DarkColors }

private val PrefsName = "mobistock_prefs"
private val PrefDark = "dark_theme"
private val PrefLang = "app_lang"
private val PrefLoggedIn = "logged_in"
private val PrefLoginAt = "login_at_ms"
private val PrefLoginUser = "login_user"
private const val SESSION_MAX_MS = 80L * 60 * 1000 // 1 heure 20 minutes

/** Auth via table Supabase AppUsers (plus de mot de passe fixe dans le code). */

data class AppStrings(
    val settings: String,
    val appearance: String,
    val darkMode: String,
    val lightMode: String,
    val language: String,
    val french: String,
    val english: String,
    val home: String,
    val stockSummary: String,
    val movement: String,
    val orgArticle: String,
    val search: String,
    val loading: String,
    val back: String,
    val noOrg: String,
    val noStock: String,
    val noMovement: String,
    val enterCodeOrDesignation: String,
    val enterCode: String,
    val designation: String,
    val descriptif: String,
    val login: String,
    val loginSubtitle: String,
    val identifier: String,
    val password: String,
    val connect: String,
    val logout: String,
    val noNetwork: String,
    val codeCopied: String,
    val searchBySapOcp: String,
    val wrongCredentials: String,
    val enterCredentials: String,
    val stockDetail: String,
    val optionalFilters: String,
    val codeRequiredFiltersOptional: String,
    val darkModeDesc: String,
    val lightModeDesc: String,
    val workWithLove: String,
    val articlesCount: String,
    val stockValue: String,
    val articlesInStock: String,
    val movementHistory: String,
    val orgSearchHint: String
)

private val StringsFr = AppStrings(
    settings = "Paramètres",
    appearance = "Apparence",
    darkMode = "Mode sombre",
    lightMode = "Mode clair",
    language = "Langue",
    french = "Français",
    english = "English",
    home = "Accueil",
    stockSummary = "SYNTHÈSE DES STOCKS",
    movement = "Mouvement matière",
    orgArticle = "Article d'organisation",
    search = "RECHERCHER",
    loading = "Chargement…",
    back = "Retour",
    noOrg = "Aucun article d'organisation trouvé.",
    noStock = "Aucun stock disponible pour cet article",
    noMovement = "Aucun mouvement trouvé pour cet article.",
    enterCodeOrDesignation = "Saisir un code SAP/OCP et/ou une désignation.",
    enterCode = "Saisir Code SAP ou Code OCP",
    designation = "Désignation",
    descriptif = "Descriptif",
    login = "Connexion",
    loginSubtitle = "Saisissez vos identifiants",
    identifier = "Identifiant",
    password = "Mot de passe",
    connect = "SE CONNECTER",
    logout = "Se déconnecter",
    noNetwork = "Pas de connexion réseau. Vérifiez votre Internet.",
    codeCopied = "Code copié",
    searchBySapOcp = "Recherche par code SAP ou code OCP.",
    wrongCredentials = "Identifiant ou mot de passe incorrect.",
    enterCredentials = "Veuillez saisir l'identifiant et le mot de passe.",
    stockDetail = "Détail du stock",
    optionalFilters = "Filtres optionnels",
    codeRequiredFiltersOptional = "Code SAP/OCP obligatoire. Filtres magasin, code mouvement et dates optionnels.",
    darkModeDesc = "Fond sombre, texte clair",
    lightModeDesc = "Fond clair, texte sombre",
    workWithLove = "Work with love",
    articlesCount = "Nombre d'articles",
    stockValue = "Valeur de stock",
    articlesInStock = "Articles en stock",
    movementHistory = "Historique des mouvements",
    orgSearchHint = "Recherche par code ou désignation"
)

private val StringsEn = AppStrings(
    settings = "Settings",
    appearance = "Appearance",
    darkMode = "Dark mode",
    lightMode = "Light mode",
    language = "Language",
    french = "Français",
    english = "English",
    home = "Home",
    stockSummary = "STOCK SUMMARY",
    movement = "Material movement",
    orgArticle = "Organization article",
    search = "SEARCH",
    loading = "Loading…",
    back = "Back",
    noOrg = "No organization article found.",
    noStock = "No stock available for this item",
    noMovement = "No movement found for this item.",
    enterCodeOrDesignation = "Enter a SAP/OCP code and/or a designation.",
    enterCode = "Enter SAP code or OCP code",
    designation = "Designation",
    descriptif = "Description",
    login = "Sign in",
    loginSubtitle = "Enter your credentials",
    identifier = "Username",
    password = "Password",
    connect = "SIGN IN",
    logout = "Sign out",
    noNetwork = "No network connection. Check your Internet.",
    codeCopied = "Code copied",
    searchBySapOcp = "Search by SAP code or OCP code.",
    wrongCredentials = "Incorrect username or password.",
    enterCredentials = "Please enter username and password.",
    stockDetail = "Stock detail",
    optionalFilters = "Optional filters",
    codeRequiredFiltersOptional = "SAP/OCP code required. Magasin, movement code and dates optional.",
    darkModeDesc = "Dark background, light text",
    lightModeDesc = "Light background, dark text",
    workWithLove = "Work with love",
    articlesCount = "Number of items",
    stockValue = "Stock value",
    articlesInStock = "Items in stock",
    movementHistory = "Movement history",
    orgSearchHint = "Search by code or designation"
)

fun stringsFor(lang: String) = if (lang == "en") StringsEn else StringsFr

fun friendlyError(msg: String?, s: AppStrings): String {
    if (msg == null) return s.noNetwork
    if (msg == "NETWORK" || msg.contains("Unable to resolve", true) ||
        msg.contains("Failed to connect", true) || msg.contains("timeout", true)
    ) return s.noNetwork
    return msg
}

val LocalAppStrings = staticCompositionLocalOf { StringsFr }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        val initialDark = prefs.getBoolean(PrefDark, true)
        val initialLang = prefs.getString(PrefLang, "fr") ?: "fr"
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        val loginAt = prefs.getLong(PrefLoginAt, 0L)
        val stillValid = prefs.getBoolean(PrefLoggedIn, false) &&
            loginAt > 0L &&
            (System.currentTimeMillis() - loginAt) < SESSION_MAX_MS
        if (prefs.getBoolean(PrefLoggedIn, false) && !stillValid) {
            prefs.edit().putBoolean(PrefLoggedIn, false).remove(PrefLoginAt).apply()
        }
        val initialLoggedIn = stillValid
        setContent {
            var isDark by remember { mutableStateOf(initialDark) }
            var lang by remember { mutableStateOf(initialLang) }
            var isLoggedIn by remember { mutableStateOf(initialLoggedIn) }
            MobiTheme(isDark) {
                CompositionLocalProvider(LocalAppStrings provides stringsFor(lang)) {
                    if (!isLoggedIn) {
                        LoginScreen(
                            api = SupabaseClient(this@MainActivity),
                            onSuccess = { username ->
                                isLoggedIn = true
                                prefs.edit()
                                    .putBoolean(PrefLoggedIn, true)
                                    .putLong(PrefLoginAt, System.currentTimeMillis())
                                    .putString(PrefLoginUser, username)
                                    .apply()
                            }
                        )
                    } else {
                        App(
                            isDark = isDark,
                            onThemeChange = { dark ->
                                isDark = dark
                                prefs.edit().putBoolean(PrefDark, dark).apply()
                            },
                            lang = lang,
                            onLangChange = { l ->
                                lang = l
                                prefs.edit().putString(PrefLang, l).apply()
                            },
                            onLogout = {
                                isLoggedIn = false
                                prefs.edit()
                                    .putBoolean(PrefLoggedIn, false)
                                    .remove(PrefLoginAt)
                                    .remove(PrefLoginUser)
                                    .apply()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MobiTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    CompositionLocalProvider(LocalMobiColors provides colors) {
        MaterialTheme(
            colorScheme = if (darkTheme) darkColorScheme(
                primary = Green,
                background = colors.surfaceBg,
                surface = colors.cardSurface,
                onSurface = colors.textPrimary,
                onPrimary = Color.White
            ) else lightColorScheme(
                primary = Green,
                background = colors.surfaceBg,
                surface = colors.cardSurface,
                onSurface = colors.textPrimary,
                onPrimary = Color.White
            ),
            content = content
        )
    }
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val division: String, val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)

private data class MovementRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val magasin: String,
    val quantite: String,
    val unite: String,
    val montant: String,
    val codeMouvement: String,
    val ordre: String,
    val reservation: String,
    val po: String,
    val docArticle: String,
    val date: String,
    val partenaire: String
)

private data class OrgRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val descriptif: String,
    val famille: String = ""
)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path: String, query: String): String {
        try {
            val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
            c.requestMethod = "GET"
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Accept", "application/json")
            c.connectTimeout = 15000
            c.readTimeout = 20000
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            c.disconnect()
            if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
            return body
        } catch (e: java.net.UnknownHostException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.net.SocketTimeoutException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.io.IOException) {
            throw IllegalStateException("NETWORK")
        }
    }

    /** true si compte inactif ou force_logout (colonne optionnelle). */
    suspend fun shouldForceLogout(identifiant: String): Boolean = withContext(Dispatchers.IO) {
        if (identifiant.isBlank()) return@withContext false
        val id = enc(identifiant.trim())
        try {
            val body = get("AppUsers", "identifiant=eq.$id&select=actif,force_logout&limit=1")
            val arr = JSONArray(body)
            if (arr.length() == 0) return@withContext true
            val o = arr.getJSONObject(0)
            if (!o.optBoolean("actif", true)) return@withContext true
            if (o.has("force_logout") && o.optBoolean("force_logout", false)) return@withContext true
            false
        } catch (e: Exception) {
            if (e.message == "NETWORK") throw e
            // Colonne force_logout absente : vérifier seulement actif
            try {
                val body = get("AppUsers", "identifiant=eq.$id&select=actif&limit=1")
                val arr = JSONArray(body)
                if (arr.length() == 0) return@withContext true
                !arr.getJSONObject(0).optBoolean("actif", true)
            } catch (e2: Exception) {
                if (e2.message == "NETWORK") throw e2
                false
            }
        }
    }

    /** Vérifie identifiant + mot de passe dans AppUsers (actif = true). */
    suspend fun login(identifiant: String, motDePasse: String): Boolean = withContext(Dispatchers.IO) {
        val id = enc(identifiant.trim())
        val q = "identifiant=eq.$id&actif=eq.true&select=identifiant,mot_de_passe&limit=1"
        val body = get("AppUsers", q)
        val arr = JSONArray(body)
        if (arr.length() == 0) return@withContext false
        val stored = arr.getJSONObject(0).optString("mot_de_passe", "")
        stored == motDePasse
    }


    /** Consommation : somme |montant| codes 261/262/201/202 + dernière date 2026. */
    data class ConsumptionStats(
        val amount2025: String,
        val amount2026: String,
        val lastDate2025: String,
        val lastDate2026: String
    )

    suspend fun consumptionByYear(): ConsumptionStats = withContext(Dispatchers.IO) {
        val codes = setOf("261", "262", "201", "202")
        val all = JSONArray()
        // Pagination pour ne pas rater 2025 (limite PostgREST souvent 1000)
        for (c in listOf("261", "262", "201", "202")) {
            var offset = 0
            while (offset < 30000) {
                try {
                    val part = JSONArray(
                        get(
                            "Mb51",
                            "code_mouvement=eq.$c&select=montant_di,montant,date,code_mouvement,date_de_saisie&limit=1000&offset=$offset"
                        )
                    )
                    for (i in 0 until part.length()) all.put(part.getJSONObject(i))
                    if (part.length() < 1000) break
                    offset += 1000
                } catch (_: Exception) {
                    break
                }
            }
        }
        var y2025 = BigDecimal.ZERO
        var y2026 = BigDecimal.ZERO
        var maxKey2025 = ""
        var maxLabel2025 = ""
        var maxKey2026 = ""
        var maxLabel2026 = ""

        fun dateRaw(o: org.json.JSONObject): String {
            for (k in listOf("date", "Date", "budat", "date_mouvement", "date_de_saisie", "Date de saisie", "posting_date")) {
                if (o.has(k) && !o.isNull(k)) {
                    val v = o.opt(k)?.toString()?.trim().orEmpty()
                    if (v.isNotEmpty() && v != "null") return v
                }
            }
            // balayer toutes les clés contenant "date"
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k.contains("date", ignoreCase = true) && !o.isNull(k)) {
                    val v = o.opt(k)?.toString()?.trim().orEmpty()
                    if (v.isNotEmpty() && v != "null") return v
                }
            }
            return ""
        }
        fun yearAndKey(d: String): Pair<Int, String>? {
            val s = d.trim()
            if (s.isBlank()) return null
            Regex("""(\d{4})-(\d{2})-(\d{2})""").find(s)?.let {
                val y = it.groupValues[1].toIntOrNull() ?: return@let
                val key = it.groupValues[1] + it.groupValues[2] + it.groupValues[3]
                return y to key
            }
            Regex("""(\d{2})[./](\d{2})[./](\d{4})""").find(s)?.let {
                val y = it.groupValues[3].toIntOrNull() ?: return@let
                val key = it.groupValues[3] + it.groupValues[2] + it.groupValues[1]
                return y to key
            }
            return null
        }
        fun montantOf(o: org.json.JSONObject): BigDecimal? {
            for (k in listOf("montant_di", "montant", "Montant", "dmbtr", "amount")) {
                if (o.has(k) && !o.isNull(k)) {
                    val raw = o.opt(k)?.toString()?.replace(" ", "")?.replace(",", ".")?.replace("MAD", "")?.trim() ?: continue
                    val v = raw.toBigDecimalOrNull()
                    if (v != null) return v
                }
            }
            return null
        }
        fun codeOf(o: org.json.JSONObject): String {
            for (k in listOf("code_mouvement", "Code mouvement", "bwart", "movement_type")) {
                if (o.has(k) && !o.isNull(k)) {
                    val v = o.opt(k)?.toString()?.trim()?.substringBefore(".") ?: continue
                    if (v.isNotEmpty() && v != "null") return v
                }
            }
            return ""
        }
        fun fmtMoney(v: BigDecimal): String {
            val n = v.setScale(2, java.math.RoundingMode.HALF_UP)
            return n.toPlainString() + " MAD"
        }
        fun fmtDateLabel(d: String): String {
            if (d.isBlank()) return "—"
            return try { formatDate(d) } catch (_: Exception) { d }
        }

        for (i in 0 until all.length()) {
            val o = all.getJSONObject(i)
            if (codeOf(o) !in codes) continue
            val m = montantOf(o) ?: continue
            val absM = m.abs()
            val dr = dateRaw(o)
            val yk = yearAndKey(dr) ?: continue
            when (yk.first) {
                2025 -> {
                    y2025 += absM
                    if (yk.second > maxKey2025) {
                        maxKey2025 = yk.second
                        maxLabel2025 = dr
                    }
                }
                2026 -> {
                    y2026 += absM
                    if (yk.second > maxKey2026) {
                        maxKey2026 = yk.second
                        maxLabel2026 = dr
                    }
                }
            }
        }
        ConsumptionStats(
            amount2025 = fmtMoney(y2025),
            amount2026 = fmtMoney(y2026),
            lastDate2025 = if (maxLabel2025.isBlank()) "—" else fmtDateLabel(maxLabel2025),
            lastDate2026 = if (maxLabel2026.isBlank()) "—" else fmtDateLabel(maxLabel2026)
        )
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,division,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }

    suspend fun movements(
        code: String,
        magasin: String = "",
        codeMouvement: String = "",
        dateFrom: String = "",
        dateTo: String = ""
    ): List<MovementRow> = withContext(Dispatchers.IO) {
        val trimmed = code.trim()
        val parts = mutableListOf<String>()
        if (trimmed.contains('.')) {
            parts += "code_ocp=eq.${enc(trimmed)}"
        } else {
            parts += "or=(code_sap.eq.${enc(trimmed)},code_ocp.eq.${enc(trimmed)})"
        }
        val mag = magasin.trim()
        if (mag.isNotBlank()) parts += "magasin=ilike.*${enc(mag)}*"
        val cm = codeMouvement.trim()
        if (cm.isNotBlank()) parts += "code_mouvement=eq.${enc(cm)}"
        parts += "select=*"
        parts += "limit=300"
        var rows = parseMovements(get("Mb51", parts.joinToString("&")))
        // Filtre dates côté client (formats variables)
        fun toKey(d: String): String? {
            val s = d.trim()
            if (s.isBlank()) return null
            // YYYY-MM-DD
            Regex("""^(\d{4})-(\d{2})-(\d{2})""").find(s)?.let {
                return it.groupValues[1] + it.groupValues[2] + it.groupValues[3]
            }
            // DD.MM.YYYY or DD/MM/YYYY
            Regex("""^(\d{2})[./](\d{2})[./](\d{4})""").find(s)?.let {
                return it.groupValues[3] + it.groupValues[2] + it.groupValues[1]
            }
            return null
        }
        val fromKey = toKey(dateFrom)
        val toKey = toKey(dateTo)
        if (fromKey != null || toKey != null) {
            rows = rows.filter { row ->
                val k = toKey(row.date) ?: return@filter true
                if (fromKey != null && k < fromKey) return@filter false
                if (toKey != null && k > toKey) return@filter false
                true
            }
        }
        // Filet de sécurité magasin / code mouvement (si filtre serveur partiel)
        if (mag.isNotBlank()) {
            val m = mag.uppercase()
            rows = rows.filter { it.magasin.uppercase().contains(m) }
        }
        if (cm.isNotBlank()) {
            rows = rows.filter { it.codeMouvement.trim() == cm }
        }
        rows
    }

    /** Recherche multicritères Mm03 (ET entre critères non vides). */
    suspend fun organizationsSearch(
        code: String = "",
        designation: String = "",
        descriptif: String = "",
        famille: String = ""
    ): List<OrgRow> = withContext(Dispatchers.IO) {
        val parts = mutableListOf<String>()
        val c = code.trim()
        if (c.isNotBlank()) {
            if (c.contains('.')) {
                parts += "code_ocp=eq.${enc(c)}"
            } else {
                parts += "or=(code_sap.eq.${enc(c)},code_ocp.eq.${enc(c)})"
            }
        }
        val d = designation.trim()
        if (d.isNotBlank()) {
            parts += "description=ilike.*${enc(d)}*"
        }
        val desc = descriptif.trim()
        if (desc.isNotBlank()) {
            parts += "descriptif=ilike.*${enc(desc)}*"
        }
        val f = famille.trim()
        if (f.isNotBlank()) {
            parts += "famille=eq.${enc(f)}"
        }
        if (parts.isEmpty()) return@withContext emptyList()
        val q = parts.joinToString("&") + "&select=*&limit=100"
        try {
            parseOrg(get("Mm03", q))
        } catch (e: Exception) {
            // Si colonne famille absente, retenter sans ce filtre
            if (f.isNotBlank() && parts.any { it.startsWith("famille=") }) {
                val withoutFamille = parts.filterNot { it.startsWith("famille=") }
                if (withoutFamille.isEmpty()) return@withContext emptyList()
                parseOrg(get("Mm03", withoutFamille.joinToString("&") + "&select=*&limit=100"))
            } else {
                throw e
            }
        }
    }

    suspend fun organizationsByCode(code: String): List<OrgRow> =
        organizationsSearch(code = code)

    suspend fun organizationsByDescriptif(search: String): List<OrgRow> =
        organizationsSearch(descriptif = search)

    suspend fun organizations(search: String): List<OrgRow> {
        val t = search.trim()
        return if (t.any { it.isLetter() }) organizationsSearch(descriptif = t)
        else organizationsSearch(code = t)
    }

    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }

    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) {
            for (i in 0 until page.length()) {
                page.getJSONObject(i).optString("code_sap").trim()
                    .takeIf { it.isNotEmpty() }?.let(codes::add)
            }
        }
        codes.size
    }

    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        var total = BigDecimal.ZERO
        for (page in pagedValues("valeur_stock")) {
            for (i in 0 until page.length()) {
                total = total.add(
                    page.getJSONObject(i).optString("valeur_stock", "0")
                        .toBigDecimalOrNull() ?: BigDecimal.ZERO
                )
            }
        }
        formatMoney(total)
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun parseStocks(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            StockRow(
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("magasin"), o.optString("division"), o.optString("bin"), o.optString("quantite"),
                o.optString("unite"), o.optString("prix_unitaire"), o.optString("valeur_stock"),
                o.optString("devise"), o.optString("date_em"), o.optString("derniere_sortie")
            )
        }
    }

    private fun parseMovements(s: String) = JSONArray(s).let { a ->
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            fun str(vararg keys: String): String {
                for (k in keys) {
                    if (o.has(k) && !o.isNull(k)) {
                        val v = o.opt(k)?.toString()?.trim().orEmpty()
                        if (v.isNotEmpty() && v != "null") return v
                    }
                }
                return ""
            }
            MovementRow(
                sap = str("code_sap", "Code SAP", "codeSAP", "matnr", "Material"),
                ocp = str("code_ocp", "Code OCP", "codeOCP", "ocp"),
                designation = str("designation", "Designation", "maktx", "Material Description"),
                magasin = str("magasin", "Magasin", "lgort", "Storage Location", "storage_location"),
                quantite = str("quantite", "Quantite", "quantity", "menge", "qty"),
                unite = str("unite", "Unite", "meins", "unit", "uom"),
                montant = str("montant_di", "montant", "Montant", "dmbtr", "amount", "valeur", "amount_lc"),
                codeMouvement = str("code_mouvement", "Code mouvement", "bwart", "movement_type", "type_mouvement"),
                ordre = str("ordre", "Ordre", "aufnr", "order", "order_number"),
                reservation = str("reservation", "Reservation", "rsnum", "réservation"),
                po = str("po", "PO", "ebeln", "purchase_order", "commande"),
                docArticle = str("doc_article", "Doc article", "mblnr", "material_document", "numero_document", "doc"),
                date = str("date", "Date", "budat", "date_mouvement", "posting_date"),
                partenaire = str("partenaire", "Partenaire", "division", "ol", "OL")
            )
        }
    }

    private fun parseOrg(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            fun str(vararg keys: String): String {
                for (k in keys) {
                    if (o.has(k) && !o.isNull(k)) {
                        val v = o.opt(k)?.toString()?.trim().orEmpty()
                        if (v.isNotEmpty() && v != "null") return v
                    }
                }
                return ""
            }
            OrgRow(
                sap = str("code_sap", "code_article"),
                ocp = str("code_ocp"),
                designation = str("description", "designation"),
                descriptif = str("descriptif"),
                famille = str("famille", "Famille")
            )
        }
    }
}

private fun formatMoney(value: BigDecimal): String =
    NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
        isGroupingUsed = true
    }.format(value)

private fun formatMoney(raw: String, currency: String): String =
    "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"

private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 3
        isGroupingUsed = true
    }.format(n)
}

private fun dash(s: String): String = if (s.isBlank()) "—" else s

private fun formatCodeNum(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return d.stripTrailingZeros().toPlainString()
}

/** Code OCP : toujours 5 décimales (ex. 10073.00500) */
private fun formatOcp(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return d.setScale(5, java.math.RoundingMode.HALF_UP).toPlainString()
}


private fun copyToClipboard(context: Context, label: String, value: String, toastMsg: String) {
    if (value.isBlank()) return
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, value))
    Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CopyableCodeLine(
    text: String,
    codeValue: String,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit = 14.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val toast = LocalAppStrings.current.codeCopied
    Text(
        text,
        fontSize = fontSize,
        fontWeight = fontWeight,
        color = color,
        lineHeight = 18.sp,
        modifier = modifier.combinedClickable(
            onClick = {},
            onLongClick = { copyToClipboard(context, "code", codeValue, toast) }
        )
    )
}


/** Code SAP : entier si possible */
private fun formatSap(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return if (d.stripTrailingZeros().scale() <= 0)
        d.toBigInteger().toString()
    else
        d.stripTrailingZeros().toPlainString()
}

private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 ->
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10)
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else
            SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) {
        raw
    }
}


@Composable
private fun LoginScreen(api: SupabaseClient, onSuccess: (String) -> Unit) {
    val c = LocalMobiColors.current
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()

    val s = LocalAppStrings.current
    fun tryLogin() {
        keyboard?.hide()
        if (user.trim().isEmpty() || pass.isEmpty()) {
            error = s.enterCredentials
            return
        }
        scope.launch {
            loading = true
            error = null
            runCatching { api.login(user.trim(), pass) }
                .onSuccess { ok ->
                    if (ok) onSuccess(user.trim())
                    else error = s.wrongCredentials
                }
                .onFailure { error = friendlyError(it.message, s) }
            loading = false
        }
    }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(HeaderGreen)
                    .padding(vertical = 28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "JORF FERTILIZERS COMPANY I",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "MobiStock",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 28.dp)
                    .padding(top = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    s.login,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.textPrimary
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Saisissez vos identifiants",
                    fontSize = 14.sp,
                    color = c.textSecondary
                )
                Spacer(Modifier.height(28.dp))
                OutlinedTextField(
                    value = user,
                    onValueChange = { user = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            s.identifier,
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = c.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary
                    )
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = pass,
                    onValueChange = { pass = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            s.password,
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) {
                                    Icons.Default.Visibility
                                } else {
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = if (passwordVisible) {
                                    "Masquer le mot de passe"
                                } else {
                                    "Afficher le mot de passe"
                                },
                                tint = c.textSecondary
                            )
                        }
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = c.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { tryLogin() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary
                    )
                )
                if (error != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        error!!,
                        color = Color(0xFFDC2626),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { tryLogin() },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HeaderGreen)
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            s.connect,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun App(
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    lang: String,
    onLangChange: (String) -> Unit,
    onLogout: () -> Unit = {}
) {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    val c = LocalMobiColors.current
    val prefs = remember { context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE) }
    val s = LocalAppStrings.current
    // Session 1h20 : déconnexion même si l'app reste ouverte (toutes les 60 s)
    // force_logout Supabase : aussi vérifié dans la même boucle
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(60_000)
            val loginAt = prefs.getLong(PrefLoginAt, 0L)
            if (loginAt > 0L && System.currentTimeMillis() - loginAt >= SESSION_MAX_MS) {
                onLogout()
                continue
            }
            val user = prefs.getString(PrefLoginUser, "") ?: ""
            if (user.isNotBlank()) {
                runCatching { api.shouldForceLogout(user) }
                    .onSuccess { force -> if (force) onLogout() }
            }
        }
    }
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }
    var movementRows by remember { mutableStateOf<List<MovementRow>?>(null) }
    var orgRows by remember { mutableStateOf<List<OrgRow>?>(null) }
    var subScreen by remember { mutableStateOf<String?>(null) }

    // Stats globales — chargées UNE SEULE FOIS pour toute la session
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    var statsLoaded by remember { mutableStateOf(false) }
    var statsLoading by remember { mutableStateOf(false) }
    var statsError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (!statsLoaded) {
            statsLoading = true
            runCatching {
                articleCount = api.articleCount().toString()
                stockValue = api.stockValue()
                statsLoaded = true
            }.onFailure { statsError = friendlyError(it.message, s) }
            statsLoading = false
        }
    }

    if (stockRows != null) {
        StockResultPage(
            rows = stockRows!!,
            onBack = { stockRows = null },
            onHome = { stockRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (movementRows != null) {
        MovementResultPage(
            rows = movementRows!!,
            onBack = { movementRows = null },
            onHome = { movementRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "movement") {
        MovementSearchPage(
            api = api,
            onBack = { subScreen = null },
            onResult = { movementRows = it }
        )
        return
    }
    if (orgRows != null) {
        OrgResultPage(
            rows = orgRows!!,
            onBack = { orgRows = null },
            onHome = { orgRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "org") {
        OrgSearchPage(
            api = api,
            onBack = { subScreen = null },
            onResult = { orgRows = it }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        if (page == 1) {
            SettingsPage(api, isDark = isDark, onThemeChange = onThemeChange, lang = lang, onLangChange = onLangChange, onLogout = onLogout)
        } else {
            HomePage(
                api = api,
                articleCount = articleCount,
                stockValue = stockValue,
                statsLoading = statsLoading,
                onStockResult = { stockRows = it },
                onOpenMovement = { subScreen = "movement" },
                onOpenOrg = { subScreen = "org" }
            )
        }
        BottomNavigationBar(
            page = page,
            onPage = { page = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    statsError?.let { msg ->
        AppDialog(msg) { statsError = null }
    }
}

@Composable
private fun HomePage(
    api: SupabaseClient,
    articleCount: String,
    stockValue: String,
    statsLoading: Boolean,
    onStockResult: (List<StockRow>) -> Unit,
    onOpenMovement: () -> Unit,
    onOpenOrg: () -> Unit
) {
    val strings = LocalAppStrings.current
    var stock by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Surface(modifier = Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Header()
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SummaryCard(
                            title = "Nombre d'articles",
                            value = articleCount,
                            subtitle = "Articles en stock",
                            accent = Green,
                            icon = Icons.Default.Inventory2,
                            modifier = Modifier.weight(1f)
                        )
                        SummaryCard(
                            title = "Valeur de stock",
                            value = stockValue,
                            subtitle = "MAD",
                            accent = Blue,
                            icon = Icons.Default.AccountBalance,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    StockSearchBlock(
                        value = stock,
                        onValueChange = { stock = codeFilter(it) },
                        onSearch = {
                            keyboard?.hide()
                            val e = validate(stock)
                            if (e != null) dialog = e
                            else scope.launch {
                                loading = true
                                runCatching { api.stocks(stock.trim()) }
                                    .onSuccess { r ->
                                        if (r.isEmpty())
                                            dialog = "Aucun stock disponible pour cet article"
                                        else onStockResult(r)
                                    }
                                    .onFailure { dialog = friendlyError(it.message, strings) }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(20.dp))
                }
                item {
                    ModuleNavButton(
                        title = "Mouvement matière",
                        subtitle = LocalAppStrings.current.movementHistory,
                        emoji = "🔄",
                        accent = Blue,
                        background = BlueSoft,
                        onClick = onOpenMovement
                    )
                    Spacer(Modifier.height(12.dp))
                }
                item {
                    ModuleNavButton(
                        title = "Article d'organisation",
                        subtitle = LocalAppStrings.current.orgSearchHint,
                        emoji = "🏢",
                        accent = Purple,
                        background = PurpleSoft,
                        onClick = onOpenOrg
                    )
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    Text(
                        "Work with love",
                        Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        color = LocalMobiColors.current.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Overlay uniquement pour les recherches, PAS pour les stats (déjà en cache)
    LoadingOverlay(loading)
    // Petit indicateur discret si stats encore en cours au 1er lancement
    if (statsLoading && !loading) {
        Box(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            contentAlignment = Alignment.Center
        ) { /* stats en arrière-plan, pas de popup bloquant */ }
    }
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun StockSearchBlock(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit
) {
    val strings = LocalAppStrings.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Green),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📦", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "SYNTHÈSE DES STOCKS",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary
                    )
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    placeholder = {
                        Text(
                            "Saisir Code SAP ou Code OCP",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.surfaceBg,
                        unfocusedContainerColor = LocalMobiColors.current.surfaceBg,
                        cursorColor = Green,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onSearch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    elevation = ButtonDefaults.buttonElevation(0.dp)
                ) {
                    Text("🔍", fontSize = 15.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "RECHERCHER",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    strings.searchBySapOcp,
                    fontSize = 12.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Green)
            )
        }
    }
}

@Composable
private fun ModuleNavButton(
    title: String,
    subtitle: String,
    emoji: String,
    accent: Color,
    background: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(emoji, fontSize = 18.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title.uppercase(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        subtitle,
                        fontSize = 12.sp,
                        color = LocalMobiColors.current.textSecondary
                    )
                }
                Text("→", fontSize = 18.sp, color = accent, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accent)
            )
        }
    }
}

@Composable
private fun MovementSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit,
    onResult: (List<MovementRow>) -> Unit
) {
    val strings = LocalAppStrings.current
    var code by remember { mutableStateOf("") }
    var filterMagasin by remember { mutableStateOf("") }
    var filterCodeMvt by remember { mutableStateOf("") }
    var filterDateFrom by remember { mutableStateOf("") }
    var filterDateTo by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var conso2025 by remember { mutableStateOf("—") }
    var conso2026 by remember { mutableStateOf("—") }
    var consoDate2025 by remember { mutableStateOf("—") }
    var consoDate2026 by remember { mutableStateOf("—") }
    var consoLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        consoLoading = true
        runCatching { api.consumptionByYear() }
            .onSuccess { stats ->
                conso2025 = stats.amount2025
                conso2026 = stats.amount2026
                consoDate2025 = stats.lastDate2025
                consoDate2026 = stats.lastDate2026
            }
            .onFailure {
                conso2025 = "—"
                conso2026 = "—"
                consoDate2025 = "—"
                consoDate2026 = "—"
            }
        consoLoading = false
    }

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }
    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    fun doSearch() {
        keyboard?.hide()
        val e = validate(code)
        if (e != null) dialog = e
        else scope.launch {
            loading = true
            runCatching {
                api.movements(
                    code = code.trim(),
                    magasin = filterMagasin,
                    codeMouvement = filterCodeMvt,
                    dateFrom = filterDateFrom,
                    dateTo = filterDateTo
                )
            }
                .onSuccess { r ->
                    if (r.isEmpty()) dialog = "Aucun mouvement trouvé pour cet article."
                    else onResult(r)
                }
                .onFailure { dialog = friendlyError(it.message, strings) }
            loading = false
        }
    }

    val baseScheme = MaterialTheme.colorScheme
    MaterialTheme(colorScheme = baseScheme.copy(primary = Blue, primaryContainer = Blue)) {
    CompositionLocalProvider(
        LocalTextSelectionColors provides TextSelectionColors(
            handleColor = Blue,
            backgroundColor = Blue.copy(alpha = 0.35f)
        )
    ) {
    Surface(Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvement matière",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Blue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🔄", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Mouvement matière",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Blue
                    )
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Saisir Code SAP ou Code OCP",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = filterMagasin,
                    onValueChange = { filterMagasin = it.uppercase().take(10) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Magasin (ex. MC01)",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = filterCodeMvt,
                    onValueChange = { filterCodeMvt = it.filter { ch -> ch.isDigit() }.take(4) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Code mouvement (ex. 261)",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = filterDateFrom,
                        onValueChange = { filterDateFrom = it.take(10) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        placeholder = {
                            Text(
                                "Du (JJ.MM.AAAA)",
                                color = LocalMobiColors.current.textMuted,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalMobiColors.current.textPrimary,
                            textAlign = TextAlign.Center
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue,
                            unfocusedBorderColor = LocalMobiColors.current.border,
                            focusedContainerColor = LocalMobiColors.current.cardSurface,
                            unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                            cursorColor = Blue,
                            focusedTextColor = LocalMobiColors.current.textPrimary,
                            unfocusedTextColor = LocalMobiColors.current.textPrimary
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = filterDateTo,
                        onValueChange = { filterDateTo = it.take(10) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        placeholder = {
                            Text(
                                "Au (JJ.MM.AAAA)",
                                color = LocalMobiColors.current.textMuted,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalMobiColors.current.textPrimary,
                            textAlign = TextAlign.Center
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue,
                            unfocusedBorderColor = LocalMobiColors.current.border,
                            focusedContainerColor = LocalMobiColors.current.cardSurface,
                            unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                            cursorColor = Blue,
                            focusedTextColor = LocalMobiColors.current.textPrimary,
                            unfocusedTextColor = LocalMobiColors.current.textPrimary
                        )
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    strings.searchBySapOcp,
                    fontSize = 13.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
                Spacer(Modifier.height(24.dp))
                Text(
                    "Tableau de bord",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Blue
                )
                Spacer(Modifier.height(12.dp))
                if (consoLoading) {
                    Text(
                        "Chargement…",
                        fontSize = 14.sp,
                        color = LocalMobiColors.current.textMuted,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                } else {
                    Row(Modifier.fillMaxWidth()) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(Color(0xFFE8F1FF)),
                            elevation = CardDefaults.cardElevation(0.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(
                                    "💰",
                                    fontSize = 18.sp
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Consommation 2025",
                                    fontSize = 12.sp,
                                    color = Color(0xFF3B6EA5)
                                )
                                Text(
                                    "MAJ : $consoDate2025",
                                    fontSize = 11.sp,
                                    color = LocalMobiColors.current.textMuted
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    conso2025,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Blue,
                                    maxLines = 2
                                )
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(Color(0xFFE8F1FF)),
                            elevation = CardDefaults.cardElevation(0.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(
                                    "💰",
                                    fontSize = 18.sp
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Consommation 2026",
                                    fontSize = 12.sp,
                                    color = Color(0xFF3B6EA5)
                                )
                                Text(
                                    "MAJ : $consoDate2026",
                                    fontSize = 11.sp,
                                    color = LocalMobiColors.current.textMuted
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    conso2026,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Blue,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg, accent = Blue) { dialog = null } }
}

@Composable
private fun OrgSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit,
    onResult: (List<OrgRow>) -> Unit
) {
    val s = LocalAppStrings.current
    var code by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var descriptif by remember { mutableStateOf("") }
    var famille by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun doSearch() {
        keyboard?.hide()
        val c = code.trim()
        val d = designation.trim()
        val desc = descriptif.trim()
        val f = famille.trim()
        if (c.isBlank() && d.isBlank() && desc.isBlank() && f.isBlank()) {
            dialog = "Veuillez saisir au moins un critère de recherche."
            return
        }
        scope.launch {
            loading = true
            runCatching {
                api.organizationsSearch(
                    code = c,
                    designation = d,
                    descriptif = desc,
                    famille = f
                )
            }.onSuccess { r ->
                if (r.isEmpty()) {
                    dialog = s.noOrg
                } else {
                    onResult(r)
                }
            }.onFailure { dialog = friendlyError(it.message, s) }
            loading = false
        }
    }

    val baseScheme = MaterialTheme.colorScheme
    MaterialTheme(colorScheme = baseScheme.copy(primary = Purple, primaryContainer = Purple)) {
    CompositionLocalProvider(
        LocalTextSelectionColors provides TextSelectionColors(
            handleColor = Purple,
            backgroundColor = Purple.copy(alpha = 0.35f)
        )
    ) {
    Surface(Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Purple)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Article d'organisation",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Purple),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🏢", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Article d'organisation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple
                    )
                }
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. 10067.05422",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )

                Spacer(Modifier.height(14.dp))

                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. MANCHON COMPENSATEUR",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )

                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = descriptif,
                    onValueChange = { descriptif = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. descriptif technique",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = famille,
                    onValueChange = { raw ->
                        famille = raw.filter { it.isDigit() }.take(5)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. 12345",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Combinez un ou plusieurs critères (code, désignation, descriptif, famille).",
                    fontSize = 13.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg, accent = Purple) { dialog = null } }
}

@Composable
private fun LoadingOverlay(loading: Boolean) {
    if (!loading) return
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Green, strokeWidth = 3.dp)
                Spacer(Modifier.height(12.dp))
                Text(LocalAppStrings.current.loading, color = LocalMobiColors.current.textPrimary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun AppDialog(msg: String, accent: Color = Green, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        containerColor = LocalMobiColors.current.cardSurface,
        title = {
            Text(
                "MobiStock",
                fontWeight = FontWeight.Bold,
                color = accent,
                fontSize = 18.sp
            )
        },
        text = {
            Text(msg, color = LocalMobiColors.current.textPrimary, fontSize = 14.sp, lineHeight = 20.sp)
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = accent),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("OK", fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
private fun StockResultPage(
    rows: List<StockRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.qty.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val totalValue = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.valeur.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val currency = first?.devise?.takeIf { it.isNotBlank() } ?: "MAD"
    val WaGreen = Green

    Surface(modifier = Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    LocalAppStrings.current.stockDetail,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        CopyableCodeLine(
                            text = "Code SAP : ${formatSap(first.sap)}",
                            codeValue = formatSap(first.sap),
                            color = LocalMobiColors.current.textPrimary
                        )
                        CopyableCodeLine(
                            text = "Code OCP : ${formatOcp(first.ocp)}",
                            codeValue = formatOcp(first.ocp),
                            color = LocalMobiColors.current.textPrimary
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    StockDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item {
                    Spacer(Modifier.height(6.dp))
                    HorizontalDivider(color = LocalMobiColors.current.border, thickness = 1.dp)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📦", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "TOTAL EN STOCK : ${formatQty(totalQty.toPlainString())}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💰", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "VALEUR GLOBALE : ${formatMoney(totalValue)} $currency",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun StockDetailBlock(row: StockRow, showDivider: Boolean) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${dash(row.magasin)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
            if (row.division.isNotBlank()) {
                Spacer(Modifier.width(14.dp))
                Text("🏭", fontSize = 16.sp)
                Spacer(Modifier.width(4.dp))
                Text(
                    "OL : ${row.division}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalMobiColors.current.textPrimary
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📍", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "BIN : ${dash(row.emplacement)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
        }
        Spacer(Modifier.height(2.dp))
        val devise = row.devise.ifBlank { "MAD" }
        val qtyText = "Quantité : ${formatQty(row.qty)} ${row.unite}"
        val puText = "Prix unitaire : ${formatMoney(row.pu, devise)}"
        val valText = "Valeur : ${formatMoney(row.valeur, devise)}"
        val emText = "Date EM : ${formatDate(row.dateEm)}"
        val outText = "Dernière sortie : ${formatDate(row.derniereSortie)}"
        Text(qtyText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(puText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(valText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(emText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(outText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        if (showDivider) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = LocalMobiColors.current.border, thickness = 1.dp)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun StockCard(row: StockRow, index: Int) {
    StockDetailBlock(row, showDivider = false)
}

@Composable
private fun StockField(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, color = LocalMobiColors.current.textSecondary, modifier = Modifier.width(110.dp))
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = LocalMobiColors.current.textPrimary,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CodeChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "$label : ",
                fontSize = 11.sp,
                color = LocalMobiColors.current.textSecondary,
                fontWeight = FontWeight.Medium
            )
            Text(
                value.ifBlank { "—" },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
        }
    }
}

@Composable
private fun MovementResultPage(
    rows: List<MovementRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val c = LocalMobiColors.current

    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvements matière",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                // En-tête unique : désignation + SAP / OCP
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(2.dp))
                        Row(Modifier.fillMaxWidth()) {
                            CopyableCodeLine(
                                text = "Code SAP : ${formatSap(first.sap)}",
                                codeValue = formatSap(first.sap),
                                color = c.textPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            CopyableCodeLine(
                                text = "Code OCP : ${formatOcp(first.ocp)}",
                                codeValue = formatOcp(first.ocp),
                                color = c.textPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = c.border, thickness = 1.dp)
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    MovementDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun MovementDetailBlock(row: MovementRow, showDivider: Boolean) {
    val c = LocalMobiColors.current
    val qtyNum = row.quantite.replace(" ", "").replace(",", ".").toBigDecimalOrNull()
    val isPositive = qtyNum != null && qtyNum > java.math.BigDecimal.ZERO
    val accent = if (isPositive) Blue else c.textPrimary
    val qtyLabel = buildString {
        append(formatQty(row.quantite))
        if (row.unite.isNotBlank()) {
            append(' ')
            append(row.unite)
        }
    }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${dash(row.magasin)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = accent,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Quantité : ${dash(qtyLabel)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = accent
            )
        }
        Spacer(Modifier.height(4.dp))
        val montantText = when {
            row.montant.isBlank() -> "—"
            row.montant.toBigDecimalOrNull() != null -> formatMoney(row.montant.toBigDecimal())
            else -> row.montant
        }
        Text(
            "Montant : $montantText",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Text(
            "Code mouvement : ${dash(row.codeMouvement)}",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                "Ordre : ${dash(row.ordre)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Réservation : ${dash(row.reservation)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
        }
        Text(
            "PO : ${dash(row.po)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                "Doc article : ${dash(row.docArticle)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Date : ${formatDate(row.date)}",
                fontSize = 14.sp,
                color = c.textPrimary
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏭", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "OL : ${dash(row.partenaire)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary
            )
        }
        if (showDivider) {
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = c.border, thickness = 1.dp)
            Spacer(Modifier.height(12.dp))
        }
    }
}


@Composable
private fun OrgResultPage(
    rows: List<OrgRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val c = LocalMobiColors.current
    val s = LocalAppStrings.current
    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Purple)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    s.orgArticle,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = s.home,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                itemsIndexed(rows) { index, row ->
                    Column(Modifier.fillMaxWidth()) {
                        // Désignation en haut, couleur barre de recherche, un peu plus grande
                        Text(
                            row.designation.ifBlank { "—" },
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Purple,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        // Codes SAP / OCP lisibles, gras, noir
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            CopyableCodeLine(
                                text = "Code SAP : ${formatSap(row.sap)}",
                                codeValue = formatSap(row.sap),
                                color = c.textPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(12.dp))
                            CopyableCodeLine(
                                text = "Code OCP : ${formatOcp(row.ocp)}",
                                codeValue = formatOcp(row.ocp),
                                color = c.textPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        // Descriptif inchangé
                        Text(
                            "📌  Descriptif : ${row.descriptif.ifBlank { "—" }}",
                            fontSize = 14.sp,
                            color = c.textPrimary,
                            lineHeight = 18.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (index < rows.lastIndex) {
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider(color = c.border, thickness = 1.dp)
                            Spacer(Modifier.height(12.dp))
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun SummaryLine(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = LocalMobiColors.current.textSecondary, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
    }
}

@Composable
private fun Header() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(HeaderGreen)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "JORF FERTILIZERS COMPANY I",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.5.sp
            )
            Text(
                "MobiStock",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD))
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Bonjour,",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GreenDark
                )
                Text(
                    "Bienvenue sur MobiStock",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalMobiColors.current.textPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Consultez et gérez vos stocks et mouvements en temps réel.",
                    fontSize = 11.sp,
                    color = LocalMobiColors.current.textSecondary,
                    lineHeight = 15.sp
                )
            }
            Icon(
                Icons.Default.Business,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color(0x6675A98A)
            )
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LocalMobiColors.current.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        value,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        subtitle,
                        fontSize = 10.sp,
                        color = LocalMobiColors.current.textMuted
                    )
                }
            }
            // bande colorée en bas
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accent)
            )
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    subtitle: String,
    accent: Color,
    background: Color,
    icon: ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    organisation: Boolean,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                    Text(
                        subtitle,
                        fontSize = 11.sp,
                        color = LocalMobiColors.current.textSecondary
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            placeholder,
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = LocalMobiColors.current.textPrimary
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = accent
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Rechercher",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(
    api: SupabaseClient,
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    lang: String,
    onLangChange: (String) -> Unit,
    onLogout: () -> Unit = {}
) {
    val c = LocalMobiColors.current
    val s = LocalAppStrings.current
    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .padding(top = 24.dp, bottom = 80.dp)
        ) {
            Text(
                s.settings,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary
            )
            Spacer(Modifier.height(24.dp))
            Text(
                s.appearance,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.textSecondary
            )
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(c.cardSurface),
                border = BorderStroke(1.dp, c.border)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.darkMode,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.textPrimary
                            )
                            Text(
                                s.darkModeDesc,
                                fontSize = 12.sp,
                                color = c.textSecondary
                            )
                        }
                        Switch(
                            checked = isDark,
                            onCheckedChange = { onThemeChange(true) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                    HorizontalDivider(color = c.border, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.lightMode,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.textPrimary
                            )
                            Text(
                                s.lightModeDesc,
                                fontSize = 12.sp,
                                color = c.textSecondary
                            )
                        }
                        Switch(
                            checked = !isDark,
                            onCheckedChange = { onThemeChange(false) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text(
                s.language,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.textSecondary
            )
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(c.cardSurface),
                border = BorderStroke(1.dp, c.border)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            s.french,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = c.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = lang == "fr",
                            onCheckedChange = { if (it) onLangChange("fr") },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                    HorizontalDivider(color = c.border, thickness = 1.dp, modifier = Modifier.padding(vertical = 6.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            s.english,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = c.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = lang == "en",
                            onCheckedChange = { if (it) onLangChange("en") },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HeaderGreen)
            ) {
                Text(s.logout, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Text("MobiStock 1.0 développé par LEMMAA", color = c.textSecondary, fontSize = 14.sp)
        }
    }
}

@Composable
private fun BottomNavigationBar(
    page: Int,
    onPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = LocalMobiColors.current.cardSurface,
        shadowElevation = 8.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            NavigationItem(
                icon = Icons.Default.Home,
                label = LocalAppStrings.current.home,
                active = page == 0,
                onClick = { onPage(0) }
            )
            NavigationItem(
                icon = Icons.Default.Settings,
                label = LocalAppStrings.current.settings,
                active = page == 1,
                onClick = { onPage(1) }
            )
        }
    }
}

@Composable
private fun NavigationItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val color = if (active) Green else LocalMobiColors.current.textMuted
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(120.dp)
            .padding(vertical = 2.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(24.dp))
        }
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = color
        )
        Spacer(Modifier.height(3.dp))
        Box(
            Modifier
                .width(if (active) 28.dp else 0.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(if (active) Green else Color.Transparent)
        )
    }
}
