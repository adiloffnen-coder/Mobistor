package com.ocp.consultationstocks

import android.content.Context
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val GreenLight = Color(0xFFF5FCF8)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val GreyLight = Color(0xFF8A9BA5)
private val Border = Color(0xFFD5E5E0)
private val CardBg = Color(0xFFFFFFFF)
private val SurfaceBg = Color(0xFFF7FAF9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { MobiTheme { App() } }
    }
}

@Composable
private fun MobiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            background = Color.White,
            surface = Color.White,
            onSurface = TextDark,
            onPrimary = Color.White
        ),
        content = content
    )
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)

private data class MovementRow(
    val date: String, val type: String, val sap: String, val ocp: String,
    val designation: String, val qty: String, val unite: String, val source: String,
    val destination: String, val doc: String, val valeur: String
)

private data class OrgRow(
    val code: String, val designation: String, val unite: String,
    val groupe: String, val organisation: String
)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path: String, query: String): String {
        val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("apikey", key)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
        return body
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }

    suspend fun movements(code: String): List<MovementRow> = withContext(Dispatchers.IO) {
        val q = "select=date_mouvement,type_mouvement,code_sap,code_ocp,designation,quantite,unite,magasin_source,magasin_destination,numero_document,valeur&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&order=date_mouvement.desc&limit=100"
        parseMovements(get("mouvements", q))
    }

    suspend fun organizations(search: String): List<OrgRow> = withContext(Dispatchers.IO) {
        val s = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation&or=(code_article.ilike.*$s*,designation.ilike.*$s*)&limit=100"
        parseOrg(get("articles_organisation", q))
    }

    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }

    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) {
            for (i in 0 until page.length()) {
                page.getJSONObject(i).optString("code_sap").trim()
                    .takeIf { it.isNotEmpty() }?.let(codes::add)
            }
        }
        codes.size
    }

    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        var total = BigDecimal.ZERO
        for (page in pagedValues("valeur_stock")) {
            for (i in 0 until page.length()) {
                total = total.add(
                    page.getJSONObject(i).optString("valeur_stock", "0")
                        .toBigDecimalOrNull() ?: BigDecimal.ZERO
                )
            }
        }
        formatMoney(total)
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun parseStocks(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            StockRow(
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("magasin"), o.optString("bin"), o.optString("quantite"),
                o.optString("unite"), o.optString("prix_unitaire"), o.optString("valeur_stock"),
                o.optString("devise"), o.optString("date_em"), o.optString("derniere_sortie")
            )
        }
    }

    private fun parseMovements(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            MovementRow(
                o.optString("date_mouvement"), o.optString("type_mouvement"),
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("quantite"), o.optString("unite"), o.optString("magasin_source"),
                o.optString("magasin_destination"), o.optString("numero_document"),
                o.optString("valeur")
            )
        }
    }

    private fun parseOrg(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            OrgRow(
                o.optString("code_article"), o.optString("designation"),
                o.optString("unite"), o.optString("groupe"), o.optString("organisation")
            )
        }
    }
}

private fun formatMoney(value: BigDecimal): String =
    NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
        isGroupingUsed = true
    }.format(value)

private fun formatMoney(raw: String, currency: String): String =
    "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"

private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 3
        isGroupingUsed = true
    }.format(n)
}

private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 ->
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10)
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else
            SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) {
        raw
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }
    var movementRows by remember { mutableStateOf<List<MovementRow>?>(null) }

    if (stockRows != null) {
        StockResultPage(
            rows = stockRows!!,
            onBack = { stockRows = null },
            onHome = { stockRows = null; page = 0 }
        )
        return
    }
    if (movementRows != null) {
        MovementResultPage(
            rows = movementRows!!,
            onBack = { movementRows = null },
            onHome = { movementRows = null; page = 0 }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        if (page == 1) {
            SettingsPage(api)
        } else {
            HomePage(
                api = api,
                onStockResult = { stockRows = it },
                onMovementResult = { movementRows = it }
            )
        }
        BottomNavigationBar(
            page = page,
            onPage = { page = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun HomePage(
    api: SupabaseClient,
    onStockResult: (List<StockRow>) -> Unit,
    onMovementResult: (List<MovementRow>) -> Unit
) {
    var stock by remember { mutableStateOf("") }
    var movement by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        loading = true
        runCatching {
            articleCount = api.articleCount().toString()
            stockValue = api.stockValue()
        }.onFailure { dialog = it.message }
        loading = false
    }

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Surface(modifier = Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Header()
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
            ) {
                item {
                    WelcomeBanner()
                    Spacer(Modifier.height(16.dp))
                }
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SummaryCard(
                            title = "Nombre d'articles",
                            value = articleCount,
                            subtitle = "Articles en stock",
                            accent = Green,
                            icon = Icons.Default.Inventory2,
                            modifier = Modifier.weight(1f)
                        )
                        SummaryCard(
                            title = "Valeur de stock",
                            value = stockValue,
                            subtitle = "MAD",
                            accent = Blue,
                            icon = Icons.Default.AccountBalance,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(20.dp))
                }
                item {
                    // Module 1: Synthèse des stocks
                    SearchModule(
                        title = "Synthèse des stocks",
                        subtitle = "Recherche par code SAP ou OCP",
                        accent = Green,
                        background = GreenSoft,
                        icon = Icons.Default.Inventory2,
                        value = stock,
                        onValueChange = { stock = codeFilter(it) },
                        placeholder = "Code SAP ou Code OCP",
                        organisation = false,
                        onSearch = {
                            keyboard?.hide()
                            val e = validate(stock)
                            if (e != null) dialog = e
                            else scope.launch {
                                loading = true
                                runCatching { api.stocks(stock.trim()) }
                                    .onSuccess { r ->
                                        if (r.isEmpty())
                                            dialog = "Aucun stock disponible pour cet article"
                                        else onStockResult(r)
                                    }
                                    .onFailure { dialog = it.message }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(14.dp))
                }
                item {
                    // Module 2: Mouvement matière
                    SearchModule(
                        title = "Mouvement matière",
                        subtitle = "Historique des mouvements",
                        accent = Blue,
                        background = BlueSoft,
                        icon = Icons.Default.SwapHoriz,
                        value = movement,
                        onValueChange = { movement = codeFilter(it) },
                        placeholder = "Code SAP ou Code OCP",
                        organisation = false,
                        onSearch = {
                            keyboard?.hide()
                            val e = validate(movement)
                            if (e != null) dialog = e
                            else scope.launch {
                                loading = true
                                runCatching { api.movements(movement.trim()) }
                                    .onSuccess { r ->
                                        if (r.isEmpty())
                                            dialog = "Aucun mouvement trouvé pour cet article."
                                        else onMovementResult(r)
                                    }
                                    .onFailure { dialog = it.message }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(14.dp))
                }
                item {
                    // Module 3: Article d'organisation (conservé)
                    SearchModule(
                        title = "Article d'organisation",
                        subtitle = "Recherche par code ou désignation",
                        accent = Purple,
                        background = PurpleSoft,
                        icon = Icons.Default.Business,
                        value = org,
                        onValueChange = { org = it },
                        placeholder = "Code article ou Désignation",
                        organisation = true,
                        onSearch = {
                            keyboard?.hide()
                            if (org.trim().isBlank())
                                dialog = "Veuillez saisir un code ou une désignation."
                            else scope.launch {
                                loading = true
                                runCatching { api.organizations(org.trim()) }
                                    .onSuccess { r ->
                                        dialog = if (r.isEmpty())
                                            "Aucun article d'organisation trouvé."
                                        else r.joinToString("\n\n") {
                                            "Code: ${it.code}\n${it.designation}\nUnité: ${it.unite}\nGroupe: ${it.groupe}\nOrganisation: ${it.organisation}"
                                        }
                                    }
                                    .onFailure { dialog = it.message }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    Text(
                        "Work with love ♥",
                        Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        color = GreenDark.copy(alpha = 0.7f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    if (loading) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(Color.White),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(
                    Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = Green, strokeWidth = 3.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("Chargement…", color = TextDark, fontSize = 14.sp)
                }
            }
        }
    }

    dialog?.let { msg ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Text(
                    "MobiStock",
                    fontWeight = FontWeight.Bold,
                    color = GreenDark,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(msg, color = TextDark, fontSize = 14.sp, lineHeight = 20.sp)
            },
            confirmButton = {
                Button(
                    onClick = { dialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("OK", fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun StockResultPage(
    rows: List<StockRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.qty.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val totalValue = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.valeur.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val currency = first?.devise?.takeIf { it.isNotBlank() } ?: "MAD"

    Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Green)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Détail du stock",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" },
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Green,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Code SAP : ${first.sap.ifBlank { "—" }}",
                            fontSize = 14.sp,
                            color = TextDark
                        )
                        Text(
                            "Code OCP : ${first.ocp.ifBlank { "—" }}",
                            fontSize = 14.sp,
                            color = TextDark
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    StockDetailBlock(row, index + 1, showDivider = index < rows.lastIndex)
                }

                item {
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider(color = Border, thickness = 1.dp)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Inventory2,
                            contentDescription = null,
                            tint = Green,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "TOTAL EN STOCK : ${formatQty(totalQty.toPlainString())}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Green
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AttachMoney,
                            contentDescription = null,
                            tint = Green,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "VALEUR GLOBALE : ${formatMoney(totalValue)} $currency",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Green
                        )
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun StockDetailBlock(row: StockRow, index: Int, showDivider: Boolean) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Store,
                contentDescription = null,
                tint = Green,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${row.magasin.ifBlank { "—" }}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.LocationOn,
                contentDescription = null,
                tint = Color(0xFFE53935),
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                "BIN : ${row.emplacement.ifBlank { "—" }}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
        }
        Spacer(Modifier.height(2.dp))
        CompactLine(Icons.Default.Inventory2, Green, "Quantité : ${formatQty(row.qty)} ${row.unite}")
        CompactLine(Icons.Default.Sell, Green, "Prix unitaire : ${formatMoney(row.pu, row.devise.ifBlank { "MAD" })}")
        CompactLine(Icons.Default.MonetizationOn, Green, "Valeur : ${formatMoney(row.valeur, row.devise.ifBlank { "MAD" })}")
        CompactLine(Icons.Default.DateRange, Green, "Date EM : ${formatDate(row.dateEm)}")
        CompactLine(Icons.AutoMirrored.Filled.ExitToApp, Green, "Dernière sortie : ${formatDate(row.derniereSortie)}")
        if (showDivider) {
            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFB7C9C2), thickness = 1.dp)
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun CompactLine(icon: ImageVector, tint: Color, text: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 14.sp, color = TextDark, lineHeight = 18.sp)
    }
}

@Composable
private fun StockCard(row: StockRow, index: Int) {
    // kept for compatibility — unused after redesign
    StockDetailBlock(row, index, showDivider = false)
}

@Composable
private fun StockField(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, color = Grey, modifier = Modifier.width(110.dp))
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextDark,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CodeChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "$label : ",
                fontSize = 11.sp,
                color = Grey,
                fontWeight = FontWeight.Medium
            )
            Text(
                value.ifBlank { "—" },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
        }
    }
}

@Composable
private fun MovementResultPage(
    rows: List<MovementRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Blue)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Text(
                    "Mouvements matière",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                item {
                    Text(
                        "${rows.size} mouvement${if (rows.size > 1) "s" else ""}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Grey,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
                itemsIndexed(rows) { index, row ->
                    MovementCard(row, index + 1)
                    Spacer(Modifier.height(12.dp))
                }
            }

            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Blue)
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text("Retour", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MovementCard(row: MovementRow, index: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(CardBg),
        elevation = CardDefaults.cardElevation(1.dp),
        border = BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Blue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "$index",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        row.type.ifBlank { "Mouvement" },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark
                    )
                    Text(
                        formatDate(row.date),
                        fontSize = 12.sp,
                        color = Grey
                    )
                }
            }
            if (row.designation.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    row.designation,
                    fontSize = 13.sp,
                    color = TextDark,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            HorizontalDivider(
                Modifier.padding(vertical = 10.dp),
                color = Border,
                thickness = 1.dp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CodeChip("SAP", row.sap)
                CodeChip("OCP", row.ocp)
            }
            Spacer(Modifier.height(8.dp))
            StockField(Icons.Default.Inventory2, "Quantité", "${formatQty(row.qty)} ${row.unite}")
            StockField(Icons.Default.Store, "Source", row.source.ifBlank { "—" })
            StockField(Icons.Default.LocalShipping, "Destination", row.destination.ifBlank { "—" })
            StockField(Icons.Default.Description, "Document", row.doc.ifBlank { "—" })
            if (row.valeur.isNotBlank()) {
                StockField(Icons.Default.AttachMoney, "Valeur", row.valeur)
            }
        }
    }
}

@Composable
private fun SummaryLine(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = Grey, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
    }
}

@Composable
private fun Header() {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(GreenSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Eco,
                contentDescription = null,
                tint = Green,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "JORF FERTILIZERS COMPANY I",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = GreenDark.copy(alpha = 0.8f)
            )
            Text(
                "MobiStock",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = GreenDark
            )
            Text(
                "Gestion des stocks & mouvements",
                fontSize = 11.sp,
                color = Grey
            )
        }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD))
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Bonjour,",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GreenDark
                )
                Text(
                    "Bienvenue sur MobiStock",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Consultez et gérez vos stocks et mouvements en temps réel.",
                    fontSize = 11.sp,
                    color = Grey,
                    lineHeight = 15.sp
                )
            }
            Icon(
                Icons.Default.Business,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color(0x6675A98A)
            )
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(CardBg),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f)),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Grey,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    value,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    subtitle,
                    fontSize = 10.sp,
                    color = GreyLight
                )
            }
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    subtitle: String,
    accent: Color,
    background: Color,
    icon: ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    organisation: Boolean,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                    Text(
                        subtitle,
                        fontSize = 11.sp,
                        color = Grey
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            placeholder,
                            color = GreyLight,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextDark
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = accent
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Rechercher",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(api: SupabaseClient) {
    Surface(modifier = Modifier.fillMaxSize(), color = SurfaceBg) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .padding(top = 24.dp, bottom = 80.dp)
        ) {
            Text(
                "Paramètres",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = GreenDark
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "Connexion Supabase",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
            Spacer(Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(GreenSoft),
                border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Green)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Supabase connecté",
                            fontWeight = FontWeight.Bold,
                            color = GreenDark,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Base de données", fontSize = 11.sp, color = Grey)
                    Text(
                        "kbztwijnoyifbmtoanps.supabase.co",
                        fontSize = 13.sp,
                        color = TextDark,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Accès : lecture seule des stocks",
                        fontSize = 12.sp,
                        color = Grey
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("MobiStock 1.2", color = Grey, fontSize = 13.sp)
            Text("JORF FERTILIZERS COMPANY I", color = Grey, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BottomNavigationBar(
    page: Int,
    onPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 8.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            NavigationItem(
                icon = Icons.Default.Home,
                label = "Accueil",
                active = page == 0,
                onClick = { onPage(0) }
            )
            NavigationItem(
                icon = Icons.Default.Settings,
                label = "Paramètres",
                active = page == 1,
                onClick = { onPage(1) }
            )
        }
    }
}

@Composable
private fun NavigationItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val color = if (active) Green else Grey
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(120.dp)
            .padding(vertical = 4.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(24.dp))
        }
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            color = color
        )
        if (active) {
            Spacer(Modifier.height(2.dp))
            Box(
                Modifier
                    .width(40.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Green)
            )
        }
    }
}
