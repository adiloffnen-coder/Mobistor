package com.ocp.consultationstocks

import android.content.Context
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val Border = Color(0xFFD5E5E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { MobiTheme { App() } }
    }
}

@Composable
private fun MobiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Green, background = Color.White, surface = Color.White, onSurface = TextDark),
        content = content
    )
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)
private data class MovementRow(val date:String,val type:String,val sap:String,val ocp:String,val designation:String,val qty:String,val unite:String,val source:String,val destination:String,val doc:String,val valeur:String)
private data class OrgRow(val code:String,val designation:String,val unite:String,val groupe:String,val organisation:String)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path:String, query:String): String {
        val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("apikey", key)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
        return body
    }

    suspend fun stocks(code:String):List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock",q))
    }
    suspend fun movements(code:String):List<MovementRow> = withContext(Dispatchers.IO) {
        val q = "select=date_mouvement,type_mouvement,code_sap,code_ocp,designation,quantite,unite,magasin_source,magasin_destination,numero_document,valeur&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&order=date_mouvement.desc&limit=100"
        parseMovements(get("mouvements",q))
    }
    suspend fun organizations(search:String):List<OrgRow> = withContext(Dispatchers.IO) {
        val s = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation&or=(code_article.ilike.*$s*,designation.ilike.*$s*)&limit=100"
        parseOrg(get("articles_organisation",q))
    }
    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }
    suspend fun articleCount():Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        for (page in pagedValues("code_sap")) for (i in 0 until page.length()) page.getJSONObject(i).optString("code_sap").trim().takeIf { it.isNotEmpty() }?.let(codes::add)
        codes.size
    }
    suspend fun stockValue():String = withContext(Dispatchers.IO) {
        var total=BigDecimal.ZERO
        for (page in pagedValues("valeur_stock")) for (i in 0 until page.length()) total = total.add(page.getJSONObject(i).optString("valeur_stock","0").toBigDecimalOrNull() ?: BigDecimal.ZERO)
        formatMoney(total)
    }
    private fun enc(v:String)=URLEncoder.encode(v,"UTF-8")
    private fun parseStocks(s:String)=JSONArray(s).let { a -> List(a.length()){i-> val o=a.getJSONObject(i); StockRow(o.optString("code_sap"),o.optString("code_ocp"),o.optString("designation"),o.optString("magasin"),o.optString("bin"),o.optString("quantite"),o.optString("unite"),o.optString("prix_unitaire"),o.optString("valeur_stock"),o.optString("devise"),o.optString("date_em"),o.optString("derniere_sortie")) } }
    private fun parseMovements(s:String)=JSONArray(s).let { a -> List(a.length()){i-> val o=a.getJSONObject(i); MovementRow(o.optString("date_mouvement"),o.optString("type_mouvement"),o.optString("code_sap"),o.optString("code_ocp"),o.optString("designation"),o.optString("quantite"),o.optString("unite"),o.optString("magasin_source"),o.optString("magasin_destination"),o.optString("numero_document"),o.optString("valeur")) } }
    private fun parseOrg(s:String)=JSONArray(s).let { a -> List(a.length()){i-> val o=a.getJSONObject(i); OrgRow(o.optString("code_article"),o.optString("designation"),o.optString("unite"),o.optString("groupe"),o.optString("organisation")) } }
}

private fun formatMoney(value: BigDecimal): String = NumberFormat.getNumberInstance(Locale.FRANCE).apply { minimumFractionDigits = 2; maximumFractionDigits = 2; isGroupingUsed = true }.format(value)
private fun formatMoney(raw: String, currency: String): String = "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"
private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply { minimumFractionDigits = 0; maximumFractionDigits = 3; isGroupingUsed = true }.format(n)
}
private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 -> SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10) SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) { raw }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }
    if (stockRows != null) {
        StockResultPage(stockRows!!, onBack = { stockRows = null }, onHome = { stockRows = null; page = 0 })
        return
    }
    if (page == 1) SettingsPage(api) else HomePage(api, onStockResult = { stockRows = it })
    BottomNavigationBar(page) { page = it }
}

@Composable
private fun HomePage(api: SupabaseClient, onStockResult: (List<StockRow>) -> Unit) {
    var stock by remember { mutableStateOf("") }; var movement by remember { mutableStateOf("") }; var org by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }; var loading by remember { mutableStateOf(false) }
    var articleCount by remember { mutableStateOf("—") }; var stockValue by remember { mutableStateOf("—") }
    val scope=rememberCoroutineScope()
    LaunchedEffect(Unit) { loading=true; runCatching { articleCount=api.articleCount().toString(); stockValue=api.stockValue() }.onFailure{dialog=it.message}; loading=false }
    fun codeFilter(s:String)=s.filter{it.isDigit()||it=='.'}.let{ if(it.count{c->c=='.'}<=1) it.take(11) else it.dropLast(1).take(11) }
    fun validate(v:String)=when { v.isBlank()->"Veuillez saisir un code SAP ou un code OCP."; v.length>11->"Le code ne doit pas dépasser 11 caractères."; v.count{it=='.'}>1->"Un seul point (.) est autorisé."; !v.all{it.isDigit()||it=='.'}->"Le code doit être numérique."; else->null }
    Surface(Modifier.fillMaxSize(),Color.White){
        Column(Modifier.fillMaxSize()){
            Header()
            Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp)){
                Spacer(Modifier.height(2.dp)); WelcomeBanner(); Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(7.dp)){SummaryCard("Nombre d’articles",articleCount,"Articles en stock",Green,Icons.Default.Inventory2,Modifier.weight(1f)); SummaryCard("Valeur de stock global",stockValue,"MAD",Blue,Icons.Default.Storage,Modifier.weight(1f))}
                Spacer(Modifier.height(9.dp))
                SearchModule("Synthèse des stocks",Green,GreenSoft,stock,{stock=codeFilter(it)}){ val e=validate(stock); if(e!=null) dialog=e else scope.launch{loading=true; runCatching{api.stocks(stock.trim())}.onSuccess{r->if(r.isEmpty()) dialog="Aucun stock disponible pour cet article." else onStockResult(r)}.onFailure{dialog=it.message}; loading=false} }
                Spacer(Modifier.height(9.dp)); SearchModule("Mouvement matière",Blue,BlueSoft,movement,{movement=codeFilter(it)}){ val e=validate(movement); if(e!=null) dialog=e else scope.launch{loading=true; runCatching{api.movements(movement.trim())}.onSuccess{r->dialog=if(r.isEmpty())"Aucun mouvement trouvé pour cet article." else r.joinToString("\n\n"){ "${it.date} — ${it.type}\nSAP: ${it.sap} / OCP: ${it.ocp}\n${it.designation}\nQté: ${it.qty} ${it.unite}\n${it.source} → ${it.destination}\nDoc: ${it.doc}\nValeur: ${it.valeur}" }}.onFailure{dialog=it.message}; loading=false} }
                Spacer(Modifier.height(9.dp)); SearchModule("Article d’organisation",Purple,PurpleSoft,org,{org=it},true){ if(org.trim().isBlank()) dialog="Veuillez saisir un code ou une désignation." else scope.launch{loading=true; runCatching{api.organizations(org.trim())}.onSuccess{r->dialog=if(r.isEmpty())"Aucun article d’organisation trouvé." else r.joinToString("\n\n"){ "Code: ${it.code}\n${it.designation}\nUnité: ${it.unite}\nGroupe: ${it.groupe}\nOrganisation: ${it.organisation}" }}.onFailure{dialog=it.message}; loading=false} }
                Spacer(Modifier.weight(1f)); Text("Work with love ♥",Modifier.fillMaxWidth().padding(bottom=4.dp),color=GreenDark,fontSize=14.sp,fontWeight=FontWeight.Medium,textAlign=TextAlign.Center)
            }
        }
    }
    if(loading) Box(Modifier.fillMaxSize().background(Color.Black.copy(.08f)),contentAlignment=Alignment.Center){CircularProgressIndicator(color=Green)}
    dialog?.let{msg->AlertDialog(onDismissRequest={dialog=null},title={Text("MobiStock")},text={Text(msg)},confirmButton={TextButton({dialog=null}){Text("OK")}})}
}

@Composable private fun StockResultPage(rows: List<StockRow>, onBack:()->Unit, onHome:()->Unit){
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO){acc,r->acc+(r.qty.toBigDecimalOrNull()?:BigDecimal.ZERO)}
    val totalValue = rows.fold(BigDecimal.ZERO){acc,r->acc+(r.valeur.toBigDecimalOrNull()?:BigDecimal.ZERO)}
    Surface(Modifier.fillMaxSize(),Color.White){
        Column(Modifier.fillMaxSize()){
            Row(Modifier.fillMaxWidth().height(58.dp).background(Green).padding(horizontal=18.dp),verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick=onBack,modifier=Modifier.size(42.dp)){Icon(Icons.Default.ArrowBack,null,tint=Color.White,modifier=Modifier.size(29.dp))}
                Text("Détail du stock",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Color.White,modifier=Modifier.weight(1f))
                IconButton(onClick=onHome,modifier=Modifier.size(42.dp)){Icon(Icons.Default.Home,null,tint=Color.White,modifier=Modifier.size(28.dp))}
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=16.dp),contentPadding=PaddingValues(top=10.dp,bottom=8.dp)){
                item {
                    if(first != null){
                        Text(first.designation,fontSize=21.sp,fontWeight=FontWeight.Bold,color=Green,modifier=Modifier.fillMaxWidth().padding(bottom=7.dp))
                        Text("Code SAP : ${first.sap}",fontSize=14.sp,color=TextDark)
                        Text("Code OCP : ${first.ocp}",fontSize=14.sp,color=TextDark,modifier=Modifier.padding(bottom=9.dp))
                    }
                }
                itemsIndexed(rows){index,row->
                    StockDetailBlock(row)
                    if(index < rows.lastIndex) HorizontalDivider(color=Color(0xFFB7C9C2),thickness=1.dp,modifier=Modifier.padding(vertical=8.dp))
                }
                item {
                    Spacer(Modifier.height(5.dp))
                    SummaryLine(Icons.Default.Inventory2,"TOTAL EN STOCK : ${formatQty(totalQty.toPlainString())}")
                    SummaryLine(Icons.Default.AttachMoney,"VALEUR GLOBALE : ${formatMoney(totalValue)} MAD")
                }
            }
            Button(onClick=onBack,modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp).height(54.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.ArrowBack,null,Modifier.size(25.dp));Spacer(Modifier.width(12.dp));Text("Retour",fontSize=18.sp,fontWeight=FontWeight.Bold)}
        }
    }
}

@Composable private fun StockDetailBlock(row: StockRow){
    DetailLine(Icons.Default.Store,"MAGASIN : ",row.magasin,true)
    DetailLine(Icons.Default.LocationOn,"BIN : ",row.emplacement,true)
    DetailLine(Icons.Default.Inventory2,"Quantité : ","${formatQty(row.qty)} ${row.unite}",true)
    DetailLine(Icons.Default.AttachMoney,"Prix unitaire : ",formatMoney(row.pu,row.devise),true)
    DetailLine(Icons.Default.MonetizationOn,"Valeur : ",formatMoney(row.valeur,row.devise),true)
    DetailLine(Icons.Default.DateRange,"Date EM : ",formatDate(row.dateEm),true)
    DetailLine(Icons.Default.ExitToApp,"Dernière sortie : ",formatDate(row.derniereSortie),true)
}

@Composable private fun DetailLine(icon: ImageVector,label:String,value:String,boldValue:Boolean){
    Row(Modifier.fillMaxWidth().padding(vertical=2.dp),verticalAlignment=Alignment.CenterVertically){
        Icon(icon,null,tint=Green,modifier=Modifier.size(27.dp))
        Spacer(Modifier.width(10.dp))
        Text(label,fontSize=13.sp,color=Grey)
        Text(value,fontSize=13.sp,fontWeight=if(boldValue)FontWeight.Bold else FontWeight.Normal,color=TextDark)
    }
}

@Composable private fun SummaryLine(icon: ImageVector,text:String){
    Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Green,modifier=Modifier.size(34.dp));Spacer(Modifier.width(10.dp));Text(text,fontSize=17.sp,fontWeight=FontWeight.Bold,color=GreenDark)}
}

@Composable private fun Header(){ Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal=12.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(46.dp).clip(RoundedCornerShape(23.dp)).background(GreenSoft),contentAlignment=Alignment.Center){Icon(Icons.Default.Eco,null,tint=Green,modifier=Modifier.size(28.dp))};Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("JORF FERTILIZERS COMPANY I",fontSize=13.sp,fontWeight=FontWeight.Bold,color=GreenDark);Text("MobiStock",fontSize=21.sp,fontWeight=FontWeight.Bold,color=GreenDark);Text("Gestion des stocks & mouvements",fontSize=11.sp,color=Grey)}} }
@Composable private fun WelcomeBanner(){Box(Modifier.fillMaxWidth().height(74.dp).clip(RoundedCornerShape(0.dp,0.dp,22.dp,22.dp)).background(Brush.horizontalGradient(listOf(Color(0xFFF0FBF7),Color(0xFFDDF3EA),Color(0xFFCDEBDD))))){Column(Modifier.padding(start=16.dp,top=10.dp,end=135.dp)){Text("Bonjour,",fontSize=14.sp,fontWeight=FontWeight.Bold,color=GreenDark);Text("Bienvenue sur MobiStock",fontSize=16.sp,fontWeight=FontWeight.Bold,color=TextDark);Spacer(Modifier.height(2.dp));Text("Consultez et gérez vos stocks et mouvements en temps réel.",fontSize=7.sp,color=Grey)};Icon(Icons.Default.Business,null,modifier=Modifier.align(Alignment.CenterEnd).padding(end=18.dp).size(58.dp),tint=Color(0x6675A98A))}}
@Composable private fun SummaryCard(title:String,value:String,subtitle:String,accent:Color,icon:ImageVector,modifier:Modifier){Card(modifier.height(92.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),border=BorderStroke(1.dp,accent.copy(.25f)),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.fillMaxSize().padding(8.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(34.dp).clip(RoundedCornerShape(17.dp)).background(accent),contentAlignment=Alignment.Center){Icon(icon,null,tint=Color.White,modifier=Modifier.size(19.dp))};Spacer(Modifier.width(7.dp));Column{Text(title,fontSize=9.sp,fontWeight=FontWeight.Bold,color=TextDark);Text(value,fontSize=17.sp,fontWeight=FontWeight.Bold,color=TextDark);Text(subtitle,fontSize=8.sp,color=Grey)}}}}
@Composable private fun SearchModule(title:String,accent:Color,background:Color,value:String,onValueChange:(String)->Unit,onSearch:()->Unit,organisation:Boolean=false){Card(Modifier.fillMaxWidth().height(98.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(background),border=BorderStroke(1.dp,accent.copy(.25f)),elevation=CardDefaults.cardElevation(0.dp)){Column(Modifier.padding(horizontal=9.dp,vertical=7.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(accent),contentAlignment=Alignment.Center){Icon(if(organisation)Icons.Default.Business else Icons.Default.Search,null,tint=Color.White,modifier=Modifier.size(18.dp))};Spacer(Modifier.width(8.dp));Text(title,fontSize=14.sp,fontWeight=FontWeight.Bold,color=accent,modifier=Modifier.weight(1f));Icon(Icons.Default.ArrowForwardIos,null,tint=accent,modifier=Modifier.size(15.dp))};Spacer(Modifier.height(4.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(value,onValueChange,Modifier.weight(1f).height(42.dp),singleLine=true,shape=RoundedCornerShape(14.dp),placeholder={Text(if(organisation)"Code article ou Désignation" else "Code SAP ou Code OCP",color=Grey,fontSize=9.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())},textStyle=LocalTextStyle.current.copy(textAlign=TextAlign.Center,fontSize=11.sp),keyboardOptions=KeyboardOptions(keyboardType=if(organisation)KeyboardType.Text else KeyboardType.Decimal),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=accent,unfocusedBorderColor=Border,focusedContainerColor=Color.White,unfocusedContainerColor=Color.White));Button(onSearch,Modifier.width(124.dp).height(42.dp),shape=RoundedCornerShape(14.dp),contentPadding=PaddingValues(horizontal=8.dp),colors=ButtonDefaults.buttonColors(containerColor=accent)){Icon(Icons.Default.Search,null,Modifier.size(20.dp));Spacer(Modifier.width(4.dp));Text("Rechercher",fontSize=9.sp,fontWeight=FontWeight.Bold)}}}}}

@Composable private fun SettingsPage(api:SupabaseClient){Column(Modifier.fillMaxSize().padding(18.dp)){Text("Paramètres",fontSize=26.sp,fontWeight=FontWeight.Bold,color=GreenDark);Spacer(Modifier.height(8.dp));Text("Connexion Supabase",fontSize=18.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(GreenSoft),border=BorderStroke(1.dp,Green.copy(.25f))){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(12.dp).clip(RoundedCornerShape(6.dp)).background(Green));Spacer(Modifier.width(8.dp));Text("Supabase connecté",fontWeight=FontWeight.Bold,color=GreenDark)};Spacer(Modifier.height(12.dp));Text("Base de données",fontSize=11.sp,color=Grey);Text("kbztwijnoyifbmtoanps.supabase.co",fontSize=12.sp,color=TextDark,fontWeight=FontWeight.Medium);Spacer(Modifier.height(8.dp));Text("Accès : lecture seule des stocks",fontSize=11.sp,color=Grey)}};Spacer(Modifier.height(20.dp));Text("MobiStock 1.1",color=Grey);Text("JORF FERTILIZERS COMPANY I",color=Grey)}}

@Composable private fun BottomNavigationBar(page:Int,onPage:(Int)->Unit){Surface(Modifier.fillMaxWidth(),color=Color.White,shadowElevation=4.dp){Row(Modifier.fillMaxWidth().padding(vertical=2.dp),horizontalArrangement=Arrangement.SpaceAround){NavigationItem(Icons.Default.Home,"Accueil",page==0,Green){onPage(0)};NavigationItem(Icons.Default.Settings,"Paramètres",page==1,Grey){onPage(1)}}}}
@Composable private fun NavigationItem(icon:ImageVector,label:String,active:Boolean,color:Color,onClick:()->Unit){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(110.dp).padding(vertical=2.dp)){IconButton(onClick=onClick,modifier=Modifier.size(28.dp)){Icon(icon,null,tint=if(active)Green else color,modifier=Modifier.size(20.dp))};Text(label,fontSize=9.sp,fontWeight=if(active)FontWeight.Bold else FontWeight.Normal,color=if(active)Green else color);if(active)Box(Modifier.width(90.dp).height(2.dp).clip(RoundedCornerShape(2.dp)).background(Green))}}
