package com.ocp.consultationstocks

import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val Border = Color(0xFFD5E5E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { MobiTheme { App() } }
    }
}

@Composable
private fun MobiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            background = Color.White,
            surface = Color.White,
            onSurface = TextDark
        ),
        content = content
    )
}

private data class StockRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val magasin: String,
    val emplacement: String,
    val qty: String,
    val unite: String,
    val pu: String,
    val valeur: String,
    val devise: String
)

private data class MovementRow(
    val date: String,
    val type: String,
    val sap: String,
    val ocp: String,
    val designation: String,
    val qty: String,
    val unite: String,
    val source: String,
    val destination: String,
    val doc: String,
    val valeur: String
)

private data class OrgRow(
    val code: String,
    val designation: String,
    val unite: String,
    val groupe: String,
    val organisation: String
)

private class SupabaseClient(context: Context) {
    private val prefs = context.getSharedPreferences("supabase", Context.MODE_PRIVATE)

    var url: String
        get() = prefs.getString("url", "") ?: ""
        set(value) {
            prefs.edit().putString("url", value.trim().removeSuffix("/")).apply()
        }

    var key: String
        get() = prefs.getString("key", "") ?: ""
        set(value) {
            prefs.edit().putString("key", value.trim()).apply()
        }

    private fun get(path: String, query: String): String {
        if (url.isBlank() || key.isBlank()) {
            throw IllegalStateException("Supabase n'est pas configuré. Ouvrez Paramètres.")
        }

        val connection = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("apikey", key)
        connection.setRequestProperty("Authorization", "Bearer $key")
        connection.setRequestProperty("Accept", "application/json")
        connection.connectTimeout = 15000
        connection.readTimeout = 20000

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        connection.disconnect()

        if (code !in 200..299) {
            throw IllegalStateException("Supabase ($code): $body")
        }
        return body
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,emplacement,quantite,unite,prix_unitaire,valeur_stock,devise" +
                "&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }

    suspend fun movements(code: String): List<MovementRow> = withContext(Dispatchers.IO) {
        val q = "select=date_mouvement,type_mouvement,code_sap,code_ocp,designation,quantite,unite,magasin_source,magasin_destination,numero_document,valeur" +
                "&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&order=date_mouvement.desc&limit=100"
        parseMovements(get("mouvements", q))
    }

    suspend fun organizations(search: String): List<OrgRow> = withContext(Dispatchers.IO) {
        val encoded = enc(search)
        val q = "select=code_article,designation,unite,groupe,organisation" +
                "&or=(code_article.ilike.*$encoded*,designation.ilike.*$encoded*)&limit=100"
        parseOrg(get("articles_organisation", q))
    }

    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val q = "select=code_sap&limit=100000"
        parseStocksCodes(get("stock", q)).toSet().count { it.isNotBlank() }
    }

    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        val q = "select=valeur_stock&limit=100000"
        var total = 0.0
        val array = JSONArray(get("stock", q))
        for (i in 0 until array.length()) {
            total += array.getJSONObject(i).optDouble("valeur_stock", 0.0)
        }
        "%.2f".format(total)
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun parseStocks(value: String): List<StockRow> {
        val array = JSONArray(value)
        return List(array.length()) { index ->
            val obj = array.getJSONObject(index)
            StockRow(
                obj.optString("code_sap"),
                obj.optString("code_ocp"),
                obj.optString("designation"),
                obj.optString("magasin"),
                obj.optString("emplacement"),
                obj.optString("quantite"),
                obj.optString("unite"),
                obj.optString("prix_unitaire"),
                obj.optString("valeur_stock"),
                obj.optString("devise")
            )
        }
    }

    private fun parseMovements(value: String): List<MovementRow> {
        val array = JSONArray(value)
        return List(array.length()) { index ->
            val obj = array.getJSONObject(index)
            MovementRow(
                obj.optString("date_mouvement"),
                obj.optString("type_mouvement"),
                obj.optString("code_sap"),
                obj.optString("code_ocp"),
                obj.optString("designation"),
                obj.optString("quantite"),
                obj.optString("unite"),
                obj.optString("magasin_source"),
                obj.optString("magasin_destination"),
                obj.optString("numero_document"),
                obj.optString("valeur")
            )
        }
    }

    private fun parseOrg(value: String): List<OrgRow> {
        val array = JSONArray(value)
        return List(array.length()) { index ->
            val obj = array.getJSONObject(index)
            OrgRow(
                obj.optString("code_article"),
                obj.optString("designation"),
                obj.optString("unite"),
                obj.optString("groupe"),
                obj.optString("organisation")
            )
        }
    }

    private fun parseStocksCodes(value: String): List<String> {
        val array = JSONArray(value)
        return List(array.length()) { index ->
            array.getJSONObject(index).optString("code_sap")
        }
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    var page by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (page == 1) {
                SettingsPage(api)
            } else {
                HomePage(api)
            }
        }
        BottomNavigationBar(page = page, onPage = { page = it })
    }
}

@Composable
private fun HomePage(api: SupabaseClient) {
    var stock by remember { mutableStateOf("") }
    var movement by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var dialogMessage by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        if (api.url.isNotBlank() && api.key.isNotBlank()) {
            loading = true
            try {
                articleCount = api.articleCount().toString()
                stockValue = api.stockValue()
            } catch (e: Exception) {
                dialogMessage = e.message ?: "Erreur de connexion."
            } finally {
                loading = false
            }
        }
    }

    fun codeFilter(value: String): String {
        var result = value.filter { it.isDigit() || it == '.' }
        if (result.count { it == '.' } > 1) {
            result = result.dropLast(1)
        }
        return result.take(11)
    }

    fun validate(value: String): String? {
        return when {
            value.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
            value.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
            value.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
            !value.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
            else -> null
        }
    }

    fun searchStock() {
        val error = validate(stock)
        if (error != null) {
            dialogMessage = error
            return
        }
        scope.launch {
            loading = true
            try {
                val rows = api.stocks(stock.trim())
                dialogMessage = if (rows.isEmpty()) {
                    "Aucun stock disponible pour cet article."
                } else {
                    rows.joinToString("\n\n") {
                        "SAP: ${it.sap}\nOCP: ${it.ocp}\n${it.designation}\n" +
                                "${it.magasin} / ${it.emplacement}\nQté: ${it.qty} ${it.unite}\n" +
                                "PU: ${it.pu} ${it.devise}\nValeur: ${it.valeur} ${it.devise}"
                    }
                }
            } catch (e: Exception) {
                dialogMessage = e.message ?: "Erreur de recherche."
            } finally {
                loading = false
            }
        }
    }

    fun searchMovement() {
        val error = validate(movement)
        if (error != null) {
            dialogMessage = error
            return
        }
        scope.launch {
            loading = true
            try {
                val rows = api.movements(movement.trim())
                dialogMessage = if (rows.isEmpty()) {
                    "Aucun mouvement trouvé pour cet article."
                } else {
                    rows.joinToString("\n\n") {
                        "${it.date} — ${it.type}\nSAP: ${it.sap} / OCP: ${it.ocp}\n" +
                                "${it.designation}\nQté: ${it.qty} ${it.unite}\n" +
                                "${it.source} → ${it.destination}\nDoc: ${it.doc}\nValeur: ${it.valeur}"
                    }
                }
            } catch (e: Exception) {
                dialogMessage = e.message ?: "Erreur de recherche."
            } finally {
                loading = false
            }
        }
    }

    fun searchOrganization() {
        if (org.trim().isBlank()) {
            dialogMessage = "Veuillez saisir un code ou une désignation."
            return
        }
        scope.launch {
            loading = true
            try {
                val rows = api.organizations(org.trim())
                dialogMessage = if (rows.isEmpty()) {
                    "Aucun article d’organisation trouvé."
                } else {
                    rows.joinToString("\n\n") {
                        "Code: ${it.code}\n${it.designation}\nUnité: ${it.unite}\n" +
                                "Groupe: ${it.groupe}\nOrganisation: ${it.organisation}"
                    }
                }
            } catch (e: Exception) {
                dialogMessage = e.message ?: "Erreur de recherche."
            } finally {
                loading = false
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(Modifier.fillMaxSize()) {
            Header()
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Spacer(Modifier.height(2.dp))
                WelcomeBanner()
                Spacer(Modifier.height(5.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    SummaryCard(
                        title = "Nombre d’articles",
                        value = articleCount,
                        subtitle = "Articles en stock",
                        accent = Green,
                        icon = Icons.Default.Inventory2,
                        modifier = Modifier.weight(1f)
                    )
                    SummaryCard(
                        title = "Valeur de stock global",
                        value = stockValue,
                        subtitle = "MAD",
                        accent = Blue,
                        icon = Icons.Default.Storage,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(5.dp))
                SearchModule(
                    title = "Synthèse des stocks",
                    accent = Green,
                    background = GreenSoft,
                    value = stock,
                    onValueChange = { stock = codeFilter(it) },
                    onSearch = { searchStock() }
                )
                Spacer(Modifier.height(4.dp))
                SearchModule(
                    title = "Mouvement matière",
                    accent = Blue,
                    background = BlueSoft,
                    value = movement,
                    onValueChange = { movement = codeFilter(it) },
                    onSearch = { searchMovement() }
                )
                Spacer(Modifier.height(4.dp))
                SearchModule(
                    title = "Article d’organisation",
                    accent = Purple,
                    background = PurpleSoft,
                    value = org,
                    onValueChange = { org = it },
                    onSearch = { searchOrganization() },
                    organisation = true
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Work with love ♥",
                    modifier = Modifier.fillMaxWidth(),
                    color = GreenDark,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(1.dp))
            }
        }
    }

    if (loading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Green)
        }
    }

    if (dialogMessage != null) {
        AlertDialog(
            onDismissRequest = { dialogMessage = null },
            title = { Text("MobiStock") },
            text = { Text(dialogMessage ?: "") },
            confirmButton = {
                TextButton(onClick = { dialogMessage = null }) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(23.dp))
                .background(GreenSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Eco, contentDescription = null, tint = Green, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("JORF FERTILIZERS COMPANY I", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("MobiStock", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("Gestion des stocks & mouvements", fontSize = 11.sp, color = Grey)
        }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(74.dp)
            .clip(RoundedCornerShape(0.dp, 0.dp, 22.dp, 22.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD))
                )
            )
    ) {
        Column(Modifier.padding(start = 16.dp, top = 10.dp, end = 135.dp)) {
            Text("Bonjour,", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("Bienvenue sur MobiStock", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(Modifier.height(2.dp))
            Text(
                "Consultez et gérez vos stocks et mouvements en temps réel.",
                fontSize = 7.sp,
                color = Grey
            )
        }
        Icon(
            Icons.Default.Business,
            contentDescription = null,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 18.dp)
                .size(58.dp),
            tint = Color(0x6675A98A)
        )
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier
) {
    Card(
        modifier = modifier.height(92.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.width(7.dp))
            Column {
                Text(title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Text(subtitle, fontSize = 8.sp, color = Grey)
            }
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    accent: Color,
    background: Color,
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    organisation: Boolean = false
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(98.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (organisation) Icons.Default.Business else Icons.Default.Search,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = accent,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    Icons.Default.ArrowForwardIos,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(15.dp)
                )
            }
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(
                            width = 2.dp,
                            color = if (value.isNotEmpty()) accent else Border,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    BasicTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(
                            color = TextDark,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal
                        ),
                        decorationBox = { innerTextField ->
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (value.isEmpty()) {
                                    Text(
                                        text = if (organisation) "Code article ou Désignation" else "Code SAP ou Code OCP",
                                        color = Grey,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                }

                Button(
                    onClick = onSearch,
                    modifier = Modifier
                        .width(124.dp)
                        .height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Rechercher", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(api: SupabaseClient) {
    var url by remember { mutableStateOf(api.url) }
    var key by remember { mutableStateOf(api.key) }
    var saved by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Paramètres", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = GreenDark)
        Spacer(Modifier.height(8.dp))
        Text("Connexion Supabase", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("URL Supabase") },
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Anon public key") },
            singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                api.url = url
                api.key = key
                saved = true
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) {
            Text("Enregistrer")
        }
        if (saved) {
            Spacer(Modifier.height(10.dp))
            Text("Configuration enregistrée.", color = Green, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(30.dp))
        Text("MobiStock 1.0", color = Grey)
        Text("JORF FERTILIZERS COMPANY I", color = Grey)
    }
}

@Composable
private fun BottomNavigationBar(page: Int, onPage: (Int) -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            NavigationItem(Icons.Default.Home, "Accueil", page == 0, Green) { onPage(0) }
            NavigationItem(Icons.Default.Settings, "Paramètres", page == 1, Grey) { onPage(1) }
        }
    }
}

@Composable
private fun NavigationItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(110.dp)
            .padding(vertical = 2.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(28.dp)) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (active) Green else color,
                modifier = Modifier.size(20.dp)
            )
        }
        Text(
            label,
            fontSize = 9.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            color = if (active) Green else color
        )
        if (active) {
            Box(
                modifier = Modifier
                    .width(90.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Green)
            )
        }
    }
}
