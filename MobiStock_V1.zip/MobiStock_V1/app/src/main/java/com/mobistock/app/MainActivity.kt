package com.mobistock.app

import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.provider.MediaStore
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as lazyGridItems
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

private val Green = Color(0xFF22C55E)
private val GreenDark = Color(0xFF16A34A)
private val Blue = Color(0xFF3B82F6)
private val Purple = Color(0xFFA855F7)
private val HeaderGreen = Color(0xFF15803D)
private val NetflixRed = Color(0xFFE50914)
private val GreenSoft = Color(0xFF14532D)
private val BlueSoft = Color(0xFF1E3A5F)
private val PurpleSoft = Color(0xFF3B0764)

private data class MobiColors(
    val surfaceBg: Color,
    val cardSurface: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val fieldBg: Color,
    val isDark: Boolean
)

private val DarkColors = MobiColors(
    surfaceBg = Color(0xFF0B1220),
    cardSurface = Color(0xFF0F172A),
    textPrimary = Color.White,
    textSecondary = Color(0xFF94A3B8),
    textMuted = Color(0xFF64748B),
    border = Color(0xFF1E293B),
    fieldBg = Color(0xFF0F172A),
    isDark = true
)

private val LightColors = MobiColors(
    surfaceBg = Color(0xFFF8FAFC),
    cardSurface = Color.White,
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    textMuted = Color(0xFF94A3B8),
    border = Color(0xFFE2E8F0),
    fieldBg = Color(0xFFF1F5F9),
    isDark = false
)

private val LocalMobiColors = staticCompositionLocalOf { DarkColors }

private val PrefsName = "mobistock_prefs"
private val PrefDark = "dark_theme"
private val PrefLang = "app_lang"
private val PrefLoggedIn = "logged_in"
private val PrefLoginAt = "login_at_ms"
private val PrefLoginUser = "login_user"
private val PrefUserRole = "user_role"
private val PrefReadTeamMsgs = "read_team_msg_ids"
private val PrefReadTeamComments = "read_team_comment_ids"
private const val SESSION_MAX_MS = 240L * 60 * 1000 // 4 heures (240 minutes)

/** Auth via table Supabase AppUsers (plus de mot de passe fixe dans le code). */

data class AppStrings(
    val settings: String,
    val appearance: String,
    val darkMode: String,
    val lightMode: String,
    val language: String,
    val french: String,
    val english: String,
    val home: String,
    val stockSummary: String,
    val movement: String,
    val orgArticle: String,
    val search: String,
    val loading: String,
    val back: String,
    val noOrg: String,
    val noStock: String,
    val noMovement: String,
    val enterCodeOrDesignation: String,
    val enterCode: String,
    val designation: String,
    val descriptif: String,
    val login: String,
    val loginSubtitle: String,
    val identifier: String,
    val password: String,
    val connect: String,
    val logout: String,
    val noNetwork: String,
    val codeCopied: String,
    val searchBySapOcp: String,
    val wrongCredentials: String,
    val enterCredentials: String,
    val stockDetail: String,
    val optionalFilters: String,
    val codeRequiredFiltersOptional: String,
    val darkModeDesc: String,
    val lightModeDesc: String,
    val workWithLove: String,
    val articlesCount: String,
    val stockValue: String,
    val articlesInStock: String,
    val movementHistory: String,
    val orgSearchHint: String
)

private val StringsFr = AppStrings(
    settings = "Paramètres",
    appearance = "Apparence",
    darkMode = "Mode sombre",
    lightMode = "Mode clair",
    language = "Langue",
    french = "Français",
    english = "English",
    home = "Accueil",
    stockSummary = "SYNTHÈSE DES STOCKS",
    movement = "Mouvements matières",
    orgArticle = "Article d'organisation",
    search = "RECHERCHER",
    loading = "Chargement…",
    back = "Retour",
    noOrg = "Aucun article d'organisation trouvé.",
    noStock = "Aucun stock disponible pour cet article",
    noMovement = "Aucun mouvement trouvé pour cet article.",
    enterCodeOrDesignation = "Saisir un code SAP/OCP et/ou une désignation.",
    enterCode = "Saisir Code SAP ou Code OCP",
    designation = "Désignation",
    descriptif = "Descriptif",
    login = "Connexion",
    loginSubtitle = "Saisissez vos identifiants",
    identifier = "Identifiant",
    password = "Mot de passe",
    connect = "SE CONNECTER",
    logout = "Se déconnecter",
    noNetwork = "Pas de connexion réseau. Vérifiez votre Internet.",
    codeCopied = "Code copié",
    searchBySapOcp = "Recherche par code SAP ou code OCP.",
    wrongCredentials = "Identifiant ou mot de passe incorrect.",
    enterCredentials = "Veuillez saisir l'identifiant et le mot de passe.",
    stockDetail = "Détail du stock",
    optionalFilters = "Filtres optionnels",
    codeRequiredFiltersOptional = "Code SAP/OCP obligatoire. Filtres magasin, code mouvement et dates optionnels.",
    darkModeDesc = "Fond sombre, texte clair",
    lightModeDesc = "Fond clair, texte sombre",
    workWithLove = "Work with love",
    articlesCount = "Nombre d'articles",
    stockValue = "Valeur de stock",
    articlesInStock = "Articles en stock",
    movementHistory = "Historique des mouvements",
    orgSearchHint = "Recherche par code ou désignation"
)

private val StringsEn = AppStrings(
    settings = "Settings",
    appearance = "Appearance",
    darkMode = "Dark mode",
    lightMode = "Light mode",
    language = "Language",
    french = "Français",
    english = "English",
    home = "Home",
    stockSummary = "STOCK SUMMARY",
    movement = "Material movements",
    orgArticle = "Organization article",
    search = "SEARCH",
    loading = "Loading…",
    back = "Back",
    noOrg = "No organization article found.",
    noStock = "No stock available for this item",
    noMovement = "No movement found for this item.",
    enterCodeOrDesignation = "Enter a SAP/OCP code and/or a designation.",
    enterCode = "Enter SAP code or OCP code",
    designation = "Designation",
    descriptif = "Description",
    login = "Sign in",
    loginSubtitle = "Enter your credentials",
    identifier = "Username",
    password = "Password",
    connect = "SIGN IN",
    logout = "Sign out",
    noNetwork = "No network connection. Check your Internet.",
    codeCopied = "Code copied",
    searchBySapOcp = "Search by SAP code or OCP code.",
    wrongCredentials = "Incorrect username or password.",
    enterCredentials = "Please enter username and password.",
    stockDetail = "Stock detail",
    optionalFilters = "Optional filters",
    codeRequiredFiltersOptional = "SAP/OCP code required. Magasin, movement code and dates optional.",
    darkModeDesc = "Dark background, light text",
    lightModeDesc = "Light background, dark text",
    workWithLove = "Work with love",
    articlesCount = "Number of items",
    stockValue = "Stock value",
    articlesInStock = "Items in stock",
    movementHistory = "Movement history",
    orgSearchHint = "Search by code or designation"
)

fun stringsFor(lang: String) = if (lang == "en") StringsEn else StringsFr

fun friendlyError(msg: String?, s: AppStrings): String {
    if (msg == null) return s.noNetwork
    if (msg == "NETWORK" || msg.contains("Unable to resolve", true) ||
        msg.contains("Failed to connect", true) || msg.contains("timeout", true)
    ) return s.noNetwork
    return msg
}

val LocalAppStrings = staticCompositionLocalOf { StringsFr }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        val initialDark = prefs.getBoolean(PrefDark, true)
        val initialLang = prefs.getString(PrefLang, "fr") ?: "fr"
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        val loginAt = prefs.getLong(PrefLoginAt, 0L)
        val stillValid = prefs.getBoolean(PrefLoggedIn, false) &&
            loginAt > 0L &&
            (System.currentTimeMillis() - loginAt) < SESSION_MAX_MS
        if (prefs.getBoolean(PrefLoggedIn, false) && !stillValid) {
            prefs.edit().putBoolean(PrefLoggedIn, false).remove(PrefLoginAt).apply()
        }
        val initialLoggedIn = stillValid
        setContent {
            var isDark by remember { mutableStateOf(initialDark) }
            var lang by remember { mutableStateOf(initialLang) }
            var isLoggedIn by remember { mutableStateOf(initialLoggedIn) }
            MobiTheme(isDark) {
                CompositionLocalProvider(LocalAppStrings provides stringsFor(lang)) {
                    if (!isLoggedIn) {
                        LoginScreen(
                            api = SupabaseClient(this@MainActivity),
                            onSuccess = { username ->
                                isLoggedIn = true
                                prefs.edit()
                                    .putBoolean(PrefLoggedIn, true)
                                    .putLong(PrefLoginAt, System.currentTimeMillis())
                                    .putString(PrefLoginUser, username)
                                    .apply()
                            }
                        )
                    } else {
                        App(
                            isDark = isDark,
                            onThemeChange = { dark ->
                                isDark = dark
                                prefs.edit().putBoolean(PrefDark, dark).apply()
                            },
                            lang = lang,
                            onLangChange = { l ->
                                lang = l
                                prefs.edit().putString(PrefLang, l).apply()
                            },
                            onLogout = {
                                isLoggedIn = false
                                prefs.edit()
                                    .putBoolean(PrefLoggedIn, false)
                                    .remove(PrefLoginAt)
                                    .remove(PrefLoginUser).remove(PrefUserRole)
                                    .apply()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MobiTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    CompositionLocalProvider(LocalMobiColors provides colors) {
        MaterialTheme(
            colorScheme = if (darkTheme) darkColorScheme(
                primary = Green,
                background = colors.surfaceBg,
                surface = colors.cardSurface,
                onSurface = colors.textPrimary,
                onPrimary = Color.White
            ) else lightColorScheme(
                primary = Green,
                background = colors.surfaceBg,
                surface = colors.cardSurface,
                onSurface = colors.textPrimary,
                onPrimary = Color.White
            ),
            content = content
        )
    }
}

private data class StockRow(
    val sap: String, val ocp: String, val designation: String, val magasin: String,
    val division: String, val emplacement: String, val qty: String, val unite: String, val pu: String,
    val valeur: String, val devise: String, val dateEm: String, val derniereSortie: String
)

/** Ligne résultat recherche stock multiple (max 15). */
private data class MultiStockRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val qty: String,
    val bin: String,
    val cons2025: String,
    val cons2026: String
)

private data class MovementRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val magasin: String,
    val quantite: String,
    val unite: String,
    val montant: String,
    val codeMouvement: String,
    val ordre: String,
    val reservation: String,
    val po: String,
    val reference: String,
    val docArticle: String,
    val date: String,
    val partenaire: String
)

private data class OrgRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val descriptif: String,
    val famille: String = ""
)

/** Photo catalogue liée à un code SAP ou OCP. */
private data class CatalogPhotoRow(
    val id: String,
    val code: String,
    val photoUrl: String
)

/** Carte catalogue enrichie Mm03 + stock. */
private object CatalogCache {
    @Volatile var items: List<CatalogItem>? = null
}

private data class CatalogItem(
    val id: String,
    val code: String,
    val sap: String,
    val ocp: String,
    val designation: String,
    val qty: String,
    val photoUrl: String
)

private object Top15LastTotal {
    @Volatile var value: java.math.BigDecimal = java.math.BigDecimal.ZERO
    fun set(v: java.math.BigDecimal) { value = v }
    fun get(): java.math.BigDecimal = value
}

/** Cache Top 15 par type de carte (session). */
private object Top15Cache {
    data class Entry(
        val rows: List<TopArticleRow>,
        val total: java.math.BigDecimal,
        val topSum: java.math.BigDecimal
    )
    private val map = mutableMapOf<String, Entry>()
    fun get(key: String): Entry? = map[key]
    fun put(key: String, entry: Entry) { map[key] = entry }
}

private data class TeamMessage(
    val id: String,
    val objet: String,
    val corps: String,
    val date: String = "",
    val photoUrl: String = "",
    val auteur: String = ""
)

private data class TeamMessageComment(
    val id: String,
    val messageId: String,
    val auteur: String,
    val texte: String,
    val date: String = "",
    val role: String = "user"
)

private data class TopArticleRow(
    val sap: String,
    val ocp: String,
    val designation: String,
    val value: String,
    val valueBd: java.math.BigDecimal = java.math.BigDecimal.ZERO,
    val detail: String = ""
)

private data class Top15Bundle(
    val rows: List<TopArticleRow>,
    val total: java.math.BigDecimal
)

private class SupabaseClient(context: Context) {
    private val baseUrl = "https://kbztwijnoyifbmtoanps.supabase.co"
    private val publishableKey = "sb_publishable_jZ09Xb3kpjE7buTRwRKwNQ_7SzSDAZh"
    val url: String get() = baseUrl
    val key: String get() = publishableKey

    private fun get(path: String, query: String): String {
        try {
            val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
            c.requestMethod = "GET"
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Accept", "application/json")
            c.connectTimeout = 15000
            c.readTimeout = 20000
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            c.disconnect()
            if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
            return body
        } catch (e: java.net.UnknownHostException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.net.SocketTimeoutException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.io.IOException) {
            throw IllegalStateException("NETWORK")
        }
    }

    /** true si compte inactif ou force_logout (colonne optionnelle). */
    suspend fun shouldForceLogout(identifiant: String): Boolean = withContext(Dispatchers.IO) {
        if (identifiant.isBlank()) return@withContext false
        val id = enc(identifiant.trim())
        try {
            val body = get("AppUsers", "identifiant=eq.$id&select=actif,force_logout&limit=1")
            val arr = JSONArray(body)
            if (arr.length() == 0) return@withContext true
            val o = arr.getJSONObject(0)
            if (!o.optBoolean("actif", true)) return@withContext true
            if (o.has("force_logout") && o.optBoolean("force_logout", false)) return@withContext true
            false
        } catch (e: Exception) {
            if (e.message == "NETWORK") throw e
            // Colonne force_logout absente : vérifier seulement actif
            try {
                val body = get("AppUsers", "identifiant=eq.$id&select=actif&limit=1")
                val arr = JSONArray(body)
                if (arr.length() == 0) return@withContext true
                !arr.getJSONObject(0).optBoolean("actif", true)
            } catch (e2: Exception) {
                if (e2.message == "NETWORK") throw e2
                false
            }
        }
    }

    /** Vérifie identifiant + mot de passe dans AppUsers (actif = true). */
    suspend fun login(identifiant: String, motDePasse: String): Boolean = withContext(Dispatchers.IO) {
        val id = enc(identifiant.trim())
        val q = "identifiant=eq.$id&actif=eq.true&select=identifiant,mot_de_passe,role&limit=1"
        val body = try {
            get("AppUsers", q)
        } catch (_: Exception) {
            get("AppUsers", "identifiant=eq.$id&actif=eq.true&select=identifiant,mot_de_passe&limit=1")
        }
        val arr = JSONArray(body)
        if (arr.length() == 0) return@withContext false
        val o = arr.getJSONObject(0)
        val stored = o.optString("mot_de_passe", "")
        if (stored != motDePasse) return@withContext false
        lastLoginRole = o.optString("role", "user").trim().ifBlank { "user" }.lowercase()
        true
    }

    @Volatile
    var lastLoginRole: String = "user"
        private set

    suspend fun userRole(identifiant: String): String = withContext(Dispatchers.IO) {
        val id = enc(identifiant.trim())
        try {
            val body = get("AppUsers", "identifiant=eq.$id&select=role&limit=1")
            val arr = JSONArray(body)
            if (arr.length() == 0) return@withContext "user"
            arr.getJSONObject(0).optString("role", "user").trim().ifBlank { "user" }.lowercase()
        } catch (_: Exception) {
            "user"
        }
    }

    suspend fun createTeamMessage(
        objet: String,
        corps: String,
        photoUrl: String? = null,
        auteur: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val o = objet.trim()
        val c = corps.trim()
        if (o.isEmpty() || c.isEmpty()) return@withContext false
        val json = JSONObject()
            .put("objet", o)
            .put("corps", c)
            .put("actif", true)
        val pu = photoUrl?.trim().orEmpty()
        if (pu.isNotEmpty()) json.put("photo_url", pu)
        val au = auteur?.trim().orEmpty()
        if (au.isNotEmpty()) json.put("auteur", au)
        try {
            val resp = post("TeamMessages", json.toString())
            resp.trimStart().startsWith("{") || resp.trimStart().startsWith("[") || resp.isBlank()
        } catch (_: Exception) {
            false
        }
    }

    /** Upload image vers Storage bucket team-photos, retourne l'URL publique. */
    /** Charge une photo Storage (public ou authentifié). */
    fun teamPhotoRequest(context: android.content.Context, rawUrl: String): coil.request.ImageRequest {
        var u = rawUrl.trim()
        // Forcer le chemin authentifié si public bloqué par RLS
        if (u.contains("/object/public/")) {
            u = u.replace("/object/public/", "/object/authenticated/")
        }
        return coil.request.ImageRequest.Builder(context)
            .data(u)
            .addHeader("apikey", key)
            .addHeader("Authorization", "Bearer $key")
            .crossfade(true)
            .build()
    }

    suspend fun uploadTeamPhoto(bytes: ByteArray, fileName: String): String? = withContext(Dispatchers.IO) {
        val safe = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "photo.jpg" }
        val objectPath = "team-photos/$safe"
        try {
            val c = URL("$url/storage/v1/object/$objectPath").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "image/jpeg")
            c.setRequestProperty("x-upsert", "true")
            c.setRequestProperty("Content-Length", bytes.size.toString())
            c.connectTimeout = 30000
            c.readTimeout = 60000
            c.outputStream.use { out -> out.write(bytes); out.flush() }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            c.disconnect()
            if (code !in 200..299) return@withContext null
            // URL publique standard Supabase
            val publicUrl = "$url/storage/v1/object/public/$objectPath"
            publicUrl
        } catch (_: Exception) {
            null
        }
    }

    suspend fun uploadCatalogPhoto(bytes: ByteArray, fileName: String): String? = withContext(Dispatchers.IO) {
        val safe = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "photo.jpg" }
        val objectPath = "catalog-photos/$safe"
        try {
            val c = URL("$url/storage/v1/object/$objectPath").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "image/jpeg")
            c.setRequestProperty("x-upsert", "true")
            c.setRequestProperty("Content-Length", bytes.size.toString())
            c.connectTimeout = 30000
            c.readTimeout = 60000
            c.outputStream.use { out -> out.write(bytes); out.flush() }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            stream?.bufferedReader()?.use { it.readText() }
            c.disconnect()
            if (code !in 200..299) return@withContext null
            "$url/storage/v1/object/public/$objectPath"
        } catch (_: Exception) {
            null
        }
    }

    suspend fun catalogPhotos(): List<CatalogPhotoRow> = withContext(Dispatchers.IO) {
        val queries = listOf(
            "select=id,code,photo_url,created_at&order=created_at.desc.nullslast&limit=200",
            "select=*&order=created_at.desc&limit=200",
            "select=*&limit=200"
        )
        var body = ""
        for (q in queries) {
            try {
                body = get("CatalogPhotos", q)
                if (body.trimStart().startsWith("[")) break
            } catch (_: Exception) {
                body = ""
            }
        }
        if (!body.trimStart().startsWith("[")) return@withContext emptyList()
        val arr = JSONArray(body)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id").trim()
                val code = sequenceOf("code", "code_sap", "code_ocp", "sap", "ocp")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                val photo = sequenceOf("photo_url", "photo", "image_url", "url")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                if (id.isEmpty() || code.isEmpty() || photo.isEmpty()) continue
                add(CatalogPhotoRow(id = id, code = code, photoUrl = photo))
            }
        }
    }

    suspend fun createCatalogPhoto(code: String, photoUrl: String): Boolean = withContext(Dispatchers.IO) {
        val c = code.trim()
        val u = photoUrl.trim()
        if (c.isEmpty() || u.isEmpty()) return@withContext false
        val json = JSONObject().put("code", c).put("photo_url", u)
        try {
            val resp = post("CatalogPhotos", json.toString())
            resp.trimStart().startsWith("{") || resp.trimStart().startsWith("[") || resp.isBlank()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteCatalogPhoto(id: String): Boolean = withContext(Dispatchers.IO) {
        val mid = id.trim()
        if (mid.isEmpty()) return@withContext false
        try {
            deleteHttp("CatalogPhotos", "id=eq.${enc(mid)}")
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun enrichCatalogPhoto(ph: CatalogPhotoRow): CatalogItem {
        val orgs = try {
            organizationsByCode(ph.code)
        } catch (_: Exception) {
            emptyList()
        }
        val org = orgs.firstOrNull()
        val stocks = try {
            stocks(ph.code)
        } catch (_: Exception) {
            emptyList()
        }
        var sum = java.math.BigDecimal.ZERO
        for (s in stocks) {
            val raw = s.qty.replace(" ", "").replace(",", ".")
            try {
                sum = sum.add(java.math.BigDecimal(raw))
            } catch (_: Exception) {
            }
        }
        val qtyStr = sum.stripTrailingZeros().toPlainString()
        return CatalogItem(
            id = ph.id,
            code = ph.code,
            sap = org?.sap?.ifBlank { ph.code } ?: stocks.firstOrNull()?.sap?.ifBlank { ph.code } ?: ph.code,
            ocp = org?.ocp?.ifBlank { "" } ?: stocks.firstOrNull()?.ocp.orEmpty(),
            designation = org?.designation?.ifBlank { "—" } ?: stocks.firstOrNull()?.designation?.ifBlank { "—" } ?: "—",
            qty = qtyStr,
            photoUrl = ph.photoUrl
        )
    }

    /** Codes liés (SAP + OCP) via Mm03 / stock pour une recherche catalogue. */
    suspend fun resolveRelatedArticleCodes(search: String): Set<String> = withContext(Dispatchers.IO) {
        val q = search.trim()
        if (q.isEmpty()) return@withContext emptySet()
        val codes = linkedSetOf(q)
        try {
            for (o in organizationsByCode(q)) {
                o.sap.trim().takeIf { it.isNotEmpty() && it != "null" }?.let { codes.add(it) }
                o.ocp.trim().takeIf { it.isNotEmpty() && it != "null" }?.let { codes.add(it) }
            }
        } catch (_: Exception) {
        }
        try {
            for (s in stocks(q)) {
                s.sap.trim().takeIf { it.isNotEmpty() && it != "null" }?.let { codes.add(it) }
                s.ocp.trim().takeIf { it.isNotEmpty() && it != "null" }?.let { codes.add(it) }
            }
        } catch (_: Exception) {
        }
        codes
    }

    /** Photos catalogue + Mm03 + quantité stock (0 si rupture). Uniquement articles avec photo. */
    suspend fun catalogItems(searchCode: String = ""): List<CatalogItem> = withContext(Dispatchers.IO) {
        val photos = catalogPhotos()
        val q = searchCode.trim()
        val all = coroutineScope {
            photos.map { ph -> async { enrichCatalogPhoto(ph) } }.awaitAll()
        }
        if (q.isEmpty()) all
        else all.filter { item ->
            item.code.contains(q, ignoreCase = true) ||
                item.sap.contains(q, ignoreCase = true) ||
                item.ocp.contains(q, ignoreCase = true)
        }
    }

    suspend fun deleteTeamMessage(id: String): Boolean = withContext(Dispatchers.IO) {
        val mid = id.trim()
        if (mid.isEmpty()) return@withContext false
        try {
            deleteHttp("TeamMessages", "id=eq.${enc(mid)}")
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun teamMessageComments(messageId: String): List<TeamMessageComment> = withContext(Dispatchers.IO) {
        val mid = messageId.trim()
        if (mid.isEmpty()) return@withContext emptyList()
        val queries = listOf(
            "message_id=eq.${enc(mid)}&select=*&order=created_at.asc.nullslast&limit=100",
            "message_id=eq.${enc(mid)}&select=id,message_id,auteur,texte,created_at&order=created_at.asc&limit=100",
            "message_id=eq.${enc(mid)}&select=*&limit=100"
        )
        var body = ""
        for (q in queries) {
            try {
                body = get("TeamMessageComments", q)
                if (body.trimStart().startsWith("[")) break
            } catch (_: Exception) {
                body = ""
            }
        }
        if (!body.trimStart().startsWith("[")) return@withContext emptyList()
        val arr = JSONArray(body)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id").trim()
                if (id.isEmpty()) continue
                val mId = o.optString("message_id").trim()
                val auteur = sequenceOf("auteur", "author", "identifiant", "user")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                val texte = sequenceOf("texte", "text", "corps", "comment", "contenu")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                if (texte.isEmpty()) continue
                val date = sequenceOf("created_at", "date", "createdAt")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                val role = sequenceOf("role", "user_role")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" }
                    ?.lowercase()
                    ?: "user"
                add(TeamMessageComment(id = id, messageId = mId, auteur = auteur, texte = texte, date = date, role = role))
            }
        }.sortedBy { it.date }
    }


    /** Tous les commentaires (pour badges non lus / cloche). */
    suspend fun allTeamMessageComments(): List<TeamMessageComment> = withContext(Dispatchers.IO) {
        val queries = listOf(
            "select=*&order=created_at.desc.nullslast&limit=500",
            "select=id,message_id,auteur,texte,created_at,role&order=created_at.desc&limit=500",
            "select=*&limit=500"
        )
        var body = ""
        for (q in queries) {
            try {
                body = get("TeamMessageComments", q)
                if (body.trimStart().startsWith("[")) break
            } catch (_: Exception) {
                body = ""
            }
        }
        if (!body.trimStart().startsWith("[")) return@withContext emptyList()
        val arr = JSONArray(body)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id").trim()
                if (id.isEmpty()) continue
                val mId = o.optString("message_id").trim()
                val auteur = sequenceOf("auteur", "author", "identifiant", "user")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                val texte = sequenceOf("texte", "text", "corps", "comment", "contenu")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                if (texte.isEmpty()) continue
                val date = sequenceOf("created_at", "date", "createdAt")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                val role = sequenceOf("role", "user_role")
                    .map { o.optString(it).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" }
                    ?.lowercase()
                    ?: "user"
                add(TeamMessageComment(id = id, messageId = mId, auteur = auteur, texte = texte, date = date, role = role))
            }
        }
    }

    suspend fun createTeamMessageComment(
        messageId: String,
        texte: String,
        auteur: String,
        role: String = "user"
    ): Boolean = withContext(Dispatchers.IO) {
        val mid = messageId.trim()
        val t = texte.trim()
        if (mid.isEmpty() || t.isEmpty()) return@withContext false
        val json = JSONObject()
            .put("message_id", mid)
            .put("texte", t)
        val au = auteur.trim()
        if (au.isNotEmpty()) json.put("auteur", au)
        val r = role.trim().lowercase().ifBlank { "user" }
        json.put("role", r)
        try {
            val resp = post("TeamMessageComments", json.toString())
            resp.trimStart().startsWith("{") || resp.trimStart().startsWith("[") || resp.isBlank()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteTeamMessageComment(id: String): Boolean = withContext(Dispatchers.IO) {
        val cid = id.trim()
        if (cid.isEmpty()) return@withContext false
        try {
            deleteHttp("TeamMessageComments", "id=eq.${enc(cid)}")
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun deleteHttp(path: String, query: String): String {
        try {
            val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
            c.doOutput = true
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Prefer", "return=minimal")
            c.connectTimeout = 15000
            c.readTimeout = 20000
            try {
                c.requestMethod = "DELETE"
            } catch (_: java.net.ProtocolException) {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", "DELETE")
            }
            c.setRequestProperty("X-HTTP-Method-Override", "DELETE")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            c.disconnect()
            if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
            return body
        } catch (e: java.net.UnknownHostException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.net.SocketTimeoutException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.io.IOException) {
            throw IllegalStateException("NETWORK")
        }
    }

    private fun post(path: String, jsonBody: String): String {
        try {
            val c = URL("$url/rest/v1/$path").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Prefer", "return=representation")
            c.setRequestProperty("Accept", "application/json")
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            c.disconnect()
            if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
            return body
        } catch (e: java.net.UnknownHostException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.net.SocketTimeoutException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.io.IOException) {
            throw IllegalStateException("NETWORK")
        }
    }

    /**
     * PATCH PostgREST. Sur Android, HttpURLConnection refuse souvent "PATCH" :
     * on utilise POST + X-HTTP-Method-Override.
     */
    private fun patch(path: String, query: String, jsonBody: String): String {
        try {
            val c = URL("$url/rest/v1/$path?$query").openConnection() as HttpURLConnection
            c.doOutput = true
            c.setRequestProperty("apikey", key)
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Prefer", "return=representation")
            c.connectTimeout = 15000
            c.readTimeout = 20000
            // Android : PATCH non supporté → POST + override
            try {
                c.requestMethod = "PATCH"
            } catch (_: java.net.ProtocolException) {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            }
            // Certains appareils acceptent setRequestMethod("PATCH") mais l'ignorent :
            // forcer aussi l'override en complément
            c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            val bytes = jsonBody.toByteArray(Charsets.UTF_8)
            c.setRequestProperty("Content-Length", bytes.size.toString())
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            c.disconnect()
            if (code !in 200..299) throw IllegalStateException("Supabase ($code): $body")
            return body
        } catch (e: java.net.UnknownHostException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.net.SocketTimeoutException) {
            throw IllegalStateException("NETWORK")
        } catch (e: java.io.IOException) {
            throw IllegalStateException("NETWORK")
        }
    }

    /** Change le mot de passe (vérifie l'ancien, met à jour AppUsers, contrôle le résultat). */

    suspend fun teamMessages(): List<TeamMessage> = withContext(Dispatchers.IO) {
        val queries = listOf(
            "select=*&order=created_at.desc.nullslast&limit=50",
            "select=id,objet,corps,created_at&order=created_at.desc.nullslast&limit=50",
            "select=*&limit=50",
            "select=id,objet,corps,created_at&limit=50",
            "select=id,objet,corps&limit=50",
            "actif=eq.true&select=*&limit=50"
        )
        var body: String? = null
        for (q in queries) {
            try {
                val b = get("TeamMessages", q)
                if (b.trimStart().startsWith("[")) {
                    body = b
                    break
                }
            } catch (_: Exception) { /* essai suivant */ }
        }
        if (body == null) return@withContext emptyList()
        val arr = try { JSONArray(body) } catch (_: Exception) { return@withContext emptyList() }
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val id = o.opt("id")?.toString()?.trim().orEmpty()
            if (id.isEmpty() || id == "null") return@mapNotNull null
            // ignorer inactifs si colonne présente
            if (o.has("actif") && !o.isNull("actif") && !o.optBoolean("actif", true)) return@mapNotNull null
            val objet = sequenceOf("objet", "title", "sujet", "object")
                .map { o.optString(it).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" }
                ?: "Message d'équipe"
            val corps = sequenceOf("corps", "body", "message", "contenu")
                .map { o.optString(it).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" }
                ?: ""
            val date = sequenceOf("created_at", "date", "createdAt")
                .map { o.optString(it).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" }
                ?: ""
            val photo = sequenceOf("photo_url", "photo", "image_url", "image")
                .map { o.optString(it).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" }
                ?: ""
            val auteur = sequenceOf("auteur", "author", "created_by", "identifiant", "user")
                .map { o.optString(it).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" }
                ?: ""
            TeamMessage(id = id, objet = objet, corps = corps, date = date, photoUrl = photo, auteur = auteur)
        }.sortedByDescending { it.date.ifBlank { "" } }
    }

    suspend fun changePassword(
        identifiant: String,
        ancien: String,
        nouveau: String
    ): Boolean = withContext(Dispatchers.IO) {
        if (identifiant.isBlank() || ancien.isEmpty() || nouveau.isEmpty()) return@withContext false
        if (!login(identifiant, ancien)) return@withContext false
        val id = enc(identifiant.trim())
        val jsonBody = JSONObject().put("mot_de_passe", nouveau).toString()
        val response = patch("AppUsers", "identifiant=eq.$id", jsonBody)
        // Si RLS bloque l'UPDATE, réponse vide [] ou 204 sans body → échec
        val updated = try {
            val arr = JSONArray(response)
            arr.length() > 0 && arr.getJSONObject(0).optString("mot_de_passe", "") == nouveau
        } catch (_: Exception) {
            false
        }
        if (updated) return@withContext true
        // Repli : vérifier en relisant la table
        val check = get("AppUsers", "identifiant=eq.$id&select=mot_de_passe&limit=1")
        val arr = JSONArray(check)
        if (arr.length() == 0) return@withContext false
        arr.getJSONObject(0).optString("mot_de_passe", "") == nouveau
    }


    /** Consommation : somme |montant| codes 261/262/201/202 + dernière date 2026. */
    data class ConsumptionStats(
        val amount2025: String,
        val amount2026: String,
        val lastDate2025: String,
        val lastDate2026: String,
        val reception2025: String = "—",
        val reception2026: String = "—",
        val receptionDate2025: String = "—",
        val receptionDate2026: String = "—",
        val surstock: String = "—",
        val transfert2026: String = "—"
    )

    suspend fun consumptionByYear(): ConsumptionStats = withContext(Dispatchers.IO) {
        val codesConso = setOf("261", "262", "201", "202")
        val codesRecept = setOf("101", "102")
        val codesTransfert = setOf("643")
        val allCodes = codesConso + codesRecept + codesTransfert

        fun dateRaw(o: org.json.JSONObject): String {
            // Date métier uniquement (pas created_at / updated_at → fausse année)
            val preferred = listOf(
                "date", "Date", "budat", "date_mouvement", "date_de_saisie",
                "Date de saisie", "posting_date", "date_saisie", "budat_mkpf"
            )
            for (k in preferred) {
                if (o.has(k) && !o.isNull(k)) {
                    val v = o.opt(k)?.toString()?.trim().orEmpty()
                    if (v.isNotEmpty() && v != "null") return v
                }
            }
            // Autre colonne contenant "date" sauf created/updated
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                val kl = k.lowercase()
                if (!kl.contains("date")) continue
                if (kl.contains("created") || kl.contains("updated") || kl.contains("insert")) continue
                if (o.isNull(k)) continue
                val v = o.opt(k)?.toString()?.trim().orEmpty()
                if (v.isNotEmpty() && v != "null") return v
            }
            return ""
        }
        fun yearAndKey(d: String): Pair<Int, String>? {
            val s = d.trim()
            if (s.isBlank()) return null
            Regex("""(\d{4})-(\d{2})-(\d{2})""").find(s)?.let {
                val y = it.groupValues[1].toIntOrNull() ?: return@let
                return y to (it.groupValues[1] + it.groupValues[2] + it.groupValues[3])
            }
            Regex("""(\d{2})[./](\d{2})[./](\d{4})""").find(s)?.let {
                val y = it.groupValues[3].toIntOrNull() ?: return@let
                return y to (it.groupValues[3] + it.groupValues[2] + it.groupValues[1])
            }
            // Année seule en début / fin
            Regex("""(20\d{2})""").find(s)?.let {
                val y = it.groupValues[1].toIntOrNull() ?: return@let
                return y to (it.groupValues[1] + "0101")
            }
            return null
        }
        fun montantOf(o: org.json.JSONObject): BigDecimal? {
            for (k in listOf("montant_di", "montant", "Montant", "dmbtr", "amount", "valeur", "montant_di_mad")) {
                if (!o.has(k) || o.isNull(k)) continue
                var raw = o.opt(k)?.toString()
                    ?.replace("\u00a0", "")
                    ?.replace(" ", "")
                    ?.replace("MAD", "")
                    ?.replace("mad", "")
                    ?.trim() ?: continue
                if (raw.isEmpty() || raw == "null") continue
                // Format FR : 44.826.658,66 ou 44826658,66
                if (raw.contains(",") && raw.contains(".")) {
                    // points = milliers, virgule = décimale
                    raw = raw.replace(".", "").replace(",", ".")
                } else if (raw.contains(",")) {
                    raw = raw.replace(",", ".")
                }
                val v = raw.toBigDecimalOrNull()
                if (v != null) return v
            }
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                if (!k.contains("montant", ignoreCase = true) || o.isNull(k)) continue
                var raw = o.opt(k)?.toString()
                    ?.replace("\u00a0", "")
                    ?.replace(" ", "")
                    ?.replace("MAD", "")
                    ?.trim() ?: continue
                if (raw.contains(",") && raw.contains(".")) {
                    raw = raw.replace(".", "").replace(",", ".")
                } else if (raw.contains(",")) {
                    raw = raw.replace(",", ".")
                }
                val v = raw.toBigDecimalOrNull()
                if (v != null) return v
            }
            return null
        }
        fun codeOf(o: org.json.JSONObject): String {
            for (k in listOf("code_mouvement", "Code mouvement", "bwart", "movement_type", "code_mvt")) {
                if (!o.has(k) || o.isNull(k)) continue
                var v = o.opt(k)?.toString()?.trim() ?: continue
                if (v.isEmpty() || v == "null") continue
                // "261.0" / "261 " / 261
                v = v.substringBefore(".").substringBefore(" ").trim()
                // enlever zéros non significatifs : 0261 → 261 mais garder "101"
                v = v.trimStart('0').ifEmpty { "0" }
                return v
            }
            return ""
        }
        fun fmtMoney(v: BigDecimal): String = formatMoney(v) + " MAD"
        fun fmtDateLabel(d: String): String {
            if (d.isBlank()) return "—"
            return try { formatDate(d) } catch (_: Exception) { d }
        }

        // Chargement paginé avec ORDER pour éviter doublons / trous PostgREST
        val all = JSONArray()
        val selectCols = "code_mouvement,montant_di,montant,date,date_de_saisie,magasin"
        var offset = 0
        while (offset < 100000) {
            try {
                val part = JSONArray(
                    get(
                        "Mb51",
                        "code_mouvement=in.(261,262,201,202,101,102,643)&select=$selectCols&order=date.asc.nullslast&limit=1000&offset=$offset"
                    )
                )
                for (i in 0 until part.length()) all.put(part.getJSONObject(i))
                if (part.length() < 1000) break
                offset += 1000
            } catch (_: Exception) {
                // Repli sans order / select restreint
                if (offset == 0) {
                    try {
                        offset = 0
                        while (offset < 100000) {
                            val part = JSONArray(
                                get(
                                    "Mb51",
                                    "code_mouvement=in.(261,262,201,202,101,102,643)&select=*&limit=1000&offset=$offset"
                                )
                            )
                            for (i in 0 until part.length()) all.put(part.getJSONObject(i))
                            if (part.length() < 1000) break
                            offset += 1000
                        }
                    } catch (_: Exception) {
                        for (c in allCodes) {
                            try {
                                val part = JSONArray(
                                    get("Mb51", "code_mouvement=eq.$c&select=*&limit=5000")
                                )
                                for (i in 0 until part.length()) all.put(part.getJSONObject(i))
                            } catch (_: Exception) { }
                        }
                    }
                }
                break
            }
        }

        var c2025 = BigDecimal.ZERO
        var c2026 = BigDecimal.ZERO
        var r2025 = BigDecimal.ZERO
        var r2026 = BigDecimal.ZERO
        var t2026 = BigDecimal.ZERO
        var maxKeyC2025 = ""
        var maxLabelC2025 = ""
        var maxKeyC2026 = ""
        var maxLabelC2026 = ""
        var maxKeyR2025 = ""
        var maxLabelR2025 = ""
        var maxKeyR2026 = ""
        var maxLabelR2026 = ""

        for (i in 0 until all.length()) {
            val o = all.getJSONObject(i)
            val code = codeOf(o)
            if (code !in allCodes) continue
            // Somme algébrique (comme Excel) : ne pas prendre |montant|
            // ex. code 102 / retours négatifs réduisent la réception nette
            val m = montantOf(o) ?: continue
            val dr = dateRaw(o)
            val yk = yearAndKey(dr) ?: continue
            val year = yk.first
            val key = yk.second
            when {
                code in codesConso && year == 2025 -> {
                    c2025 += m
                    if (key > maxKeyC2025) { maxKeyC2025 = key; maxLabelC2025 = dr }
                }
                code in codesConso && year == 2026 -> {
                    c2026 += m
                    if (key > maxKeyC2026) { maxKeyC2026 = key; maxLabelC2026 = dr }
                }
                code in codesRecept && year == 2025 -> {
                    r2025 += m
                    if (key > maxKeyR2025) { maxKeyR2025 = key; maxLabelR2025 = dr }
                }
                code in codesRecept && year == 2026 -> {
                    r2026 += m
                    if (key > maxKeyR2026) { maxKeyR2026 = key; maxLabelR2026 = dr }
                }
                code in codesTransfert && year == 2026 -> {
                    t2026 += m
                }
            }
        }

        // Surstock : table stock uniquement, magasin MIN1
        var surstockSum = BigDecimal.ZERO
        try {
            var off = 0
            while (off < 50000) {
                val stockArr = JSONArray(
                    get("stock", "magasin=eq.MIN1&select=valeur_stock,magasin&limit=1000&offset=$off")
                )
                for (i in 0 until stockArr.length()) {
                    val o = stockArr.getJSONObject(i)
                    if (o.optString("magasin", "").trim().uppercase() != "MIN1") continue
                    val raw = o.opt("valeur_stock")?.toString()
                        ?.replace(" ", "")?.replace(",", ".")?.trim() ?: continue
                    val v = raw.toBigDecimalOrNull() ?: continue
                    surstockSum += v.abs()
                }
                if (stockArr.length() < 1000) break
                off += 1000
            }
        } catch (_: Exception) { }

        ConsumptionStats(
            amount2025 = fmtMoney(c2025.abs()),
            amount2026 = fmtMoney(c2026.abs()),
            lastDate2025 = if (maxLabelC2025.isBlank()) "—" else fmtDateLabel(maxLabelC2025),
            lastDate2026 = if (maxLabelC2026.isBlank()) "—" else fmtDateLabel(maxLabelC2026),
            reception2025 = fmtMoney(r2025),
            reception2026 = fmtMoney(r2026),
            receptionDate2025 = if (maxLabelR2025.isBlank()) "—" else fmtDateLabel(maxLabelR2025),
            receptionDate2026 = if (maxLabelR2026.isBlank()) "—" else fmtDateLabel(maxLabelR2026),
            surstock = fmtMoney(surstockSum),
            transfert2026 = fmtMoney(t2026.abs())
        )
    }

    suspend fun stocks(code: String): List<StockRow> = withContext(Dispatchers.IO) {
        val q = "select=code_sap,code_ocp,designation,magasin,division,bin,quantite,unite,prix_unitaire,valeur_stock,devise,date_em,derniere_sortie&or=(code_sap.eq.${enc(code)},code_ocp.eq.${enc(code)})&limit=100"
        parseStocks(get("stock", q))
    }

    /** Stock multiple : jusqu'à 15 codes SAP/OCP → qté, bin, cons 2025/2026 (mvt 261,262,201,202). */
    suspend fun multiStockLookup(codes: List<String>): List<MultiStockRow> = withContext(Dispatchers.IO) {
        val consMvt = setOf("261", "262", "201", "202")
        fun yearOf(d: String): Int? {
            val s = d.trim()
            Regex("""(\d{4})-(\d{2})-(\d{2})""").find(s)?.let { return it.groupValues[1].toIntOrNull() }
            Regex("""(\d{2})[./](\d{2})[./](\d{4})""").find(s)?.let { return it.groupValues[3].toIntOrNull() }
            Regex("""(\d{4})""").find(s)?.let { return it.groupValues[1].toIntOrNull() }
            return null
        }
        fun montantBd(raw: String): BigDecimal {
            val n = raw.replace(" ", "").replace(",", ".").trim()
            return n.toBigDecimalOrNull()?.abs() ?: BigDecimal.ZERO
        }
        val limited = codes.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(15)
        coroutineScope {
            limited.map { code ->
                async {
                    val stockRows = try {
                        stocks(code)
                    } catch (_: Exception) {
                        emptyList()
                    }
                    val sap = stockRows.firstOrNull()?.sap?.ifBlank { null }
                        ?: code.takeIf { !it.contains('.') }
                        ?: ""
                    val ocp = stockRows.firstOrNull()?.ocp?.ifBlank { null }
                        ?: code.takeIf { it.contains('.') }
                        ?: stockRows.firstOrNull()?.ocp.orEmpty()
                    val designation = stockRows.firstOrNull()?.designation?.ifBlank { "—" } ?: "—"
                    var qtySum = BigDecimal.ZERO
                    val bins = linkedSetOf<String>()
                    for (s in stockRows) {
                        val q = s.qty.replace(" ", "").replace(",", ".").trim()
                        q.toBigDecimalOrNull()?.let { qtySum = qtySum.add(it) }
                        s.emplacement.trim().takeIf { it.isNotEmpty() && it != "null" }?.let { bins.add(it) }
                    }
                    val qtyStr = if (stockRows.isEmpty()) "—"
                    else qtySum.stripTrailingZeros().toPlainString()
                    val binStr = if (bins.isEmpty()) "—" else bins.joinToString(separator = "\u000A")

                    var c25 = BigDecimal.ZERO
                    var c26 = BigDecimal.ZERO
                    val mvts = try {
                        movements(code)
                    } catch (_: Exception) {
                        emptyList()
                    }
                    for (m in mvts) {
                        val cm = m.codeMouvement.trim()
                        if (cm !in consMvt) continue
                        val y = yearOf(m.date) ?: continue
                        // Cons = total quantités (pas montant)
                        val qRaw = m.quantite.replace(" ", "").replace(",", ".").trim()
                        val qAbs = qRaw.toBigDecimalOrNull()?.abs() ?: BigDecimal.ZERO
                        when (y) {
                            2025 -> c25 = c25.add(qAbs)
                            2026 -> c26 = c26.add(qAbs)
                        }
                    }
                    MultiStockRow(
                        sap = sap.ifBlank { if (code.contains('.')) "—" else code },
                        ocp = ocp.ifBlank { if (code.contains('.')) code else "—" },
                        designation = if (stockRows.isEmpty() && mvts.isEmpty()) "Non trouvé" else designation,
                        qty = qtyStr,
                        bin = binStr,
                        cons2025 = c25.stripTrailingZeros().toPlainString(),
                        cons2026 = c26.stripTrailingZeros().toPlainString()
                    )
                }
            }.awaitAll()
        }
    }

    suspend fun movements(
        code: String,
        magasin: String = "",
        codeMouvement: String = "",
        dateFrom: String = "",
        dateTo: String = ""
    ): List<MovementRow> = withContext(Dispatchers.IO) {
        val trimmed = code.trim()
        val parts = mutableListOf<String>()
        if (trimmed.contains('.')) {
            parts += "code_ocp=eq.${enc(trimmed)}"
        } else {
            parts += "or=(code_sap.eq.${enc(trimmed)},code_ocp.eq.${enc(trimmed)})"
        }
        val mag = magasin.trim()
        if (mag.isNotBlank()) parts += "magasin=ilike.*${enc(mag)}*"
        val cm = codeMouvement.trim()
        if (cm.isNotBlank()) parts += "code_mouvement=eq.${enc(cm)}"
        parts += "select=*"
        parts += "limit=300"
        var rows = parseMovements(get("Mb51", parts.joinToString("&")))
        // Filtre dates côté client (formats variables)
        fun toKey(d: String): String? {
            val s = d.trim()
            if (s.isBlank()) return null
            // YYYY-MM-DD
            Regex("""^(\d{4})-(\d{2})-(\d{2})""").find(s)?.let {
                return it.groupValues[1] + it.groupValues[2] + it.groupValues[3]
            }
            // DD.MM.YYYY or DD/MM/YYYY
            Regex("""^(\d{2})[./](\d{2})[./](\d{4})""").find(s)?.let {
                return it.groupValues[3] + it.groupValues[2] + it.groupValues[1]
            }
            return null
        }
        val fromKey = toKey(dateFrom)
        val toKey = toKey(dateTo)
        if (fromKey != null || toKey != null) {
            rows = rows.filter { row ->
                val k = toKey(row.date) ?: return@filter true
                if (fromKey != null && k < fromKey) return@filter false
                if (toKey != null && k > toKey) return@filter false
                true
            }
        }
        // Filet de sécurité magasin / code mouvement (si filtre serveur partiel)
        if (mag.isNotBlank()) {
            val m = mag.uppercase()
            rows = rows.filter { it.magasin.uppercase().contains(m) }
        }
        if (cm.isNotBlank()) {
            rows = rows.filter { it.codeMouvement.trim() == cm }
        }
        rows
    }

    /** Recherche multicritères Mm03 (ET entre critères non vides). */
    suspend fun organizationsSearch(
        code: String = "",
        designation: String = "",
        descriptif: String = "",
        famille: String = ""
    ): List<OrgRow> = withContext(Dispatchers.IO) {
        val parts = mutableListOf<String>()
        val c = code.trim()
        if (c.isNotBlank()) {
            if (c.contains('.')) {
                parts += "code_ocp=eq.${enc(c)}"
            } else {
                parts += "or=(code_sap.eq.${enc(c)},code_ocp.eq.${enc(c)})"
            }
        }
        val d = designation.trim()
        if (d.isNotBlank()) {
            parts += "description=ilike.*${enc(d)}*"
        }
        val desc = descriptif.trim()
        if (desc.isNotBlank()) {
            parts += "descriptif=ilike.*${enc(desc)}*"
        }
        val f = famille.trim()
        if (f.isNotBlank()) {
            parts += "famille=eq.${enc(f)}"
        }
        if (parts.isEmpty()) return@withContext emptyList()
        val q = parts.joinToString("&") + "&select=*&limit=100"
        try {
            parseOrg(get("Mm03", q))
        } catch (e: Exception) {
            // Si colonne famille absente, retenter sans ce filtre
            if (f.isNotBlank() && parts.any { it.startsWith("famille=") }) {
                val withoutFamille = parts.filterNot { it.startsWith("famille=") }
                if (withoutFamille.isEmpty()) return@withContext emptyList()
                parseOrg(get("Mm03", withoutFamille.joinToString("&") + "&select=*&limit=100"))
            } else {
                throw e
            }
        }
    }

    suspend fun organizationsByCode(code: String): List<OrgRow> =
        organizationsSearch(code = code)

    suspend fun organizationsByDescriptif(search: String): List<OrgRow> =
        organizationsSearch(descriptif = search)

    suspend fun organizations(search: String): List<OrgRow> {
        val t = search.trim()
        return if (t.any { it.isLetter() }) organizationsSearch(descriptif = t)
        else organizationsSearch(code = t)
    }

    private suspend fun pagedValues(select: String, pageSize: Int = 1000): List<JSONArray> {
        val pages = mutableListOf<JSONArray>()
        var offset = 0
        while (true) {
            val page = JSONArray(get("stock", "select=$select&limit=$pageSize&offset=$offset"))
            if (page.length() == 0) break
            pages += page
            if (page.length() < pageSize) break
            offset += pageSize
        }
        return pages
    }


    /** Top N articles par valeur_stock (table stock). */
    suspend fun topStockArticles(limit: Int = 15, magasinEq: String? = null): List<TopArticleRow> = withContext(Dispatchers.IO) {
        val pages = mutableListOf<JSONObject>()
        var offset = 0
        while (offset < 20000) {
            val filter = if (magasinEq != null) "magasin=eq.${enc(magasinEq)}&" else ""
            val arr = try {
                JSONArray(get("stock", "${filter}select=code_sap,code_ocp,designation,valeur_stock,magasin&limit=1000&offset=$offset"))
            } catch (_: Exception) { break }
            for (i in 0 until arr.length()) pages += arr.getJSONObject(i)
            if (arr.length() < 1000) break
            offset += 1000
        }
        pages.mapNotNull { o ->
            val raw = o.opt("valeur_stock")?.toString()
                ?.replace(" ", "")?.replace(",", ".")?.trim() ?: return@mapNotNull null
            val v = raw.toBigDecimalOrNull() ?: return@mapNotNull null
            TopArticleRow(
                sap = o.opt("code_sap")?.toString()?.trim().orEmpty(),
                ocp = o.opt("code_ocp")?.toString()?.trim().orEmpty(),
                designation = o.optString("designation"),
                value = formatMoney(v.abs()) + " MAD",
                valueBd = v.abs(),
                detail = o.optString("magasin")
            )
        }.sortedByDescending { it.valueBd }.let { sorted ->
            if (limit >= sorted.size) sorted else sorted.take(limit)
        }
    }

    /** Top N articles Mb51 : somme algébrique montant par code_sap, filtres codes + année. */
    /**
     * Top mouvements SANS regroupement : 1 ligne Mb51 = 1 entrée.
     * onlyNegative=true → uniquement sorties (montant < 0), affichage avec signe -.
     */
    suspend fun topMovementArticles(
        codes: Set<String>,
        year: Int?,
        limit: Int = 15,
        magasinEq: String? = null,
        onlyNegative: Boolean = false
    ): List<TopArticleRow> = withContext(Dispatchers.IO) {
        val codeList = codes.joinToString(",")
        val top = mutableListOf<TopArticleRow>()
        var totalAbs = java.math.BigDecimal.ZERO

        fun parseMontantSigned(o: org.json.JSONObject): java.math.BigDecimal? {
            for (k in listOf("montant_di", "montant", "Montant", "dmbtr")) {
                if (!o.has(k) || o.isNull(k)) continue
                var raw = o.opt(k)?.toString()
                    ?.replace("\u00a0", "")
                    ?.replace(" ", "")
                    ?.replace("MAD", "")
                    ?.trim() ?: continue
                if (raw.isEmpty() || raw == "null") continue
                if (raw.contains(",") && raw.contains(".")) raw = raw.replace(".", "").replace(",", ".")
                else if (raw.contains(",")) raw = raw.replace(",", ".")
                return raw.toBigDecimalOrNull()
            }
            return null
        }
        fun parseCode(o: org.json.JSONObject): String {
            for (k in listOf("code_mouvement", "Code mouvement", "bwart", "code_mvt")) {
                if (!o.has(k) || o.isNull(k)) continue
                var v = o.opt(k)?.toString()?.trim() ?: continue
                if (v.isEmpty() || v == "null") continue
                v = v.substringBefore(".").substringBefore(" ").trim()
                return v.trimStart('0').ifEmpty { "0" }
            }
            return ""
        }
        fun parseYear(o: org.json.JSONObject): Int? {
            for (k in listOf("date", "date_de_saisie", "Date", "budat")) {
                if (!o.has(k) || o.isNull(k)) continue
                val ds = o.opt(k)?.toString()?.trim() ?: continue
                if (ds.isEmpty() || ds == "null") continue
                return Regex("""(20\d{2})""").find(ds)?.groupValues?.getOrNull(1)?.toIntOrNull()
            }
            return null
        }
        fun push(o: org.json.JSONObject) {
            val code = parseCode(o)
            if (code.isEmpty() || code !in codes) return
            if (year != null && parseYear(o) != year) return
            if (magasinEq != null && o.optString("magasin").trim().uppercase() != magasinEq.uppercase()) return
            val signed = parseMontantSigned(o) ?: return
            if (onlyNegative && signed >= java.math.BigDecimal.ZERO) return
            val m = signed.abs()
            totalAbs += m
            val sap = o.opt("code_sap")?.toString()?.trim().orEmpty()
            val ocp = o.opt("code_ocp")?.toString()?.trim().orEmpty()
            val des = o.optString("designation")
            val mag = o.optString("magasin")
            val date = o.optString("date")
            val display = if (onlyNegative || signed < java.math.BigDecimal.ZERO) {
                "-${formatMoney(m)} MAD"
            } else {
                "${formatMoney(m)} MAD"
            }
            val candidate = TopArticleRow(
                sap = sap,
                ocp = ocp,
                designation = des,
                value = display,
                valueBd = m,
                detail = listOf(mag, date).filter { it.isNotBlank() && it != "null" }.joinToString(" · ")
            )
            if (top.size < limit) {
                top += candidate
                top.sortByDescending { it.valueBd }
            } else if (m > top.last().valueBd) {
                top[top.lastIndex] = candidate
                top.sortByDescending { it.valueBd }
            }
        }

        var offset = 0
        while (offset < 100000) {
            val q = buildString {
                append("code_mouvement=in.($codeList)")
                if (year != null) append("&date=gte.$year-01-01&date=lte.$year-12-31")
                if (magasinEq != null) append("&magasin=eq.$magasinEq")
                append("&select=code_sap,code_ocp,designation,montant_di,montant,code_mouvement,date,magasin")
                append("&limit=1000&offset=$offset")
            }
            val arr = try {
                JSONArray(get("Mb51", q))
            } catch (_: Exception) {
                break
            }
            for (i in 0 until arr.length()) push(arr.getJSONObject(i))
            if (arr.length() < 1000) break
            offset += 1000
        }

        if (top.isEmpty()) {
            totalAbs = java.math.BigDecimal.ZERO
            offset = 0
            while (offset < 100000) {
                val q = buildString {
                    append("code_mouvement=in.($codeList)")
                    if (magasinEq != null) append("&magasin=eq.$magasinEq")
                    append("&select=code_sap,code_ocp,designation,montant_di,montant,code_mouvement,date,magasin")
                    append("&limit=1000&offset=$offset")
                }
                val arr = try {
                    JSONArray(get("Mb51", q))
                } catch (_: Exception) {
                    try {
                        JSONArray(get("Mb51", "code_mouvement=in.($codeList)&select=*&limit=1000&offset=$offset"))
                    } catch (_: Exception) {
                        break
                    }
                }
                for (i in 0 until arr.length()) push(arr.getJSONObject(i))
                if (arr.length() < 1000) break
                offset += 1000
            }
        }

        Top15LastTotal.set(totalAbs)
        top.sortedByDescending { it.valueBd }
    }

    suspend fun articleCount(): Int = withContext(Dispatchers.IO) {
        val codes = mutableSetOf<String>()
        var offset = 0
        while (offset < 100000) {
            val page = try {
                JSONArray(get("stock", "select=code_sap&limit=1000&offset=$offset"))
            } catch (_: Exception) {
                break
            }
            if (page.length() == 0) break
            for (i in 0 until page.length()) {
                page.getJSONObject(i).optString("code_sap").trim()
                    .takeIf { it.isNotEmpty() && it != "null" }?.let(codes::add)
            }
            if (page.length() < 1000) break
            offset += 1000
        }
        // Repli table Stocks (casse alternative)
        if (codes.isEmpty()) {
            offset = 0
            while (offset < 100000) {
                val page = try {
                    JSONArray(get("Stocks", "select=code_sap&limit=1000&offset=$offset"))
                } catch (_: Exception) {
                    break
                }
                if (page.length() == 0) break
                for (i in 0 until page.length()) {
                    page.getJSONObject(i).optString("code_sap").trim()
                        .takeIf { it.isNotEmpty() && it != "null" }?.let(codes::add)
                }
                if (page.length() < 1000) break
                offset += 1000
            }
        }
        codes.size
    }

    suspend fun stockValue(): String = withContext(Dispatchers.IO) {
        fun parseVal(raw: String?): BigDecimal? {
            if (raw.isNullOrBlank() || raw == "null") return null
            var s = raw.replace(" ", "").replace(" ", "").replace("MAD", "").trim()
            if (s.contains(",") && s.contains(".")) s = s.replace(".", "").replace(",", ".")
            else if (s.contains(",")) s = s.replace(",", ".")
            return s.toBigDecimalOrNull()
        }
        var total = BigDecimal.ZERO
        var offset = 0
        var any = false
        while (offset < 100000) {
            val page = try {
                JSONArray(get("stock", "select=valeur_stock&limit=1000&offset=$offset"))
            } catch (_: Exception) {
                break
            }
            if (page.length() == 0) break
            any = true
            for (i in 0 until page.length()) {
                val v = parseVal(page.getJSONObject(i).opt("valeur_stock")?.toString())
                if (v != null) total = total.add(v.abs())
            }
            if (page.length() < 1000) break
            offset += 1000
        }
        if (!any) {
            offset = 0
            while (offset < 100000) {
                val page = try {
                    JSONArray(get("Stocks", "select=valeur_stock&limit=1000&offset=$offset"))
                } catch (_: Exception) {
                    break
                }
                if (page.length() == 0) break
                for (i in 0 until page.length()) {
                    val v = parseVal(page.getJSONObject(i).opt("valeur_stock")?.toString())
                    if (v != null) total = total.add(v.abs())
                }
                if (page.length() < 1000) break
                offset += 1000
            }
        }
        formatMoney(total)
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun parseStocks(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            StockRow(
                o.optString("code_sap"), o.optString("code_ocp"), o.optString("designation"),
                o.optString("magasin"), o.optString("division"), o.optString("bin"), o.optString("quantite"),
                o.optString("unite"), o.optString("prix_unitaire"), o.optString("valeur_stock"),
                o.optString("devise"), o.optString("date_em"), o.optString("derniere_sortie")
            )
        }
    }

    private fun parseMovements(s: String) = JSONArray(s).let { a ->
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            fun str(vararg keys: String): String {
                for (k in keys) {
                    if (o.has(k) && !o.isNull(k)) {
                        val v = o.opt(k)?.toString()?.trim().orEmpty()
                        if (v.isNotEmpty() && v != "null") return v
                    }
                }
                return ""
            }
            MovementRow(
                sap = str("code_sap", "Code SAP", "codeSAP", "matnr", "Material"),
                ocp = str("code_ocp", "Code OCP", "codeOCP", "ocp"),
                designation = str("designation", "Designation", "maktx", "Material Description"),
                magasin = str("magasin", "Magasin", "lgort", "Storage Location", "storage_location"),
                quantite = str("quantite", "Quantite", "quantity", "menge", "qty"),
                unite = str("unite", "Unite", "meins", "unit", "uom"),
                montant = str("montant_di", "montant", "Montant", "dmbtr", "amount", "valeur", "amount_lc"),
                codeMouvement = str("code_mouvement", "Code mouvement", "bwart", "movement_type", "type_mouvement"),
                ordre = str("ordre", "Ordre", "aufnr", "order", "order_number"),
                reservation = str("reservation", "Reservation", "rsnum", "réservation"),
                po = str("po", "PO", "ebeln", "purchase_order", "commande"),
                reference = str("reference", "Reference", "Référence", "référence", "ref", "Ref", "xref", "sgtxt"),
                docArticle = str("doc_article", "Doc article", "mblnr", "material_document", "numero_document", "doc"),
                date = str("date", "Date", "budat", "date_mouvement", "posting_date"),
                partenaire = str("partenaire", "Partenaire", "division", "ol", "OL")
            )
        }
    }

    private fun parseOrg(s: String) = JSONArray(s).let { a ->
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            fun str(vararg keys: String): String {
                for (k in keys) {
                    if (o.has(k) && !o.isNull(k)) {
                        val v = o.opt(k)?.toString()?.trim().orEmpty()
                        if (v.isNotEmpty() && v != "null") return v
                    }
                }
                return ""
            }
            OrgRow(
                sap = str("code_sap", "code_article"),
                ocp = str("code_ocp"),
                designation = str("description", "designation"),
                descriptif = str("descriptif"),
                famille = str("famille", "Famille")
            )
        }
    }
}

private fun formatMoney(value: BigDecimal): String =
    NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
        isGroupingUsed = true
    }.format(value)

private fun formatMoney(raw: String, currency: String): String =
    "${formatMoney(raw.toBigDecimalOrNull() ?: BigDecimal.ZERO)} $currency"

private fun formatQty(raw: String): String {
    val n = raw.toBigDecimalOrNull() ?: return raw
    return NumberFormat.getNumberInstance(Locale.FRANCE).apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 3
        isGroupingUsed = true
    }.format(n)
}

private fun dash(s: String): String = if (s.isBlank()) "—" else s

private fun formatCodeNum(raw: String): String {
    if (raw.isBlank()) return "—"
    val d = raw.toBigDecimalOrNull() ?: return raw
    return d.stripTrailingZeros().toPlainString()
}

/** Code OCP : conserver les zéros finaux (ex. 20492.25010, pas 20492.2501). */
private fun formatOcp(raw: String): String {
    val s = raw.trim()
    if (s.isBlank() || s == "null") return "—"
    // Si déjà une chaîne avec point : ne pas passer par un Double (perd les zéros)
    if (s.contains('.')) {
        val parts = s.split('.', limit = 2)
        val intPart = parts[0].filter { it.isDigit() || it == '-' }
        var dec = parts.getOrElse(1) { "" }.filter { it.isDigit() }
        // Au moins 5 décimales si le code OCP standard en a 5
        if (dec.length < 5) dec = dec.padEnd(5, '0')
        return "$intPart.$dec"
    }
    // Entier seul → 5 zéros
    val digits = s.filter { it.isDigit() }
    return if (digits.isNotEmpty()) "$digits.00000" else s
}


private fun copyToClipboard(context: Context, label: String, value: String, toastMsg: String) {
    if (value.isBlank()) return
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, value))
    Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CopyableCodeLine(
    text: String,
    codeValue: String,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit = 14.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val toast = LocalAppStrings.current.codeCopied
    Text(
        text,
        fontSize = fontSize,
        fontWeight = fontWeight,
        color = color,
        lineHeight = fontSize * 1.2f,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier.combinedClickable(
            onClick = {},
            onLongClick = { copyToClipboard(context, "code", codeValue, toast) }
        )
    )
}


/** Code SAP : entier si possible */
private fun formatSap(raw: String): String {
    val s = raw.trim()
    if (s.isBlank() || s == "null") return "—"
    // Ne pas convertir en nombre (évite perte de zéros / notation scientifique)
    return s.substringBefore(".").substringBefore(" ").trim().ifBlank { s }
}


private fun formatDate(raw: String): String {
    if (raw.isBlank()) return "—"
    return try {
        val normalized = raw.replace("Z", "").substringBefore("+")
        val input = when {
            normalized.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            normalized.contains(" ") && normalized.length > 16 ->
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }
        val d = input.parse(normalized) ?: return raw
        if (normalized.length > 10)
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.FRANCE).format(d)
        else
            SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(d)
    } catch (_: Exception) {
        raw
    }
}


@Composable
private fun LoginScreen(api: SupabaseClient, onSuccess: (String) -> Unit) {
    val c = LocalMobiColors.current
    val context = LocalContext.current
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()

    val s = LocalAppStrings.current
    fun tryLogin() {
        keyboard?.hide()
        if (user.trim().isEmpty() || pass.isEmpty()) {
            error = s.enterCredentials
            return
        }
        scope.launch {
            loading = true
            error = null
            runCatching { api.login(user.trim(), pass) }
                .onSuccess { ok ->
                    if (ok) {
                        // rôle admin/user stocké pour messages d'équipe
                        val prefs = context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
                        prefs.edit().putString(PrefUserRole, api.lastLoginRole).apply()
                        onSuccess(user.trim())
                    } else error = s.wrongCredentials
                }
                .onFailure { error = friendlyError(it.message, s) }
            loading = false
        }
    }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(HeaderGreen)
                    .padding(vertical = 28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "JORF FERTILIZERS COMPANY I",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "MobiStock",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 28.dp)
                    .padding(top = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    s.login,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.textPrimary
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Saisissez vos identifiants",
                    fontSize = 14.sp,
                    color = c.textSecondary
                )
                Spacer(Modifier.height(28.dp))
                OutlinedTextField(
                    value = user,
                    onValueChange = { user = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    // Espace réservé = largeur icône œil → texte centré comme le mot de passe
                    trailingIcon = {
                        Spacer(Modifier.width(48.dp))
                    },
                    placeholder = {
                        Text(
                            s.identifier,
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = c.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary
                    )
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = pass,
                    onValueChange = { pass = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            s.password,
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        Box(
                            Modifier.width(48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) {
                                        Icons.Default.Visibility
                                    } else {
                                        Icons.Default.VisibilityOff
                                    },
                                    contentDescription = if (passwordVisible) {
                                        "Masquer le mot de passe"
                                    } else {
                                        "Afficher le mot de passe"
                                    },
                                    tint = c.textSecondary
                                )
                            }
                        }
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = c.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { tryLogin() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary
                    )
                )
                if (error != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        error!!,
                        color = Color(0xFFDC2626),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { tryLogin() },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HeaderGreen)
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            s.connect,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun App(
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    lang: String,
    onLangChange: (String) -> Unit,
    onLogout: () -> Unit = {}
) {
    val context = LocalContext.current
    val api = remember { SupabaseClient(context) }
    val c = LocalMobiColors.current
    val prefs = remember { context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val s = LocalAppStrings.current
    // Session 240 min : déconnexion même si l'app reste ouverte (toutes les 60 s)
    // force_logout Supabase : aussi vérifié dans la même boucle
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(60_000)
            val loginAt = prefs.getLong(PrefLoginAt, 0L)
            if (loginAt > 0L && System.currentTimeMillis() - loginAt >= SESSION_MAX_MS) {
                onLogout()
                continue
            }
            val user = prefs.getString(PrefLoginUser, "") ?: ""
            if (user.isNotBlank()) {
                runCatching { api.shouldForceLogout(user) }
                    .onSuccess { force -> if (force) onLogout() }
            }
        }
    }
    var page by remember { mutableStateOf(0) }
    var stockRows by remember { mutableStateOf<List<StockRow>?>(null) }
    var movementRows by remember { mutableStateOf<List<MovementRow>?>(null) }
    var orgRows by remember { mutableStateOf<List<OrgRow>?>(null) }
    var subScreen by remember { mutableStateOf<String?>(null) }
    var teamMessages by remember { mutableStateOf<List<TeamMessage>>(emptyList()) }
    fun readPrefKey(user: String): String =
        if (user.isBlank()) PrefReadTeamMsgs else "${PrefReadTeamMsgs}_$user"

    var currentLoginUser by remember {
        mutableStateOf(prefs.getString(PrefLoginUser, "") ?: "")
    }
    var readMsgIds by remember(currentLoginUser) {
        mutableStateOf(
            prefs.getString(readPrefKey(currentLoginUser), "")
                ?.split(",")
                ?.map { it.trim() }
                ?.filter { it.isNotEmpty() }
                ?.toSet()
                ?: emptySet()
        )
    }
    // Recharger les "lus" si l'identifiant change
    LaunchedEffect(currentLoginUser) {
        readMsgIds = prefs.getString(readPrefKey(currentLoginUser), "")
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.toSet()
            ?: emptySet()
    }
    fun markMessageRead(id: String) {
        if (id in readMsgIds) return
        readMsgIds = readMsgIds + id
        prefs.edit().putString(readPrefKey(currentLoginUser), readMsgIds.joinToString(",")).apply()
    }
    fun commentReadPrefKey(user: String): String =
        if (user.isBlank()) PrefReadTeamComments else "${PrefReadTeamComments}_$user"

    var readCommentIds by remember(currentLoginUser) {
        mutableStateOf(
            prefs.getString(commentReadPrefKey(currentLoginUser), "")
                ?.split(",")
                ?.map { it.trim() }
                ?.filter { it.isNotEmpty() }
                ?.toSet()
                ?: emptySet()
        )
    }
    var allComments by remember { mutableStateOf<List<TeamMessageComment>>(emptyList()) }

    fun markCommentsRead(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val next = readCommentIds + ids.map { it.trim() }.filter { it.isNotEmpty() }
        if (next.size == readCommentIds.size) return
        readCommentIds = next
        prefs.edit().putString(commentReadPrefKey(currentLoginUser), next.joinToString(",")).apply()
    }

    val unreadMessageCount = teamMessages.count { it.id !in readMsgIds }
    val unreadCommentCount = allComments.count { it.id !in readCommentIds }
    val unreadCount = unreadMessageCount + unreadCommentCount
    LaunchedEffect(Unit) {
        runCatching { api.teamMessages() }.onSuccess { teamMessages = it }
        runCatching { api.allTeamMessageComments() }.onSuccess { allComments = it }
    }
    fun unreadCommentsForMessage(messageId: String): Int =
        allComments.count { it.messageId == messageId && it.id !in readCommentIds }
    var isAdmin by remember {
        mutableStateOf(
            (prefs.getString(PrefUserRole, "user") ?: "user").equals("admin", ignoreCase = true)
        )
    }
    LaunchedEffect(Unit) {
        val u = prefs.getString(PrefLoginUser, "") ?: ""
        currentLoginUser = u
        if (u.isNotBlank()) {
            runCatching { api.userRole(u) }.onSuccess { role ->
                prefs.edit().putString(PrefUserRole, role).apply()
                isAdmin = role.equals("admin", ignoreCase = true)
            }
        }
    }

    // Messages d'équipe : chargement immédiat + rafraîchissement pour le badge (sans ouvrir la cloche)
    LaunchedEffect(Unit) {
        while (isActive) {
            runCatching { api.teamMessages() }
                .onSuccess { teamMessages = it }
            delay(20_000)
        }
    }

    // Stats globales — chargées UNE SEULE FOIS pour toute la session
    var articleCount by remember { mutableStateOf("—") }
    var stockValue by remember { mutableStateOf("—") }
    var statsLoaded by remember { mutableStateOf(false) }
    var statsLoading by remember { mutableStateOf(false) }
    var statsError by remember { mutableStateOf<String?>(null) }
    // Tableau de bord mouvements — cache session (comme stats accueil)
    var conso2025 by remember { mutableStateOf("—") }
    var conso2026 by remember { mutableStateOf("—") }
    var consoDate2025 by remember { mutableStateOf("—") }
    var consoDate2026 by remember { mutableStateOf("—") }
    var recept2025 by remember { mutableStateOf("—") }
    var recept2026 by remember { mutableStateOf("—") }
    var receptDate2025 by remember { mutableStateOf("—") }
    var receptDate2026 by remember { mutableStateOf("—") }
    var surstock by remember { mutableStateOf("—") }
    var transfert2026 by remember { mutableStateOf("—") }
    var consoLoaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!statsLoaded) {
            statsLoading = true
            // Chargements indépendants : un échec ne bloque pas l'autre
            runCatching {
                articleCount = api.articleCount().toString()
            }.onFailure {
                articleCount = "—"
            }
            runCatching {
                stockValue = api.stockValue()
            }.onFailure {
                stockValue = "—"
            }
            statsLoaded = true
            statsLoading = false
        }
        if (!consoLoaded) {
            runCatching { api.consumptionByYear() }
                .onSuccess { stats ->
                    conso2025 = stats.amount2025
                    conso2026 = stats.amount2026
                    consoDate2025 = stats.lastDate2025
                    consoDate2026 = stats.lastDate2026
                    recept2025 = stats.reception2025
                    recept2026 = stats.reception2026
                    receptDate2025 = stats.receptionDate2025
                    receptDate2026 = stats.receptionDate2026
                    surstock = stats.surstock
                    transfert2026 = stats.transfert2026
                    consoLoaded = true
                }
        }
    }

    // Recharger stock si encore "—" (ex. échec réseau au 1er lancement)
    LaunchedEffect(subScreen) {
        if (subScreen == "fullDash" && (articleCount == "—" || stockValue == "—")) {
            runCatching {
                if (articleCount == "—") articleCount = api.articleCount().toString()
            }
            runCatching {
                if (stockValue == "—") stockValue = api.stockValue()
            }
        }
    }

    if (stockRows != null) {
        StockResultPage(
            rows = stockRows!!,
            onBack = { stockRows = null },
            onHome = { stockRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (movementRows != null) {
        MovementResultPage(
            rows = movementRows!!,
            onBack = { movementRows = null },
            onHome = { movementRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "movement") {
        MovementSearchPage(
            api = api,
            onBack = { subScreen = null },
            onResult = { movementRows = it },
            conso2025 = conso2025,
            conso2026 = conso2026,
            consoDate2025 = consoDate2025,
            consoDate2026 = consoDate2026
        )
        return
    }
    if (orgRows != null) {
        OrgResultPage(
            rows = orgRows!!,
            onBack = { orgRows = null },
            onHome = { orgRows = null; subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "org") {
        OrgSearchPage(
            api = api,
            onBack = { subScreen = null },
            onResult = { orgRows = it }
        )
        return
    }
    if (subScreen == "fullDash") {
        FullDashboardScreen(
            articleCount = articleCount,
            stockValue = stockValue,
            conso2025 = conso2025,
            conso2026 = conso2026,
            consoDate2025 = consoDate2025,
            consoDate2026 = consoDate2026,
            recept2025 = recept2025,
            recept2026 = recept2026,
            receptDate2025 = receptDate2025,
            receptDate2026 = receptDate2026,
            surstock = surstock,
            transfert2026 = transfert2026,
            onBack = { subScreen = null },
            onOpenCard = { type -> subScreen = "card:$type" }
        )
        return
    }
    if (subScreen != null && subScreen!!.startsWith("card:")) {
        CardTop15Screen(
            api = api,
            cardType = subScreen!!.removePrefix("card:"),
            onBack = { subScreen = "fullDash" },
            onHome = { subScreen = null; page = 0 }
        )
        return
    }
    if (subScreen == "catalog") {
        CatalogScreen(
            api = api,
            isAdmin = isAdmin,
            onBack = { subScreen = null },
            onHome = { subScreen = null; page = 0 },
            onAdd = { subScreen = "catalogAdd" }
        )
        return
    }
    if (subScreen == "catalogAdd") {
        CatalogAddScreen(
            api = api,
            onBack = { subScreen = "catalog" },
            onSaved = { subScreen = "catalog" }
        )
        return
    }
    if (subScreen == "messages") {

        LaunchedEffect(Unit) {
            runCatching { api.teamMessages() }
                .onSuccess { teamMessages = it }
        }
        LaunchedEffect(Unit) {
            runCatching { api.allTeamMessageComments() }.onSuccess { allComments = it }
        }
        TeamMessageListScreen(
            messages = teamMessages,
            readIds = readMsgIds,
            unreadCommentCounts = teamMessages.associate { m ->
                m.id to allComments.count { it.messageId == m.id && it.id !in readCommentIds }
            },
            isAdmin = isAdmin,
            onBack = { subScreen = null },
            onOpen = { id -> subScreen = "message:$id" },
            onCompose = { subScreen = "messageCompose" },
            onDelete = { id ->
                scope.launch {
                    val ok = runCatching { api.deleteTeamMessage(id) }.getOrDefault(false)
                    if (ok) {
                        teamMessages = teamMessages.filter { it.id != id }
                        runCatching { api.teamMessages() }.onSuccess { teamMessages = it }
                    }
                }
            }
        )
        return
    }
    if (subScreen == "messageCompose") {
        TeamMessageComposeScreen(
            api = api,
            currentUser = currentLoginUser.ifBlank { prefs.getString(PrefLoginUser, "") ?: "" },
            onBack = { subScreen = "messages" },
            onSent = {
                scope.launch {
                    runCatching { api.teamMessages() }.onSuccess { teamMessages = it }
                }
                subScreen = "messages"
            }
        )
        return
    }
    if (subScreen != null && subScreen!!.startsWith("message:")) {
        val mid = subScreen!!.removePrefix("message:")
        val msg = teamMessages.find { it.id == mid }
        LaunchedEffect(mid) {
            markMessageRead(mid)
            runCatching { api.teamMessageComments(mid) }.onSuccess { list ->
                markCommentsRead(list.map { it.id })
                // refresh global comments cache
                runCatching { api.allTeamMessageComments() }.onSuccess { allComments = it }
            }
        }
        TeamMessageDetailScreen(
            api = api,
            message = msg,
            isAdmin = isAdmin,
            currentUser = currentLoginUser.ifBlank { prefs.getString(PrefLoginUser, "") ?: "" },
            currentUserIsAdmin = isAdmin,
            onBack = { subScreen = "messages" },
            onHome = { subScreen = null; page = 0 },
            onCommentsChanged = {
                runCatching { api.allTeamMessageComments() }.onSuccess { allComments = it }
            }
        )
        return
    }

    if (subScreen == "multiStock") {
        MultiStockScreen(
            api = api,
            onBack = { subScreen = null },
            onHome = { subScreen = null; page = 0 }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        if (page == 1) {
            SettingsPage(api, isDark = isDark, onThemeChange = onThemeChange, lang = lang, onLangChange = onLangChange, onLogout = onLogout)
        } else {
            HomePage(
                api = api,
                articleCount = articleCount,
                stockValue = stockValue,
                statsLoading = statsLoading,
                conso2025 = conso2025,
                conso2026 = conso2026,
                consoDate2025 = consoDate2025,
                consoDate2026 = consoDate2026,
                recept2025 = recept2025,
                recept2026 = recept2026,
                receptDate2025 = receptDate2025,
                receptDate2026 = receptDate2026,
                surstock = surstock,
                transfert2026 = transfert2026,
                onStockResult = { stockRows = it },
                onOpenMovement = { subScreen = "movement" },
                onOpenOrg = { subScreen = "org" },
                onOpenCatalog = { subScreen = "catalog" },
                onOpenFullDash = { subScreen = "fullDash" },
                onOpenCard = { type -> subScreen = "card:$type" },
                messageBadge = unreadCount,
                onOpenMessages = { subScreen = "messages" }
            )
        }
        BottomNavigationBar(
            page = page,
            onPage = {
                page = it
                if (subScreen == "catalog" || subScreen == "catalogAdd" || subScreen == "messages" ||
                    subScreen == "multiStock" || subScreen?.startsWith("message:") == true
                ) {
                    subScreen = null
                }
            },
            catalogActive = subScreen == "catalog" || subScreen == "catalogAdd",
            onCatalog = { subScreen = "catalog" },
            messagesActive = subScreen == "messages" || (subScreen?.startsWith("message:") == true),
            onMessages = { subScreen = "messages" },
            multiStockActive = subScreen == "multiStock",
            onMultiStock = { subScreen = "multiStock" },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    statsError?.let { msg ->
        AppDialog(msg) { statsError = null }
    }
}

@Composable
private fun HomePage(
    api: SupabaseClient,
    articleCount: String,
    stockValue: String,
    statsLoading: Boolean,
    conso2025: String = "—",
    conso2026: String = "—",
    consoDate2025: String = "—",
    consoDate2026: String = "—",
    recept2025: String = "—",
    recept2026: String = "—",
    receptDate2025: String = "—",
    receptDate2026: String = "—",
    surstock: String = "—",
    transfert2026: String = "—",
    onStockResult: (List<StockRow>) -> Unit,
    onOpenMovement: () -> Unit,
    onOpenOrg: () -> Unit,
    onOpenCatalog: () -> Unit = {},
    onOpenFullDash: () -> Unit = {},
    onOpenCard: (String) -> Unit = {},
    messageBadge: Int = 0,
    onOpenMessages: () -> Unit = {}
) {
    val strings = LocalAppStrings.current
    var stock by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    Surface(modifier = Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Header(badgeCount = messageBadge, onBellClick = onOpenMessages)
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
            ) {
                item {
                    // Chaîne de 6 cartes : 2 visibles par écran, défilement en boucle
                    val dashCards: List<Triple<String, Pair<String, String>, Pair<Color, ImageVector>>> = listOf(
                        Triple("Nombre d'articles", articleCount to "Articles en stock", Green to Icons.Default.Inventory2),
                        Triple("Valeur de stock", stockValue to "MAD", Blue to Icons.Default.AccountBalance),
                        Triple("Cons 2025", conso2025 to "MAJ : $consoDate2025", Blue to Icons.Default.TrendingDown),
                        Triple("Cons 2026", conso2026 to "MAJ : $consoDate2026", Blue to Icons.Default.TrendingUp),
                        Triple("Réception 2025", recept2025 to "MAJ : $receptDate2025 · 101·102", Purple to Icons.Default.MoveToInbox),
                        Triple("Réception 2026", recept2026 to "MAJ : $receptDate2026 · 101·102", Purple to Icons.Default.MoveToInbox),
                        Triple("Surstock", surstock to "MAGASIN MIN1", Color(0xFFE67E22) to Icons.Default.Store),
                        Triple("Transfert 2026", transfert2026 to "Code mvt 643 · 2026", Color(0xFF16A085) to Icons.Default.SwapHoriz)
                    )
                    val pageCount = 4
                    val loop = 300
                    val startPage = (loop / 2) - ((loop / 2) % pageCount)
                    val pagerState = rememberPagerState(initialPage = startPage) { loop }
                    var verticalDrag by remember { mutableStateOf(0f) }
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(118.dp)
                            .pointerInput(Unit) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        // Haut→bas ou bas→haut → Tableau de bord
                                        if (kotlin.math.abs(verticalDrag) > 80f) onOpenFullDash()
                                        verticalDrag = 0f
                                    },
                                    onVerticalDrag = { _, amount ->
                                        verticalDrag += amount
                                    }
                                )
                            },
                        beyondViewportPageCount = 1
                    ) { page ->
                        val pairIndex = page % pageCount
                        val left = dashCards[pairIndex * 2]
                        val right = dashCards[pairIndex * 2 + 1]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SummaryCard(
                                title = left.first,
                                value = left.second.first,
                                subtitle = left.second.second,
                                accent = left.third.first,
                                icon = left.third.second,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val t = cardTypeForTitle(left.first)
                                    if (t != null) onOpenCard(t)
                                }
                            )
                            SummaryCard(
                                title = right.first,
                                value = right.second.first,
                                subtitle = right.second.second,
                                accent = right.third.first,
                                icon = right.third.second,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val t = cardTypeForTitle(right.first)
                                    if (t != null) onOpenCard(t)
                                }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val realPage = pagerState.currentPage % pageCount
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        repeat(pageCount) { i ->
                            Box(
                                Modifier
                                    .padding(horizontal = 3.dp)
                                    .size(if (i == realPage) 8.dp else 6.dp)
                                    .clip(CircleShape)
                                    .background(if (i == realPage) Green else LocalMobiColors.current.border)
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
                item {
                    StockSearchBlock(
                        value = stock,
                        onValueChange = { stock = codeFilter(it) },
                        onSearch = {
                            keyboard?.hide()
                            val e = validate(stock)
                            if (e != null) dialog = e
                            else scope.launch {
                                loading = true
                                runCatching { api.stocks(stock.trim()) }
                                    .onSuccess { r ->
                                        if (r.isEmpty())
                                            dialog = "Aucun stock disponible pour cet article"
                                        else onStockResult(r)
                                    }
                                    .onFailure { dialog = friendlyError(it.message, strings) }
                                loading = false
                            }
                        }
                    )
                    Spacer(Modifier.height(20.dp))
                }
                item {
                    ModuleNavButton(
                        title = "Mouvements matières",
                        subtitle = LocalAppStrings.current.movementHistory,
                        emoji = "🔄",
                        accent = Blue,
                        background = BlueSoft,
                        onClick = onOpenMovement
                    )
                    Spacer(Modifier.height(12.dp))
                }
                item {
                    ModuleNavButton(
                        title = "Article d'organisation",
                        subtitle = LocalAppStrings.current.orgSearchHint,
                        emoji = "🏢",
                        accent = Purple,
                        background = PurpleSoft,
                        onClick = onOpenOrg
                    )
                    Spacer(Modifier.height(12.dp))
                }
                item {
                    Text(
                        "Work with love",
                        Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        color = LocalMobiColors.current.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Overlay uniquement pour les recherches, PAS pour les stats (déjà en cache)
    LoadingOverlay(loading)
    // Petit indicateur discret si stats encore en cours au 1er lancement
    if (statsLoading && !loading) {
        Box(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            contentAlignment = Alignment.Center
        ) { /* stats en arrière-plan, pas de popup bloquant */ }
    }
    dialog?.let { msg -> AppDialog(msg) { dialog = null } }
}

@Composable
private fun StockSearchBlock(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit
) {
    val strings = LocalAppStrings.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Green),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📦", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "SYNTHÈSE DES STOCKS",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary
                    )
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    placeholder = {
                        Text(
                            "Saisir Code SAP ou Code OCP",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.surfaceBg,
                        unfocusedContainerColor = LocalMobiColors.current.surfaceBg,
                        cursorColor = Green,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onSearch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    elevation = ButtonDefaults.buttonElevation(0.dp)
                ) {
                    Text("🔍", fontSize = 15.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "RECHERCHER",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    strings.searchBySapOcp,
                    fontSize = 12.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Green)
            )
        }
    }
}

@Composable
private fun ModuleNavButton(
    title: String,
    subtitle: String,
    emoji: String,
    accent: Color,
    background: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(emoji, fontSize = 18.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title.uppercase(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        subtitle,
                        fontSize = 12.sp,
                        color = LocalMobiColors.current.textSecondary
                    )
                }
                Text("→", fontSize = 18.sp, color = accent, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accent)
            )
        }
    }
}

@Composable
private fun MovementSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit,
    onResult: (List<MovementRow>) -> Unit,
    conso2025: String = "—",
    conso2026: String = "—",
    consoDate2025: String = "—",
    consoDate2026: String = "—"
) {
    val strings = LocalAppStrings.current
    var code by remember { mutableStateOf("") }
    var filterMagasin by remember { mutableStateOf("") }
    var filterCodeMvt by remember { mutableStateOf("") }
    var filterDateFrom by remember { mutableStateOf("") }
    var filterDateTo by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }
    fun validate(v: String) = when {
        v.isBlank() -> "Veuillez saisir un code SAP ou un code OCP."
        v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
        v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
        !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
        else -> null
    }

    fun doSearch() {
        keyboard?.hide()
        val e = validate(code)
        if (e != null) dialog = e
        else scope.launch {
            loading = true
            runCatching {
                api.movements(
                    code = code.trim(),
                    magasin = filterMagasin,
                    codeMouvement = filterCodeMvt,
                    dateFrom = filterDateFrom,
                    dateTo = filterDateTo
                )
            }
                .onSuccess { r ->
                    if (r.isEmpty()) dialog = "Aucun mouvement trouvé pour cet article."
                    else onResult(r)
                }
                .onFailure { dialog = friendlyError(it.message, strings) }
            loading = false
        }
    }

    val baseScheme = MaterialTheme.colorScheme
    MaterialTheme(colorScheme = baseScheme.copy(primary = Blue, primaryContainer = Blue)) {
    CompositionLocalProvider(
        LocalTextSelectionColors provides TextSelectionColors(
            handleColor = Blue,
            backgroundColor = Blue.copy(alpha = 0.35f)
        )
    ) {
    Surface(Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvements matières",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Blue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🔄", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Mouvements matières",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Blue
                    )
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Saisir Code SAP ou Code OCP",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = filterMagasin,
                    onValueChange = { filterMagasin = it.uppercase().take(10) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Magasin (ex. MC01)",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = filterCodeMvt,
                    onValueChange = { filterCodeMvt = it.filter { ch -> ch.isDigit() }.take(4) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Code mouvement (ex. 261)",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Blue,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = filterDateFrom,
                        onValueChange = { filterDateFrom = it.take(10) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        placeholder = {
                            Text(
                                "Du (JJ.MM.AAAA)",
                                color = LocalMobiColors.current.textMuted,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalMobiColors.current.textPrimary,
                            textAlign = TextAlign.Center
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue,
                            unfocusedBorderColor = LocalMobiColors.current.border,
                            focusedContainerColor = LocalMobiColors.current.cardSurface,
                            unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                            cursorColor = Blue,
                            focusedTextColor = LocalMobiColors.current.textPrimary,
                            unfocusedTextColor = LocalMobiColors.current.textPrimary
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = filterDateTo,
                        onValueChange = { filterDateTo = it.take(10) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        placeholder = {
                            Text(
                                "Au (JJ.MM.AAAA)",
                                color = LocalMobiColors.current.textMuted,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalMobiColors.current.textPrimary,
                            textAlign = TextAlign.Center
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue,
                            unfocusedBorderColor = LocalMobiColors.current.border,
                            focusedContainerColor = LocalMobiColors.current.cardSurface,
                            unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                            cursorColor = Blue,
                            focusedTextColor = LocalMobiColors.current.textPrimary,
                            unfocusedTextColor = LocalMobiColors.current.textPrimary
                        )
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    strings.searchBySapOcp,
                    fontSize = 13.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    }
    }

    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg, accent = Blue) { dialog = null } }
}

@Composable
private fun OrgSearchPage(
    api: SupabaseClient,
    onBack: () -> Unit,
    onResult: (List<OrgRow>) -> Unit
) {
    val s = LocalAppStrings.current
    var code by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var descriptif by remember { mutableStateOf("") }
    var famille by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    fun codeFilter(s: String) = s.filter { it.isDigit() || it == '.' }.let {
        if (it.count { c -> c == '.' } <= 1) it.take(11) else it.dropLast(1).take(11)
    }

    fun doSearch() {
        keyboard?.hide()
        val c = code.trim()
        val d = designation.trim()
        val desc = descriptif.trim()
        val f = famille.trim()
        if (c.isBlank() && d.isBlank() && desc.isBlank() && f.isBlank()) {
            dialog = "Veuillez saisir au moins un critère de recherche."
            return
        }
        scope.launch {
            loading = true
            runCatching {
                api.organizationsSearch(
                    code = c,
                    designation = d,
                    descriptif = desc,
                    famille = f
                )
            }.onSuccess { r ->
                if (r.isEmpty()) {
                    dialog = s.noOrg
                } else {
                    onResult(r)
                }
            }.onFailure { dialog = friendlyError(it.message, s) }
            loading = false
        }
    }

    val baseScheme = MaterialTheme.colorScheme
    MaterialTheme(colorScheme = baseScheme.copy(primary = Purple, primaryContainer = Purple)) {
    CompositionLocalProvider(
        LocalTextSelectionColors provides TextSelectionColors(
            handleColor = Purple,
            backgroundColor = Purple.copy(alpha = 0.35f)
        )
    ) {
    Surface(Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Purple)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Article d'organisation",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Purple),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🏢", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Article d'organisation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple
                    )
                }
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = codeFilter(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. 10067.05422",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )

                Spacer(Modifier.height(14.dp))

                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. MANCHON COMPENSATEUR",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )

                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = descriptif,
                    onValueChange = { descriptif = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. descriptif technique",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = famille,
                    onValueChange = { raw ->
                        famille = raw.filter { it.isDigit() }.take(5)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            "Ex. 12345",
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = LocalMobiColors.current.cardSurface,
                        unfocusedContainerColor = LocalMobiColors.current.cardSurface,
                        cursorColor = Purple,
                        focusedTextColor = LocalMobiColors.current.textPrimary,
                        unfocusedTextColor = LocalMobiColors.current.textPrimary
                    )
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("RECHERCHER", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Combinez un ou plusieurs critères (code, désignation, descriptif, famille).",
                    fontSize = 13.sp,
                    color = LocalMobiColors.current.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )
            }
        }
    }
    }
    }
    LoadingOverlay(loading)
    dialog?.let { msg -> AppDialog(msg, accent = Purple) { dialog = null } }
}

@Composable
private fun LoadingOverlay(loading: Boolean) {
    if (!loading) return
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Green, strokeWidth = 3.dp)
                Spacer(Modifier.height(12.dp))
                Text(LocalAppStrings.current.loading, color = LocalMobiColors.current.textPrimary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun AppDialog(msg: String, accent: Color = Green, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        containerColor = LocalMobiColors.current.cardSurface,
        title = {
            Text(
                "MobiStock",
                fontWeight = FontWeight.Bold,
                color = accent,
                fontSize = 18.sp
            )
        },
        text = {
            Text(msg, color = LocalMobiColors.current.textPrimary, fontSize = 14.sp, lineHeight = 20.sp)
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = accent),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("OK", fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

@Composable
private fun StockResultPage(
    rows: List<StockRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val totalQty = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.qty.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val totalValue = rows.fold(BigDecimal.ZERO) { acc, r ->
        acc + (r.valeur.toBigDecimalOrNull() ?: BigDecimal.ZERO)
    }
    val currency = first?.devise?.takeIf { it.isNotBlank() } ?: "MAD"
    val WaGreen = Green

    Surface(modifier = Modifier.fillMaxSize(), color = LocalMobiColors.current.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    LocalAppStrings.current.stockDetail,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        CopyableCodeLine(
                            text = "Code SAP : ${formatSap(first.sap)}",
                            codeValue = formatSap(first.sap),
                            color = LocalMobiColors.current.textPrimary
                        )
                        CopyableCodeLine(
                            text = "Code OCP : ${formatOcp(first.ocp)}",
                            codeValue = formatOcp(first.ocp),
                            color = LocalMobiColors.current.textPrimary
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    StockDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item {
                    Spacer(Modifier.height(6.dp))
                    HorizontalDivider(color = LocalMobiColors.current.border, thickness = 1.dp)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📦", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "TOTAL EN STOCK : ${formatQty(totalQty.toPlainString())}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💰", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "VALEUR GLOBALE : ${formatMoney(totalValue)} $currency",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaGreen,
                            lineHeight = 18.sp
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun StockDetailBlock(row: StockRow, showDivider: Boolean) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${dash(row.magasin)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
            if (row.division.isNotBlank()) {
                Spacer(Modifier.width(14.dp))
                Text("🏭", fontSize = 16.sp)
                Spacer(Modifier.width(4.dp))
                Text(
                    "OL : ${row.division}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalMobiColors.current.textPrimary
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📍", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "BIN : ${dash(row.emplacement)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
        }
        Spacer(Modifier.height(2.dp))
        val devise = row.devise.ifBlank { "MAD" }
        val qtyText = "Quantité : ${formatQty(row.qty)} ${row.unite}"
        val puText = "Prix unitaire : ${formatMoney(row.pu, devise)}"
        val valText = "Valeur : ${formatMoney(row.valeur, devise)}"
        val emText = "Date EM : ${formatDate(row.dateEm)}"
        val outText = "Dernière sortie : ${formatDate(row.derniereSortie)}"
        Text(qtyText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(puText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(valText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(emText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        Text(outText, fontSize = 14.sp, color = LocalMobiColors.current.textPrimary, lineHeight = 18.sp)
        if (showDivider) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = LocalMobiColors.current.border, thickness = 1.dp)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun StockCard(row: StockRow, index: Int) {
    StockDetailBlock(row, showDivider = false)
}

@Composable
private fun StockField(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, color = LocalMobiColors.current.textSecondary, modifier = Modifier.width(110.dp))
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = LocalMobiColors.current.textPrimary,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CodeChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, Green.copy(alpha = 0.25f))
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "$label : ",
                fontSize = 11.sp,
                color = LocalMobiColors.current.textSecondary,
                fontWeight = FontWeight.Medium
            )
            Text(
                value.ifBlank { "—" },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = LocalMobiColors.current.textPrimary
            )
        }
    }
}

@Composable
private fun MovementResultPage(
    rows: List<MovementRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val first = rows.firstOrNull()
    val c = LocalMobiColors.current

    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Blue)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Mouvements matière",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = "Accueil",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                // En-tête unique : désignation + SAP / OCP
                item {
                    if (first != null) {
                        Text(
                            first.designation.ifBlank { "Article" }.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(2.dp))
                        Row(Modifier.fillMaxWidth()) {
                            CopyableCodeLine(
                                text = "Code SAP : ${formatSap(first.sap)}",
                                codeValue = formatSap(first.sap),
                                color = c.textPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            CopyableCodeLine(
                                text = "Code OCP : ${formatOcp(first.ocp)}",
                                codeValue = formatOcp(first.ocp),
                                color = c.textPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = c.border, thickness = 1.dp)
                        Spacer(Modifier.height(12.dp))
                    }
                }

                itemsIndexed(rows) { index, row ->
                    MovementDetailBlock(row, showDivider = index < rows.lastIndex)
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun MovementDetailBlock(row: MovementRow, showDivider: Boolean) {
    val c = LocalMobiColors.current
    val qtyNum = row.quantite.replace(" ", "").replace(",", ".").toBigDecimalOrNull()
    val isPositive = qtyNum != null && qtyNum > java.math.BigDecimal.ZERO
    val accent = if (isPositive) Blue else c.textPrimary
    val qtyLabel = buildString {
        append(formatQty(row.quantite))
        if (row.unite.isNotBlank()) {
            append(' ')
            append(row.unite)
        }
    }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏢", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "MAGASIN : ${dash(row.magasin)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = accent,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Quantité : ${dash(qtyLabel)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = accent
            )
        }
        Spacer(Modifier.height(4.dp))
        val montantText = when {
            row.montant.isBlank() -> "—"
            row.montant.toBigDecimalOrNull() != null -> formatMoney(row.montant.toBigDecimal())
            else -> row.montant
        }
        Text(
            "Montant : $montantText",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Text(
            "Code mouvement : ${dash(row.codeMouvement)}",
            fontSize = 14.sp,
            color = c.textPrimary,
            lineHeight = 18.sp
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                "Ordre : ${dash(row.ordre)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Réservation : ${dash(row.reservation)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            Text(
                "PO : ${dash(row.po)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Réf : ${dash(row.reference)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            Text(
                "Doc article : ${dash(row.docArticle)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Date : ${formatDate(row.date)}",
                fontSize = 14.sp,
                color = c.textPrimary
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏭", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                "OL : ${dash(row.partenaire)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary
            )
        }
        if (showDivider) {
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = c.border, thickness = 1.dp)
            Spacer(Modifier.height(12.dp))
        }
    }
}


@Composable
private fun OrgResultPage(
    rows: List<OrgRow>,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val c = LocalMobiColors.current
    val s = LocalAppStrings.current
    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Purple)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    s.orgArticle,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.Default.Home,
                        contentDescription = s.home,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
            ) {
                itemsIndexed(rows) { index, row ->
                    Column(Modifier.fillMaxWidth()) {
                        // Désignation en haut, couleur barre de recherche, un peu plus grande
                        Text(
                            row.designation.ifBlank { "—" },
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Purple,
                            lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        // Codes SAP / OCP lisibles, gras, noir
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            CopyableCodeLine(
                                text = "Code SAP : ${formatSap(row.sap)}",
                                codeValue = formatSap(row.sap),
                                color = c.textPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(12.dp))
                            CopyableCodeLine(
                                text = "Code OCP : ${formatOcp(row.ocp)}",
                                codeValue = formatOcp(row.ocp),
                                color = c.textPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        // Descriptif inchangé
                        Text(
                            "📌  Descriptif : " + row.descriptif.ifBlank { "—" },
                            fontSize = 14.sp,
                            color = c.textPrimary,
                            lineHeight = 18.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (index < rows.lastIndex) {
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider(color = c.border, thickness = 1.dp)
                            Spacer(Modifier.height(12.dp))
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun SummaryLine(icon: ImageVector, label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 12.sp, color = LocalMobiColors.current.textSecondary, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
    }
}




private fun teamAuthorInitials(name: String): String {
    val clean = name.trim()
    if (clean.isEmpty()) return "?"
    val parts = clean.split(Regex("\\s+|[_\\.-]+")).filter { it.isNotEmpty() }
    return when {
        parts.size >= 2 -> {
            val a = parts[0].firstOrNull { it.isLetterOrDigit() }
            val b = parts[1].firstOrNull { it.isLetterOrDigit() }
            buildString {
                if (a != null) append(a.uppercaseChar())
                if (b != null) append(b.uppercaseChar())
            }.ifEmpty { clean.take(2).uppercase() }
        }
        else -> clean.filter { it.isLetterOrDigit() }.take(2).uppercase().ifEmpty { "?" }
    }
}

@Composable
private fun TeamMessageComposeScreen(
    api: SupabaseClient,
    currentUser: String = "",
    onBack: () -> Unit,
    onSent: () -> Unit
) {
    val c = LocalMobiColors.current
    val context = LocalContext.current
    var objet by remember { mutableStateOf("") }
    var corps by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    val pickPhoto = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        photoUri = uri
        error = null
    }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Nouveau message",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Objet", fontWeight = FontWeight.Bold, color = Green, fontSize = 14.sp)
                OutlinedTextField(
                    value = objet,
                    onValueChange = { objet = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Ex. Inventaire", color = c.textMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface
                    )
                )
                Text("Message", fontWeight = FontWeight.Bold, color = Green, fontSize = 14.sp)
                OutlinedTextField(
                    value = corps,
                    onValueChange = { corps = it; error = null },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 140.dp),
                    minLines = 5,
                    placeholder = { Text("Texte du message d'équipe…", color = c.textMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface
                    )
                )
                Text("Photo (optionnel)", fontWeight = FontWeight.Bold, color = Green, fontSize = 14.sp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            pickPhoto.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = Green)
                        Spacer(Modifier.width(8.dp))
                        Text(if (photoUri == null) "Choisir une photo" else "Changer la photo", color = Green)
                    }
                    if (photoUri != null) {
                        TextButton(onClick = { photoUri = null }) {
                            Text("Retirer", color = c.textSecondary)
                        }
                    }
                }
                if (photoUri != null) {
                    AsyncImage(
                        model = photoUri,
                        contentDescription = "Aperçu",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
                if (error != null) {
                    Text(error!!, color = Color(0xFFDC2626), fontSize = 13.sp)
                }
                Button(
                    onClick = {
                        keyboard?.hide()
                        if (objet.trim().isEmpty() || corps.trim().isEmpty()) {
                            error = "Saisissez l'objet et le message."
                            return@Button
                        }
                        scope.launch {
                            loading = true
                            error = null
                            var uploadedUrl: String? = null
                            val uri = photoUri
                            if (uri != null) {
                                val bytes = withContext(Dispatchers.IO) {
                                    context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                                }
                                if (bytes == null || bytes.isEmpty()) {
                                    error = "Impossible de lire la photo."
                                    loading = false
                                    return@launch
                                }
                                val name = "msg_${System.currentTimeMillis()}.jpg"
                                uploadedUrl = api.uploadTeamPhoto(bytes, name)
                                if (uploadedUrl.isNullOrBlank()) {
                                    error = "Échec upload photo. Vérifiez le bucket team-photos (public + policies)."
                                    loading = false
                                    return@launch
                                }
                            }
                            val ok = runCatching {
                                api.createTeamMessage(objet, corps, uploadedUrl, currentUser)
                            }.getOrDefault(false)
                            loading = false
                            if (ok) onSent()
                            else error = "Échec de l'envoi. Vérifiez les droits Supabase (INSERT sur TeamMessages)."
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HeaderGreen)
                ) {
                    if (loading) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Text("Envoyer", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CatalogScreen(
    api: SupabaseClient,
    isAdmin: Boolean,
    onBack: () -> Unit,
    onHome: () -> Unit = {},
    onAdd: () -> Unit = {}
) {
    val c = LocalMobiColors.current
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<CatalogItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<CatalogItem?>(null) }
    var fullScreenUrl by remember { mutableStateOf<String?>(null) }

    fun load(code: String = query) {
        scope.launch {
            error = null
            val q = code.trim()
            // Cache mémoire session : affichage immédiat
            if (q.isEmpty() && CatalogCache.items != null) {
                items = CatalogCache.items!!
                loading = false
            } else {
                loading = items.isEmpty()
            }
            val photos = runCatching { api.catalogPhotos() }.getOrElse { emptyList() }
            // Recherche SAP ↔ OCP : résoudre les codes liés via Mm03/stock
            val related = if (q.isEmpty()) emptySet()
            else withContext(Dispatchers.IO) {
                runCatching { api.resolveRelatedArticleCodes(q) }.getOrElse { setOf(q) }
            }
            val filtered = photos.filter { ph ->
                if (q.isEmpty()) true
                else {
                    val c = ph.code
                    c.contains(q, ignoreCase = true) ||
                        related.any { r ->
                            c.equals(r, ignoreCase = true) ||
                                c.contains(r, ignoreCase = true) ||
                                r.contains(c, ignoreCase = true)
                        }
                }
            }
            if (filtered.isEmpty()) {
                items = emptyList()
                loading = false
                if (q.isNotEmpty()) error = null
                return@launch
            }
            // Grille photos immédiate si pas de cache
            if (items.isEmpty() || q.isNotEmpty()) {
                items = filtered.map { ph ->
                    CatalogItem(
                        id = ph.id,
                        code = ph.code,
                        sap = ph.code,
                        ocp = "",
                        designation = "…",
                        qty = "—",
                        photoUrl = ph.photoUrl
                    )
                }
                loading = false
            }
            // Enrichissement par lots (mise à jour progressive + cache)
            val merged = items.associateBy { it.id }.toMutableMap()
            try {
                for (batch in filtered.chunked(6)) {
                    val done = withContext(Dispatchers.IO) {
                        coroutineScope {
                            batch.map { ph -> async { api.enrichCatalogPhoto(ph) } }.awaitAll()
                        }
                    }
                    for (it in done) merged[it.id] = it
                    var list = merged.values.toList()
                    if (q.isNotEmpty()) {
                        list = list.filter { item ->
                            item.code.contains(q, ignoreCase = true) ||
                                item.sap.contains(q, ignoreCase = true) ||
                                item.ocp.contains(q, ignoreCase = true) ||
                                related.any { r ->
                                    item.code.equals(r, ignoreCase = true) ||
                                        item.sap.equals(r, ignoreCase = true) ||
                                        item.ocp.equals(r, ignoreCase = true)
                                }
                        }
                    }
                    items = list
                }
                if (q.isEmpty()) CatalogCache.items = items
            } catch (_: Exception) {
                if (items.isEmpty()) error = "Impossible de charger le catalogue."
            }
            loading = false
        }
    }

    var searchActive by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { load("") }

    // Fond blanc = même blanc que les photos catalogue (style Marjane)
    Surface(Modifier.fillMaxSize(), color = Color.White) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gauche : retour recherche OU + admin
                Box(Modifier.width(48.dp), contentAlignment = Alignment.CenterStart) {
                    if (searchActive) {
                        IconButton(onClick = {
                            query = ""
                            searchActive = false
                            load("")
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour catalogue", tint = Color.White)
                        }
                    } else if (isAdmin) {
                        IconButton(onClick = onAdd) {
                            Icon(Icons.Default.Add, "Ajouter photo", tint = Color.White)
                        }
                    }
                }
                // Centre : barre recherche blanche (style Marjane)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White)
                        .border(1.dp, Color.White, RoundedCornerShape(50))
                        .padding(start = 12.dp, end = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { raw ->
                            val f = raw.filter { ch -> ch.isDigit() || ch == '.' }
                            query = if (f.count { it == '.' } <= 1) f.take(11) else f
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 13.sp,
                            color = Color(0xFF0F172A),
                            textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(Green),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box(
                                Modifier.fillMaxWidth().height(36.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (query.isEmpty()) {
                                    Text(
                                        "Rechercher un article",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    IconButton(
                        onClick = {
                            searchActive = query.isNotBlank()
                            load(query)
                        },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.Search, "Rechercher", tint = Green, modifier = Modifier.size(18.dp))
                    }
                }
                // Droite : accueil
                Box(Modifier.width(48.dp), contentAlignment = Alignment.CenterEnd) {
                    IconButton(onClick = onHome) {
                        Icon(Icons.Default.Home, "Accueil", tint = Color.White)
                    }
                }
            }
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Green)
                }
                error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(error!!, color = Color(0xFF64748B))
                }
                items.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (query.isBlank()) "Aucune photo catalogue.\nAdmin : + pour ajouter."
                        else "Aucun article pour ce code.",
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }
                else -> {
                val sortedItems = remember(items) {
                    items.sortedByDescending { item ->
                        fun codeKey(s: String): Long {
                            val digits = s.filter { it.isDigit() }
                            return digits.toLongOrNull() ?: 0L
                        }
                        maxOf(codeKey(item.sap), codeKey(item.ocp), codeKey(item.code))
                    }
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    lazyGridItems(sortedItems, key = { it.id }) { card ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (isAdmin) Modifier.combinedClickable(
                                        onClick = {},
                                        onLongClick = { pendingDelete = card }
                                    ) else Modifier
                                ),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                                val model = remember(card.photoUrl) { api.teamPhotoRequest(ctx, card.photoUrl) }
                                SubcomposeAsyncImage(
                                    model = model,
                                    contentDescription = card.designation,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(110.dp)
                                        .clickable { fullScreenUrl = card.photoUrl },
                                    contentScale = ContentScale.Fit,
                                    loading = {
                                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator(Modifier.size(22.dp), color = Green, strokeWidth = 2.dp)
                                        }
                                    },
                                    error = {
                                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            Text("Photo", color = c.textMuted, fontSize = 12.sp)
                                        }
                                    }
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    card.designation,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF0F172A),
                                    fontSize = 11.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 13.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    listOf(card.sap, card.ocp).filter { s -> s.isNotBlank() }.joinToString(" · "),
                                    color = Color(0xFF64748B),
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 11.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    "Qté : ${card.qty}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (card.qty == "0" || card.qty == "0.0") Color(0xFFDC2626) else Green,
                                    fontSize = 11.sp,
                                    lineHeight = 13.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                        }
                    }
                }
                } // else sorted grid
            }
        }
    }
    fullScreenUrl?.let { url ->
        Dialog(
            onDismissRequest = { fullScreenUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { fullScreenUrl = null },
                contentAlignment = Alignment.Center
            ) {
                SubcomposeAsyncImage(
                    model = api.teamPhotoRequest(ctx, url),
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Supprimer la photo ?", fontWeight = FontWeight.Bold) },
            text = { Text("« ${item.designation} » (${item.code}) sera retiré du catalogue.") },
            confirmButton = {
                TextButton(onClick = {
                    val id = item.id
                    pendingDelete = null
                    scope.launch {
                        if (runCatching { api.deleteCatalogPhoto(id) }.getOrDefault(false)) { CatalogCache.items = null; load(query) }
                    }
                }) { Text("Supprimer", color = NetflixRed, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun CatalogAddScreen(
    api: SupabaseClient,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val c = LocalMobiColors.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    var code by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val pickPhoto = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) photoUri = uri }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Ajouter au catalogue",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    "Saisissez le code SAP ou OCP, puis choisissez la photo.",
                    color = c.textSecondary,
                    fontSize = 13.sp
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { raw ->
                        val f = raw.filter { ch -> ch.isDigit() || ch == '.' }
                        code = if (f.count { it == '.' } <= 1) f.take(11) else f
                        error = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Code SAP ou OCP") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(50),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = {
                            pickPhoto.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        }
                    ) {
                        Text(if (photoUri == null) "Choisir une photo" else "Changer la photo", color = Green)
                    }
                    if (photoUri != null) {
                        TextButton(onClick = { photoUri = null }) {
                            Text("Retirer", color = c.textSecondary)
                        }
                    }
                }
                if (photoUri != null) {
                    AsyncImage(
                        model = photoUri,
                        contentDescription = "Aperçu",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
                if (error != null) {
                    Text(error!!, color = Color(0xFFDC2626), fontSize = 13.sp)
                }
                Button(
                    onClick = {
                        keyboard?.hide()
                        val cd = code.trim()
                        if (cd.isEmpty()) {
                            error = "Saisissez un code SAP ou OCP."
                            return@Button
                        }
                        val uri = photoUri
                        if (uri == null) {
                            error = "Choisissez une photo."
                            return@Button
                        }
                        scope.launch {
                            loading = true
                            error = null
                            val bytes = withContext(Dispatchers.IO) {
                                ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            }
                            if (bytes == null || bytes.isEmpty()) {
                                error = "Impossible de lire la photo."
                                loading = false
                                return@launch
                            }
                            val safeCode = cd.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                            val name = "${safeCode}_${System.currentTimeMillis()}.jpg"
                            val url = api.uploadCatalogPhoto(bytes, name)
                            if (url.isNullOrBlank()) {
                                error = "Échec upload. Créez le bucket catalog-photos sur Supabase."
                                loading = false
                                return@launch
                            }
                            val ok = api.createCatalogPhoto(cd, url)
                            loading = false
                            if (ok) { CatalogCache.items = null; onSaved() }
                            else error = "Échec enregistrement. Vérifiez la table CatalogPhotos."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text("Enregistrer", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TeamMessageListScreen(
    messages: List<TeamMessage>,
    readIds: Set<String>,
    unreadCommentCounts: Map<String, Int> = emptyMap(),
    isAdmin: Boolean = false,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onCompose: () -> Unit = {},
    onDelete: (String) -> Unit = {},
    onRefresh: () -> Unit = {}
) {
    val c = LocalMobiColors.current
    var pendingDelete by remember { mutableStateOf<TeamMessage?>(null) }
    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Messages d'équipe",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                if (isAdmin) {
                    IconButton(onClick = onCompose) {
                        Icon(Icons.Default.Add, "Nouveau message", tint = Color.White)
                    }
                }
            }
            if (messages.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Aucun message", color = c.textSecondary, fontSize = 15.sp)
                }
            } else {
                val sorted = messages.sortedByDescending { it.date.ifBlank { "" } }
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(sorted.size) { i ->
                        val m = sorted[i]
                        val unread = m.id !in readIds
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { onOpen(m.id) },
                                    onLongClick = {
                                        if (isAdmin) pendingDelete = m
                                    }
                                ),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(c.cardSurface),
                            border = BorderStroke(1.dp, c.border)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Notifications,
                                        contentDescription = null,
                                        tint = if (unread) Green else c.textMuted,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            m.objet,
                                            fontWeight = if (unread) FontWeight.Bold else FontWeight.SemiBold,
                                            color = c.textPrimary,
                                            fontSize = 15.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        if (m.date.isNotBlank() || m.photoUrl.isNotBlank()) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                if (m.date.isNotBlank()) {
                                                    Text(
                                                        formatDate(m.date),
                                                        fontSize = 12.sp,
                                                        color = c.textMuted
                                                    )
                                                }
                                                if (m.photoUrl.isNotBlank()) {
                                                    Text(
                                                        "PHOTO",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = c.textPrimary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    run {
                                        val uc = unreadCommentCounts[m.id] ?: 0
                                        val showAvatar = m.auteur.isNotBlank() || uc > 0
                                        if (showAvatar) {
                                            Spacer(Modifier.width(8.dp))
                                            Box {
                                                Box(
                                                    Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            when {
                                                                m.auteur.isBlank() -> c.textMuted
                                                                unread -> Green
                                                                else -> c.textMuted
                                                            }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        if (m.auteur.isNotBlank()) teamAuthorInitials(m.auteur) else "?",
                                                        color = Color.White,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                if (uc > 0) {
                                                    Box(
                                                        Modifier
                                                            .align(Alignment.TopEnd)
                                                            .offset(x = 4.dp, y = (-4).dp)
                                                            .defaultMinSize(minWidth = 16.dp, minHeight = 16.dp)
                                                            .clip(CircleShape)
                                                            .background(NetflixRed)
                                                            .padding(horizontal = 3.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            if (uc > 9) "9+" else "$uc",
                                                            color = Color.White,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            lineHeight = 10.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (unread) {
                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .height(5.dp)
                                            .background(Green)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            pendingDelete?.let { msg ->
                AlertDialog(
                    onDismissRequest = { pendingDelete = null },
                    title = { Text("Supprimer le message ?", fontWeight = FontWeight.Bold) },
                    text = {
                        Text("« ${msg.objet} » sera définitivement supprimé pour tous les utilisateurs.")
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                val id = msg.id
                                pendingDelete = null
                                onDelete(id)
                            }
                        ) {
                            Text("Supprimer", color = NetflixRed, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { pendingDelete = null }) {
                            Text("Annuler")
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TeamMessageDetailScreen(
    api: SupabaseClient,
    message: TeamMessage?,
    isAdmin: Boolean = false,
    currentUser: String = "",
    currentUserIsAdmin: Boolean = false,
    onBack: () -> Unit,
    onHome: () -> Unit = {},
    onCommentsChanged: suspend () -> Unit = {}
) {
    val c = LocalMobiColors.current
    val valueColor = c.textPrimary
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    var comments by remember { mutableStateOf<List<TeamMessageComment>>(emptyList()) }
    var loadingComments by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<TeamMessageComment?>(null) }

    fun reloadComments() {
        val id = message?.id ?: return
        scope.launch {
            loadingComments = true
            comments = runCatching { api.teamMessageComments(id) }.getOrDefault(emptyList())
            loadingComments = false
        }
    }

    LaunchedEffect(message?.id) {
        reloadComments()
    }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Message d'équipe",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                IconButton(onClick = onHome) {
                    Icon(Icons.Default.Home, "Accueil", tint = Color.White)
                }
            }
            if (message == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Message introuvable", color = c.textSecondary)
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(
                        Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Text("Objet : ", fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
                            Text(message.objet, fontWeight = FontWeight.Bold, color = valueColor, fontSize = 16.sp)
                        }
                        Row(verticalAlignment = Alignment.Top) {
                            Text("Du : ", fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
                            Text(
                                buildString {
                                    if (message.auteur.isNotBlank()) append(message.auteur)
                                    if (message.date.isNotBlank()) {
                                        if (isNotEmpty()) append(" · ")
                                        append(formatDate(message.date))
                                    }
                                    if (isEmpty()) append("—")
                                },
                                fontWeight = FontWeight.Bold,
                                color = valueColor,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = c.border, thickness = 1.dp)
                        Spacer(Modifier.height(12.dp))
                        Text("Message :", fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            message.corps.ifBlank { "—" },
                            color = valueColor,
                            fontSize = 16.sp,
                            lineHeight = 24.sp
                        )
                        if (message.photoUrl.isNotBlank()) {
                            Spacer(Modifier.height(16.dp))
                            Text("Photo", fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
                            Spacer(Modifier.height(8.dp))
                            val ctx = LocalContext.current
                            var fullScreen by remember { mutableStateOf(false) }
                            val imageModel = remember(message.photoUrl) {
                                api.teamPhotoRequest(ctx, message.photoUrl)
                            }
                            SubcomposeAsyncImage(
                                model = imageModel,
                                contentDescription = "Photo du message",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 120.dp, max = 360.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(c.cardSurface)
                                    .clickable { fullScreen = true },
                                contentScale = ContentScale.Fit,
                                loading = {
                                    Box(
                                        Modifier.fillMaxWidth().height(160.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(color = Green, strokeWidth = 2.dp)
                                    }
                                },
                                error = {
                                    Box(
                                        Modifier.fillMaxWidth().height(100.dp).padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "Image inaccessible (droits Storage ou URL).",
                                            color = c.textSecondary,
                                            fontSize = 13.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            )
                            if (fullScreen) {
                                Dialog(
                                    onDismissRequest = { fullScreen = false },
                                    properties = DialogProperties(usePlatformDefaultWidth = false)
                                ) {
                                    Box(
                                        Modifier
                                            .fillMaxSize()
                                            .background(Color.Black)
                                            .clickable { fullScreen = false },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        SubcomposeAsyncImage(
                                            model = imageModel,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxWidth(),
                                            contentScale = ContentScale.Fit
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(20.dp))
                        HorizontalDivider(color = c.border, thickness = 1.dp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Commentaires (${comments.size})",
                            fontWeight = FontWeight.Bold,
                            color = Green,
                            fontSize = 16.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        if (loadingComments) {
                            Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Green, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                            }
                        } else if (comments.isEmpty()) {
                            Text(
                                "Aucun commentaire. Soyez le premier.",
                                color = c.textSecondary,
                                fontSize = 13.sp
                            )
                        } else {
                            comments.forEach { cm ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                        .then(
                                            if (isAdmin) {
                                                Modifier.combinedClickable(
                                                    onClick = {},
                                                    onLongClick = { pendingDelete = cm }
                                                )
                                            } else Modifier
                                        ),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    val isAdminAuthor = cm.role.equals("admin", ignoreCase = true)
                                    Box(
                                        Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(if (isAdminAuthor) Green else Color(0xFF2563EB)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            teamAuthorInitials(cm.auteur.ifBlank { "?" }),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                cm.auteur.ifBlank { "Utilisateur" },
                                                fontWeight = FontWeight.Bold,
                                                color = c.textPrimary,
                                                fontSize = 13.sp
                                            )
                                            if (cm.date.isNotBlank()) {
                                                Text(
                                                    formatDate(cm.date),
                                                    color = c.textMuted,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        Spacer(Modifier.height(2.dp))
                                        Text(cm.texte, color = valueColor, fontSize = 14.sp, lineHeight = 20.sp)
                                    }
                                }
                                HorizontalDivider(color = c.border.copy(alpha = 0.5f), thickness = 0.5.dp)
                            }
                        }
                        if (error != null) {
                            Spacer(Modifier.height(8.dp))
                            Text(error!!, color = Color(0xFFDC2626), fontSize = 13.sp)
                        }
                    }

                    // Zone saisie
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(c.cardSurface)
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it; error = null },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Écrire un commentaire…", color = c.textMuted) },
                            singleLine = true,
                            shape = RoundedCornerShape(50),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Green,
                                unfocusedBorderColor = c.border,
                                cursorColor = Green,
                                focusedTextColor = c.textPrimary,
                                unfocusedTextColor = c.textPrimary,
                                focusedContainerColor = c.surfaceBg,
                                unfocusedContainerColor = c.surfaceBg
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                keyboard?.hide()
                                val t = draft.trim()
                                if (t.isEmpty()) {
                                    error = "Saisissez un commentaire."
                                    return@IconButton
                                }
                                val mid = message.id
                                scope.launch {
                                    sending = true
                                    error = null
                                    val ok = runCatching {
                                        api.createTeamMessageComment(
                                            mid,
                                            t,
                                            currentUser,
                                            if (currentUserIsAdmin) "admin" else "user"
                                        )
                                    }.getOrDefault(false)
                                    sending = false
                                    if (ok) {
                                        draft = ""
                                        reloadComments()
                                        runCatching { onCommentsChanged() }
                                    } else {
                                        error = "Échec envoi. Vérifiez la table TeamMessageComments (Supabase)."
                                    }
                                }
                            },
                            enabled = !sending
                        ) {
                            if (sending) {
                                CircularProgressIndicator(Modifier.size(22.dp), color = Green, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Send, "Envoyer", tint = Green)
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDelete?.let { cm ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Supprimer le commentaire ?", fontWeight = FontWeight.Bold) },
            text = { Text("« ${cm.texte.take(80)} » sera supprimé pour tout le monde.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val id = cm.id
                        pendingDelete = null
                        scope.launch {
                            val ok = runCatching { api.deleteTeamMessageComment(id) }.getOrDefault(false)
                            if (ok) reloadComments()
                            else error = "Suppression impossible."
                        }
                    }
                ) {
                    Text("Supprimer", color = NetflixRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun Header(
    badgeCount: Int = 0,
    onBellClick: (() -> Unit)? = null
) {
    Box(
        Modifier
            .fillMaxWidth()
            .background(HeaderGreen)
            .padding(horizontal = 8.dp, vertical = 10.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "JORF FERTILIZERS COMPANY I",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.5.sp,
                maxLines = 1
            )
            Text(
                "MobiStock",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
        if (onBellClick != null) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 4.dp)
            ) {
                IconButton(onClick = onBellClick) {
                    Icon(
                        Icons.Default.Notifications,
                        contentDescription = "Messages d'équipe",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                if (badgeCount > 0) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = (-4).dp, y = 4.dp)
                            .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                            .height(18.dp)
                            .widthIn(min = 18.dp)
                            .clip(CircleShape)
                            .background(NetflixRed)
                            .padding(horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (badgeCount > 9) "9+" else "$badgeCount",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 10.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD))
                )
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Bonjour,",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GreenDark
                )
                Text(
                    "Bienvenue sur MobiStock",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalMobiColors.current.textPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Consultez et gérez vos stocks et mouvements en temps réel.",
                    fontSize = 11.sp,
                    color = LocalMobiColors.current.textSecondary,
                    lineHeight = 15.sp
                )
            }
            Icon(
                Icons.Default.Business,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color(0x6675A98A)
            )
        }
    }
}


private fun cardTypeForTitle(title: String): String? = when {
    title.contains("articles", ignoreCase = true) -> "stock"
    title.contains("Valeur de stock", ignoreCase = true) -> "stock"
    title.contains("Cons 2025", ignoreCase = true) -> "cons2025"
    title.contains("Cons 2026", ignoreCase = true) -> "cons2026"
    title.contains("Réception 2025", ignoreCase = true) -> "recept2025"
    title.contains("Réception 2026", ignoreCase = true) -> "recept2026"
    title.contains("Surstock", ignoreCase = true) -> "surstock"
    title.contains("Transfert", ignoreCase = true) -> "transfert2026"
    else -> null
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(LocalMobiColors.current.cardSurface),
        border = BorderStroke(1.dp, LocalMobiColors.current.border),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LocalMobiColors.current.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        value,
                        fontSize = if (value.length > 14) 11.sp else if (value.length > 10) 12.sp else 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalMobiColors.current.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 14.sp
                    )
                    Text(
                        subtitle,
                        fontSize = 10.sp,
                        color = LocalMobiColors.current.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            // bande colorée en bas
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(accent)
            )
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    subtitle: String,
    accent: Color,
    background: Color,
    icon: ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    organisation: Boolean,
    onSearch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(background),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                    Text(
                        subtitle,
                        fontSize = 11.sp,
                        color = LocalMobiColors.current.textSecondary
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    placeholder = {
                        Text(
                            placeholder,
                            color = LocalMobiColors.current.textMuted,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = LocalMobiColors.current.textPrimary
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = LocalMobiColors.current.border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        cursorColor = accent
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Rechercher",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(
    api: SupabaseClient,
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    lang: String,
    onLangChange: (String) -> Unit,
    onLogout: () -> Unit = {}
) {
    val c = LocalMobiColors.current
    val s = LocalAppStrings.current
    var showChangePassword by remember { mutableStateOf(false) }

    if (showChangePassword) {
        ChangePasswordScreen(
            api = api,
            onBack = { showChangePassword = false }
        )
        return
    }

    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .padding(top = 24.dp, bottom = 80.dp)
        ) {
            Text(
                s.settings,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = c.textPrimary
            )
            Spacer(Modifier.height(24.dp))
            Text(
                s.appearance,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.textSecondary
            )
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(c.cardSurface),
                border = BorderStroke(1.dp, c.border)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.darkMode,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = c.textPrimary
                            )
                            Text(
                                s.darkModeDesc,
                                fontSize = 12.sp,
                                color = c.textSecondary
                            )
                        }
                        Switch(
                            checked = isDark,
                            onCheckedChange = { onThemeChange(true) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                    HorizontalDivider(color = c.border, thickness = 1.dp, modifier = Modifier.padding(vertical = 6.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.lightMode,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = c.textPrimary
                            )
                            Text(
                                s.lightModeDesc,
                                fontSize = 12.sp,
                                color = c.textSecondary
                            )
                        }
                        Switch(
                            checked = !isDark,
                            onCheckedChange = { onThemeChange(false) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                s.language,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.textSecondary
            )
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(c.cardSurface),
                border = BorderStroke(1.dp, c.border)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            s.french,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = c.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = lang == "fr",
                            onCheckedChange = { if (it) onLangChange("fr") },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                    HorizontalDivider(color = c.border, thickness = 1.dp, modifier = Modifier.padding(vertical = 6.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            s.english,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = c.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = lang == "en",
                            onCheckedChange = { if (it) onLangChange("en") },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Green,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = c.border
                            )
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { showChangePassword = true },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HeaderGreen)
            ) {
                Text("Changer le mot de passe", fontWeight = FontWeight.SemiBold, color = Color.White)
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HeaderGreen)
            ) {
                Text(s.logout, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "MobiStock 1.0 développé par LEMMAA",
                color = c.textSecondary,
                fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun ChangePasswordScreen(
    api: SupabaseClient,
    onBack: () -> Unit
) {
    val c = LocalMobiColors.current
    val s = LocalAppStrings.current
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE) }
    val currentUser = prefs.getString(PrefLoginUser, "") ?: ""
    var oldPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var showOld by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    Surface(modifier = Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    "Changer le mot de passe",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (currentUser.isNotBlank()) {
                    Text(
                        "Compte : $currentUser",
                        fontSize = 14.sp,
                        color = c.textSecondary
                    )
                }
                OutlinedTextField(
                    value = oldPass,
                    onValueChange = { oldPass = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    placeholder = {
                        Text(
                            "Ancien mot de passe",
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    visualTransformation = if (showOld) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showOld = !showOld }) {
                            Icon(
                                if (showOld) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = c.textSecondary
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface
                    )
                )
                OutlinedTextField(
                    value = newPass,
                    onValueChange = { newPass = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    placeholder = {
                        Text(
                            "Nouveau mot de passe",
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    visualTransformation = if (showNew) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showNew = !showNew }) {
                            Icon(
                                if (showNew) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = c.textSecondary
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface
                    )
                )
                OutlinedTextField(
                    value = confirmPass,
                    onValueChange = { confirmPass = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 16.sp,
                        color = LocalMobiColors.current.textPrimary,
                        textAlign = TextAlign.Center
                    ),
                    placeholder = {
                        Text(
                            "Confirmer le nouveau",
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    visualTransformation = if (showConfirm) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showConfirm = !showConfirm }) {
                            Icon(
                                if (showConfirm) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = c.textSecondary
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface
                    )
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        keyboard?.hide()
                        when {
                            currentUser.isBlank() -> msg = "Session invalide. Reconnectez-vous."
                            oldPass.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty() ->
                                msg = "Veuillez remplir tous les champs."
                            newPass != confirmPass ->
                                msg = "La confirmation ne correspond pas."
                            newPass.length < 4 ->
                                msg = "Le nouveau mot de passe est trop court."
                            else -> scope.launch {
                                loading = true
                                runCatching {
                                    api.changePassword(currentUser, oldPass, newPass)
                                }.onSuccess { ok ->
                                    if (ok) {
                                        msg = "Mot de passe modifié avec succès."
                                        oldPass = ""
                                        newPass = ""
                                        confirmPass = ""
                                    } else {
                                        msg = "Échec de la mise à jour. Vérifiez l'ancien mot de passe."
                                    }
                                }.onFailure {
                                    msg = friendlyError(it.message, s)
                                }
                                loading = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !loading,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text("Enregistrer", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
    msg?.let { m ->
        AppDialog(m) {
            msg = null
            if (m.contains("succès")) onBack()
        }
    }
}


@Composable
private fun FullDashboardScreen(
    articleCount: String,
    stockValue: String,
    conso2025: String,
    conso2026: String,
    consoDate2025: String,
    consoDate2026: String,
    recept2025: String,
    recept2026: String,
    receptDate2025: String,
    receptDate2026: String,
    surstock: String,
    transfert2026: String,
    onBack: () -> Unit,
    onOpenCard: (String) -> Unit
) {
    val c = LocalMobiColors.current
    val cards = listOf(
        Triple("Nombre d'articles", articleCount to "Articles en stock", Green to Icons.Default.Inventory2),
        Triple("Valeur de stock", stockValue to "MAD", Blue to Icons.Default.AccountBalance),
        Triple("Cons 2025", conso2025 to "MAJ : $consoDate2025", Blue to Icons.Default.TrendingDown),
        Triple("Cons 2026", conso2026 to "MAJ : $consoDate2026", Blue to Icons.Default.TrendingUp),
        Triple("Réception 2025", recept2025 to "MAJ : $receptDate2025", Purple to Icons.Default.MoveToInbox),
        Triple("Réception 2026", recept2026 to "MAJ : $receptDate2026", Purple to Icons.Default.MoveToInbox),
        Triple("Surstock", surstock to "MAGASIN MIN1", Color(0xFFE67E22) to Icons.Default.Store),
        Triple("Transfert 2026", transfert2026 to "Code mvt 643", Color(0xFF16A085) to Icons.Default.SwapHoriz)
    )
    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Tableau de bord",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            val pairs = cards.chunked(2)
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(pairs.size) { idx ->
                    val pair = pairs[idx]
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { card ->
                            SummaryCard(
                                title = card.first,
                                value = card.second.first,
                                subtitle = card.second.second,
                                accent = card.third.first,
                                icon = card.third.second,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val t = cardTypeForTitle(card.first)
                                    if (t != null) onOpenCard(t)
                                }
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun CardTop15Screen(
    api: SupabaseClient,
    cardType: String,
    onBack: () -> Unit,
    onHome: () -> Unit = {}
) {
    val c = LocalMobiColors.current
    val (title, accent) = when (cardType) {
        "stock" -> "Valeur de stock" to Blue
        "cons2025" -> "Cons 2025" to Blue
        "cons2026" -> "Cons 2026" to Blue
        "recept2025" -> "Réception 2025" to Purple
        "recept2026" -> "Réception 2026" to Purple
        "surstock" -> "Surstock MIN1" to Color(0xFFE67E22)
        "transfert2026" -> "Transfert 2026" to Color(0xFF16A085)
        else -> "Détail" to Green
    }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var rows by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var totalBd by remember { mutableStateOf(java.math.BigDecimal.ZERO) }
    var topSumBd by remember { mutableStateOf(java.math.BigDecimal.ZERO) }

    LaunchedEffect(cardType) {
        val cacheKey = when (cardType) {
            "cons2025", "cons2026" -> "${cardType}_neg"
            else -> cardType
        }
        val cached = Top15Cache.get(cacheKey)
        if (cached != null) {
            rows = cached.rows
            totalBd = cached.total
            topSumBd = cached.topSum
            loading = false
            return@LaunchedEffect
        }
        loading = true
        error = null
        runCatching {
            when (cardType) {
                "stock", "surstock" -> {
                    val mag = if (cardType == "surstock") "MIN1" else null
                    val all = api.topStockArticles(limit = 100000, magasinEq = mag)
                    totalBd = all.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                    rows = all.take(15)
                    topSumBd = rows.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                }
                "cons2025" -> {
                    rows = api.topMovementArticles(setOf("261", "262", "201", "202"), 2025, limit = 15, onlyNegative = true)
                    totalBd = Top15LastTotal.get()
                    topSumBd = rows.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                }
                "cons2026" -> {
                    rows = api.topMovementArticles(setOf("261", "262", "201", "202"), 2026, limit = 15, onlyNegative = true)
                    totalBd = Top15LastTotal.get()
                    topSumBd = rows.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                }
                "recept2025" -> {
                    rows = api.topMovementArticles(setOf("101", "102"), 2025, limit = 15)
                    totalBd = Top15LastTotal.get()
                    topSumBd = rows.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                }
                "recept2026" -> {
                    rows = api.topMovementArticles(setOf("101", "102"), 2026, limit = 15)
                    totalBd = Top15LastTotal.get()
                    topSumBd = rows.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                }
                "transfert2026" -> {
                    rows = api.topMovementArticles(setOf("643"), 2026, limit = 15)
                    totalBd = Top15LastTotal.get()
                    topSumBd = rows.fold(java.math.BigDecimal.ZERO) { a, r -> a + r.valueBd }
                }
                else -> {
                    rows = emptyList()
                    totalBd = java.math.BigDecimal.ZERO
                    topSumBd = java.math.BigDecimal.ZERO
                }
            }
            if (rows.isNotEmpty()) {
                Top15Cache.put(
                    cacheKey,
                    Top15Cache.Entry(rows = rows, total = totalBd, topSum = topSumBd)
                )
            }
        }.onFailure {
            error = it.message ?: "Erreur"
        }
        loading = false
    }

    val pct = if (totalBd > java.math.BigDecimal.ZERO) {
        topSumBd.multiply(java.math.BigDecimal(100))
            .divide(totalBd, 1, java.math.RoundingMode.HALF_UP)
            .toPlainString()
    } else "0"

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onHome) {
                    Icon(Icons.Default.Home, "Accueil", tint = Color.White)
                }
            }
            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = accent)
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
                ) {
                    item {
                        Text(
                            "Top 15 articles",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = c.textPrimary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Les 15 premiers articles représentent $pct % de la valeur totale.",
                            fontSize = 14.sp,
                            color = accent,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 20.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Cumul top 15 : ${formatMoney(topSumBd)} MAD  ·  Ensemble : ${formatMoney(totalBd)} MAD",
                            fontSize = 12.sp,
                            color = c.textSecondary
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                    if (rows.isEmpty()) {
                        item {
                            Text("Aucune donnée", color = c.textSecondary)
                        }
                    } else {
                        items(rows.size) { index ->
                            val row = rows[index]
                            val sapDisp = formatSap(row.sap)
                            val ocpDisp = formatOcp(row.ocp)
                            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                                    Text(
                                        "${index + 1}.",
                                        fontWeight = FontWeight.Bold,
                                        color = accent,
                                        modifier = Modifier.width(28.dp),
                                        fontSize = 14.sp
                                    )
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            row.designation.ifBlank { "—" },
                                            fontWeight = FontWeight.SemiBold,
                                            color = c.textPrimary,
                                            fontSize = 14.sp
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            CopyableCodeLine(
                                                text = "SAP $sapDisp",
                                                codeValue = sapDisp,
                                                color = c.textSecondary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Text("   ", fontSize = 11.sp, color = c.textSecondary)
                                            CopyableCodeLine(
                                                text = "OCP $ocpDisp",
                                                codeValue = ocpDisp,
                                                color = c.textSecondary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        if (row.detail.isNotBlank()) {
                                            Text(row.detail, fontSize = 11.sp, color = c.textMuted)
                                        }
                                    }
                                    Text(
                                        row.value,
                                        fontWeight = FontWeight.Bold,
                                        color = accent,
                                        fontSize = 13.sp
                                    )
                                }
                                if (index < rows.lastIndex) {
                                    Spacer(Modifier.height(8.dp))
                                    HorizontalDivider(color = c.border, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    error?.let { msg -> AppDialog(msg) { error = null } }
}

@Composable
private fun Top15Screen(
    api: SupabaseClient,
    onBack: () -> Unit
) {
    val c = LocalMobiColors.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var stockTop by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var cons25 by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var cons26 by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var rec25 by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var rec26 by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var surTop by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }
    var trf26 by remember { mutableStateOf<List<TopArticleRow>>(emptyList()) }

    LaunchedEffect(Unit) {
        loading = true
        error = null
        runCatching {
            stockTop = api.topStockArticles(15)
            cons25 = api.topMovementArticles(setOf("261", "262", "201", "202"), 2025, 15)
            cons26 = api.topMovementArticles(setOf("261", "262", "201", "202"), 2026, 15)
            rec25 = api.topMovementArticles(setOf("101", "102"), 2025, 15)
            rec26 = api.topMovementArticles(setOf("101", "102"), 2026, 15)
            surTop = api.topStockArticles(15, magasinEq = "MIN1")
            trf26 = api.topMovementArticles(setOf("643"), 2026, 15)
        }.onFailure {
            error = it.message ?: "Erreur"
        }
        loading = false
    }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Top 15 articles",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Green)
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
                ) {
                    item {
                        Top15Section("Valeur de stock", stockTop, Blue)
                    }
                    item {
                        Top15Section("Cons 2025", cons25, Blue)
                    }
                    item {
                        Top15Section("Cons 2026", cons26, Blue)
                    }
                    item {
                        Top15Section("Réception 2025", rec25, Purple)
                    }
                    item {
                        Top15Section("Réception 2026", rec26, Purple)
                    }
                    item {
                        Top15Section("Surstock MIN1", surTop, Color(0xFFE67E22))
                    }
                    item {
                        Top15Section("Transfert 2026", trf26, Color(0xFF16A085))
                    }
                }
            }
        }
    }
    error?.let { msg ->
        AppDialog(msg) { error = null }
    }
}

@Composable
private fun Top15Section(
    title: String,
    rows: List<TopArticleRow>,
    accent: Color
) {
    val c = LocalMobiColors.current
    Spacer(Modifier.height(8.dp))
    Text(
        title,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = accent
    )
    Spacer(Modifier.height(8.dp))
    if (rows.isEmpty()) {
        Text(
            "Aucune donnée",
            fontSize = 13.sp,
            color = c.textSecondary,
            modifier = Modifier.padding(bottom = 12.dp)
        )
    } else {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(c.cardSurface),
            border = BorderStroke(1.dp, c.border)
        ) {
            Column(Modifier.padding(12.dp)) {
                rows.forEachIndexed { index, row ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            "${index + 1}.",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = accent,
                            modifier = Modifier.width(28.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                row.designation.ifBlank { "—" },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.textPrimary,
                                maxLines = 2
                            )
                            Text(
                                "SAP ${row.sap}  ·  OCP ${row.ocp}",
                                fontSize = 11.sp,
                                color = c.textSecondary
                            )
                            if (row.detail.isNotBlank()) {
                                Text(
                                    row.detail,
                                    fontSize = 11.sp,
                                    color = c.textMuted
                                )
                            }
                        }
                        Text(
                            row.value,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = accent
                        )
                    }
                    if (index < rows.lastIndex) {
                        HorizontalDivider(color = c.border, thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}



/** Dessine le tableau stock multiple en image (export). */
private fun multiStockTableToBitmap(rows: List<MultiStockRow>): Bitmap {
    val headers = listOf("Codes", "Désignation", "Qté", "Bin", "Cons 2025", "Cons 2026")
    val colW = intArrayOf(300, 420, 140, 380, 200, 200)
    val pad = 24
    val headerH = 64
    val rowH = 120
    val width = colW.sum() + pad * 2
    val height = headerH + rows.size * rowH + pad * 2
    val bmp = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.drawColor(android.graphics.Color.WHITE)
    val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#15803D")
        textSize = 32f
        isFakeBoldText = true
    }
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#0F172A")
        textSize = 28f
    }
    val linePaint = Paint().apply {
        color = android.graphics.Color.parseColor("#E2E8F0")
        strokeWidth = 2f
    }
    val headerBg = Paint().apply { color = android.graphics.Color.parseColor("#DCFCE7") }
    canvas.drawRect(0f, 0f, width.toFloat(), (pad + headerH).toFloat(), headerBg)
    var x = pad.toFloat()
    val baseY = pad + headerH - 20f
    headers.forEachIndexed { i, h ->
        canvas.drawText(h, x + 8f, baseY, headerPaint)
        x += colW[i]
    }
    canvas.drawLine(0f, (pad + headerH).toFloat(), width.toFloat(), (pad + headerH).toFloat(), linePaint)
    rows.forEachIndexed { idx, r ->
        val top = pad + headerH + idx * rowH
        if (idx % 2 == 1) {
            val alt = Paint().apply { color = android.graphics.Color.parseColor("#F8FAFC") }
            canvas.drawRect(0f, top.toFloat(), width.toFloat(), (top + rowH).toFloat(), alt)
        }
        val codesLines = listOf(r.sap, r.ocp).filter { it.isNotBlank() && it != "—" }
            .ifEmpty { listOf("—") }
        val binLines = r.bin.split(',', '\n', ';').map { it.trim() }.filter { it.isNotEmpty() }
            .ifEmpty { listOf("—") }
        val desigLines = r.designation.chunked(26).take(3)
        val cellLines = listOf(
            codesLines,
            desigLines,
            listOf(r.qty),
            binLines,
            listOf(r.cons2025),
            listOf(r.cons2026)
        )
        x = pad.toFloat()
        cellLines.forEachIndexed { i, lines ->
            lines.take(4).forEachIndexed { li, line ->
                canvas.drawText(line, x + 8f, top + 32f + li * 28f, textPaint)
            }
            x += colW[i]
        }
        canvas.drawLine(0f, (top + rowH).toFloat(), width.toFloat(), (top + rowH).toFloat(), linePaint)
    }
    return bmp
}

private fun saveBitmapToGallery(context: Context, bitmap: Bitmap, fileName: String): Boolean {
    return try {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MobiStock")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return false
        context.contentResolver.openOutputStream(uri)?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        } ?: return false
        true
    } catch (_: Exception) {
        false
    }
}

@Composable
private fun MultiStockScreen(
    api: SupabaseClient,
    onBack: () -> Unit,
    onHome: () -> Unit
) {
    val c = LocalMobiColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    var input by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf<List<MultiStockRow>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tableExpanded by remember { mutableStateOf(false) }
    val hScroll = rememberScrollState()
    val hScrollFull = rememberScrollState()

    fun parseCodes(raw: String): List<String> {
        return raw
            .split('\n', '\r', ';', '\t', ',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { it.filter { ch -> ch.isDigit() || ch == '.' } }
            .filter { it.isNotEmpty() }
            .distinct()
    }

    fun filterCodeInput(raw: String): String {
        val out = StringBuilder()
        var lineHasDot = false
        for (ch in raw) {
            when {
                ch.isDigit() -> out.append(ch)
                ch == '.' -> {
                    if (!lineHasDot) {
                        out.append('.')
                        lineHasDot = true
                    }
                }
                ch == '\n' || ch == '\r' || ch == ';' || ch == '\t' || ch == ',' || ch == ' ' -> {
                    if (ch == '\n' || ch == '\r') {
                        out.append('\n')
                        lineHasDot = false
                    } else {
                        out.append('\n')
                        lineHasDot = false
                    }
                }
            }
        }
        return out.toString()
    }

    fun search() {
        val codes = parseCodes(input)
        if (codes.isEmpty()) {
            error = "Saisissez ou collez au moins un code."
            return
        }
        if (codes.size > 15) {
            error = "15 codes maximum (vous en avez ${codes.size})."
            return
        }
        keyboard?.hide()
        scope.launch {
            loading = true
            error = null
            rows = emptyList()
            runCatching { api.multiStockLookup(codes) }
                .onSuccess { rows = it }
                .onFailure { error = "Impossible de charger les données." }
            loading = false
        }
    }

    fun exportImage() {
        if (rows.isEmpty()) return
        scope.launch {
            val ok = withContext(Dispatchers.Default) {
                val bmp = multiStockTableToBitmap(rows)
                val name = "MobiStock_multi_${System.currentTimeMillis()}.png"
                saveBitmapToGallery(context, bmp, name)
            }
            Toast.makeText(
                context,
                if (ok) "Tableau enregistré dans Images/MobiStock" else "Échec de l'enregistrement",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    @Composable
    fun TableContent(
        data: List<MultiStockRow>,
        scroll: androidx.compose.foundation.ScrollState,
        large: Boolean
    ) {
        val cellPad = if (large) Modifier.padding(horizontal = 10.dp, vertical = 2.dp) else Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
        val fs = if (large) 14.sp else 11.sp
        val headerBg = Green.copy(alpha = 0.12f)
        fun colW(label: String) = when (label) {
            "Codes" -> if (large) 130.dp else 100.dp
            "Désignation" -> if (large) 220.dp else 150.dp
            "Qté" -> if (large) 64.dp else 52.dp
            "Bin" -> if (large) 200.dp else 150.dp
            "Cons 2025" -> if (large) 96.dp else 78.dp
            "Cons 2026" -> if (large) 96.dp else 78.dp
            else -> 80.dp
        }
        val headers = listOf("Codes", "Désignation", "Qté", "Bin", "Cons 2025", "Cons 2026")
        Column(Modifier.horizontalScroll(scroll)) {
            Row(Modifier.background(headerBg).padding(vertical = 2.dp)) {
                headers.forEach { h ->
                    Text(
                        h,
                        modifier = Modifier.width(colW(h)).then(cellPad),
                        fontWeight = FontWeight.Bold,
                        fontSize = fs,
                        color = GreenDark,
                        maxLines = 1,
                        lineHeight = fs
                    )
                }
            }
            HorizontalDivider(color = c.border)
            data.forEachIndexed { idx, r ->
                val codesText = listOf(r.sap, r.ocp).filter { it.isNotBlank() && it != "—" }.joinToString("\n").ifBlank { "—" }
                Row(
                    Modifier.background(if (idx % 2 == 0) c.cardSurface else c.surfaceBg),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(codesText, Modifier.width(colW("Codes")).then(cellPad), fontSize = fs, fontWeight = FontWeight.SemiBold, color = c.textPrimary, lineHeight = fs)
                    Text(r.designation, Modifier.width(colW("Désignation")).then(cellPad), fontSize = fs, color = c.textPrimary, maxLines = if (large) 4 else 2, overflow = TextOverflow.Ellipsis, lineHeight = fs)
                    Text(r.qty, Modifier.width(colW("Qté")).then(cellPad), fontSize = fs, fontWeight = FontWeight.Bold, color = if (r.qty == "0" || r.qty == "0.0") Color(0xFFDC2626) else c.textPrimary, maxLines = 1, lineHeight = fs)
                    Text(r.bin.replace(", ", "\u000A").replace(",", "\u000A"), Modifier.width(colW("Bin")).then(cellPad), fontSize = fs, color = c.textSecondary, maxLines = if (large) 8 else 4, overflow = TextOverflow.Ellipsis, lineHeight = fs)
                    Text(r.cons2025, Modifier.width(colW("Cons 2025")).then(cellPad), fontSize = fs, color = c.textPrimary, maxLines = 1, lineHeight = fs)
                    Text(r.cons2026, Modifier.width(colW("Cons 2026")).then(cellPad), fontSize = fs, color = c.textPrimary, maxLines = 1, lineHeight = fs)
                }
                HorizontalDivider(color = c.border.copy(alpha = 0.5f), thickness = 0.5.dp)
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = c.surfaceBg) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(HeaderGreen)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                }
                Text(
                    "Stock multiple",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                if (rows.isNotEmpty()) {
                    IconButton(onClick = { exportImage() }) {
                        Icon(Icons.Default.Download, "Enregistrer image", tint = Color.White)
                    }
                }
                IconButton(onClick = onHome) {
                    Icon(Icons.Default.Home, "Accueil", tint = Color.White)
                }
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Saisissez ou collez jusqu’à 15 codes SAP/OCP (un par ligne).",
                    fontSize = 12.sp,
                    color = c.textSecondary
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = filterCodeInput(it); error = null },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 100.dp, max = 140.dp),
                    placeholder = {
                        Text("Ex.\n80021545\n20492.31086", color = c.textMuted, fontSize = 13.sp)
                    },
                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, color = c.textPrimary),
                    singleLine = false,
                    // Entrée = ligne suivante ; loupe = recherche
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(
                        onSearch = { search() }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = c.border,
                        cursorColor = Green,
                        focusedTextColor = c.textPrimary,
                        unfocusedTextColor = c.textPrimary,
                        focusedContainerColor = c.cardSurface,
                        unfocusedContainerColor = c.cardSurface
                    )
                )
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { input = ""; rows = emptyList(); error = null },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Effacer", color = c.textSecondary)
                    }
                    Button(
                        onClick = { search() },
                        modifier = Modifier.weight(1f),
                        enabled = !loading,
                        colors = ButtonDefaults.buttonColors(containerColor = Green),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Text("Rechercher", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
                if (error != null) {
                    Text(error!!, color = Color(0xFFDC2626), fontSize = 13.sp)
                }
            }
            if (loading && rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Green)
                }
            } else if (rows.isNotEmpty()) {
                Text(
                    "${rows.size} article(s) — appuyez pour agrandir (paysage) · icône ↓ pour image",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = c.textSecondary
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(bottom = 72.dp)
                        .clickable { tableExpanded = true }
                ) {
                    TableContent(rows, hScroll, large = false)
                }
            }
        }
    }

    if (tableExpanded && rows.isNotEmpty()) {
        Dialog(
            onDismissRequest = { tableExpanded = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false
            )
        ) {
            // Affichage HORIZONTAL (rotation visuelle, sans recréer l'activité)
            Surface(
                Modifier.fillMaxSize(),
                color = c.surfaceBg,
                shape = RoundedCornerShape(0.dp)
            ) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val screenW = maxWidth
                    val screenH = maxHeight
                    // Contenu en paysage : largeur = hauteur écran, hauteur = largeur écran, rotation 90°
                    Box(
                        Modifier
                            .align(Alignment.Center)
                            .requiredWidth(screenH)
                            .requiredHeight(screenW)
                            .graphicsLayer {
                                rotationZ = 90f
                                transformOrigin = TransformOrigin.Center
                            }
                    ) {
                        Column(Modifier.fillMaxSize()) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .background(HeaderGreen)
                                    .padding(horizontal = 4.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Stock multiple — ${rows.size} article(s)",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f).padding(start = 8.dp)
                                )
                                IconButton(onClick = { exportImage() }) {
                                    Icon(Icons.Default.Download, "Image", tint = Color.White)
                                }
                                IconButton(onClick = { tableExpanded = false }) {
                                    Icon(Icons.Default.Close, "Fermer", tint = Color.White)
                                }
                            }
                            Box(Modifier.fillMaxSize().padding(4.dp)) {
                                TableContent(rows, hScrollFull, large = true)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNavigationBar(
    page: Int,
    onPage: (Int) -> Unit,
    catalogActive: Boolean = false,
    onCatalog: () -> Unit = {},
    messagesActive: Boolean = false,
    onMessages: () -> Unit = {},
    multiStockActive: Boolean = false,
    onMultiStock: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = LocalMobiColors.current.cardSurface,
        shadowElevation = 8.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavigationItem(
                icon = Icons.Default.Home,
                label = LocalAppStrings.current.home,
                active = page == 0 && !catalogActive && !messagesActive && !multiStockActive,
                onClick = { onPage(0) },
                modifier = Modifier.weight(1f)
            )
            NavigationItem(
                icon = Icons.Default.ViewList,
                label = "Stocks",
                active = multiStockActive,
                onClick = onMultiStock,
                modifier = Modifier.weight(1f)
            )
            NavigationItem(
                icon = Icons.Default.ShoppingCart,
                label = "Catalogue",
                active = catalogActive,
                onClick = onCatalog,
                modifier = Modifier.weight(1f)
            )
            NavigationItem(
                icon = Icons.Default.Email,
                label = "Messages",
                active = messagesActive,
                onClick = onMessages,
                modifier = Modifier.weight(1f)
            )
            NavigationItem(
                icon = Icons.Default.Settings,
                label = LocalAppStrings.current.settings,
                active = page == 1 && !catalogActive && !messagesActive && !multiStockActive,
                onClick = { onPage(1) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun NavigationItem(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val color = if (active) Green else LocalMobiColors.current.textMuted
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp)
    ) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(
            label,
            fontSize = 9.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = color,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Visible,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(2.dp))
        Box(
            Modifier
                .width(if (active) 22.dp else 0.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(if (active) Green else Color.Transparent)
        )
    }
}
