package com.ocp.consultationstocks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF25D366)
private val DarkGreen = Color(0xFF128C4A)
private val SoftGreen = Color(0xFFEAF9F0)
private val TextDark = Color(0xFF17231D)
private val Grey = Color(0xFF6F7A74)
private val LightGrey = Color(0xFFF4F6F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JorfTheme {
                JorfHome()
            }
        }
    }
}

@Composable
private fun JorfTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Color.White,
            surface = Color.White,
            onSurface = TextDark
        ),
        content = content
    )
}

@Composable
private fun JorfHome() {
    var selectedModule by remember { mutableStateOf("stock") }
    var search by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var searchError by remember { mutableStateOf<String?>(null) }

    fun validateSapOcp(value: String): Boolean {
        if (value.isEmpty()) return false
        if (value.length > 11) return false
        if (value.count { it == '.' } > 1) return false
        return value.all { it.isDigit() || it == '.' }
    }

    fun doSearch() {
        searchError = null
        resultMessage = null
        if (selectedModule == "organisation") {
            if (search.trim().isEmpty()) {
                searchError = "Saisissez un code ou une désignation."
                return
            }
            resultMessage = "Recherche Article d’organisation : ${search.trim()}"
            return
        }

        val value = search.trim()
        if (!validateSapOcp(value)) {
            searchError = "Code invalide : chiffres uniquement, un seul point maximum, 11 caractères maximum."
            return
        }
        resultMessage = if (selectedModule == "stock") {
            "Recherche Stock : $value"
        } else {
            "Recherche Mouvement matière : $value"
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = SoftGreen
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.Inventory2,
                            contentDescription = null,
                            tint = DarkGreen,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("JORF FERTILIZERS", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Text("COMPANY I", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Grey)
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("Tableau de bord", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardCard("Nombre d’articles", "—", Modifier.weight(1f))
                DashboardCard("Valeur de stock global", "— MAD", Modifier.weight(1f))
            }

            Spacer(Modifier.height(22.dp))

            Text("Modules", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ModuleButton("Synthèse des stocks", selectedModule == "stock", Modifier.weight(1f)) {
                    selectedModule = "stock"
                    search = ""
                    searchError = null
                    resultMessage = null
                }
                ModuleButton("Mouvement matière", selectedModule == "mouvement", Modifier.weight(1f)) {
                    selectedModule = "mouvement"
                    search = ""
                    searchError = null
                    resultMessage = null
                }
                ModuleButton("Article d’organisation", selectedModule == "organisation", Modifier.weight(1f)) {
                    selectedModule = "organisation"
                    search = ""
                    searchError = null
                    resultMessage = null
                }
            }

            Spacer(Modifier.height(22.dp))

            Text(
                when (selectedModule) {
                    "stock" -> "Synthèse des stocks"
                    "mouvement" -> "Mouvement matière"
                    else -> "Article d’organisation"
                },
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { input ->
                        if (selectedModule == "organisation") {
                            search = input
                            searchError = null
                            resultMessage = null
                        } else {
                            val filtered = input.filter { it.isDigit() || it == '.' }.take(11)
                            if (filtered.count { it == '.' } <= 1) {
                                search = filtered
                                searchError = null
                                resultMessage = null
                            }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    placeholder = {
                        Text(
                            if (selectedModule == "organisation") "Code ou désignation" else "Code SAP ou Code OCP",
                            color = Grey
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null)
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (selectedModule == "organisation") KeyboardType.Text else KeyboardType.Decimal
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = Color(0xFFD9E0DC)
                    )
                )

                Button(
                    onClick = { doSearch() },
                    modifier = Modifier.height(56.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null)
                }
            }

            if (selectedModule != "organisation") {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Chiffres uniquement • 1 point maximum • 11 caractères maximum",
                    fontSize = 11.sp,
                    color = Grey
                )
            }

            searchError?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Color(0xFFB3261E), fontSize = 12.sp)
            }

            resultMessage?.let {
                Spacer(Modifier.height(14.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftGreen)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Résultat de recherche", fontWeight = FontWeight.Bold, color = DarkGreen)
                        Spacer(Modifier.height(6.dp))
                        Text(it, color = TextDark, fontSize = 14.sp)
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            HorizontalDivider(color = Color(0xFFE5EAE7))
            Spacer(Modifier.height(12.dp))
            Text(
                "Word with love ♥",
                modifier = Modifier.fillMaxWidth(),
                color = Grey,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ModuleButton(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 6.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Green else LightGrey,
            contentColor = if (selected) Color.White else TextDark
        )
    ) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun DashboardCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(112.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = LightGrey),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                title,
                fontSize = 12.sp,
                color = Grey
            )
            Spacer(Modifier.height(7.dp))
            Text(
                value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
            )
        }
    }
}

@Composable
private fun SectionTitle(
    title: String,
    active: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            modifier = Modifier.weight(1f),
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) TextDark else Grey
        )

        if (!active) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = LightGrey
            ) {
                Row(
                    modifier = Modifier.padding(
                        horizontal = 10.dp,
                        vertical = 6.dp
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = Grey,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        "Bientôt",
                        fontSize = 11.sp,
                        color = Grey
                    )
                }
            }
        }
    }
}

@Composable
private fun DisabledModule(text: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = LightGrey
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Storage,
                contentDescription = null,
                tint = Color(0xFF9AA39E),
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text,
                color = Color(0xFF9AA39E),
                fontSize = 14.sp
            )
        }
    }
}
