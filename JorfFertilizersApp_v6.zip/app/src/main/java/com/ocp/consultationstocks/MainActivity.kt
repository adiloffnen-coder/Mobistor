package com.ocp.consultationstocks

import android.os.Bundle
import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF0B9F55)
private val GreenDark = Color(0xFF075B43)
private val GreenSoft = Color(0xFFEAF8F1)
private val Blue = Color(0xFF138CE5)
private val BlueSoft = Color(0xFFEAF5FE)
private val Purple = Color(0xFF7A35C8)
private val PurpleSoft = Color(0xFFF4EEFF)
private val Navy = Color(0xFF12395F)
private val TextDark = Color(0xFF073E32)
private val Grey = Color(0xFF536B78)
private val Border = Color(0xFFD5E5E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(8, 111, 72)
        setContent { JorfTheme { JorfHome() } }
    }
}

@Composable
private fun JorfTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Color.White,
            surface = Color.White,
            onSurface = TextDark
        ),
        content = content
    )
}

@Composable
private fun JorfHome() {
    var stockSearch by remember { mutableStateOf("") }
    var movementSearch by remember { mutableStateOf("") }
    var organisationSearch by remember { mutableStateOf("") }
    var errorPopup by remember { mutableStateOf<String?>(null) }
    var resultPopup by remember { mutableStateOf<String?>(null) }

    fun filterCode(input: String): String {
        val filtered = input.filter { it.isDigit() || it == '.' }.take(11)
        return if (filtered.count { it == '.' } <= 1) filtered else filtered.dropLast(1)
    }

    fun validateCode(value: String): String? {
        val v = value.trim()
        return when {
            v.isEmpty() -> "Veuillez saisir un code SAP ou un code OCP."
            v.length > 11 -> "Le code ne doit pas dépasser 11 caractères."
            v.count { it == '.' } > 1 -> "Un seul point (.) est autorisé."
            !v.all { it.isDigit() || it == '.' } -> "Le code doit être numérique."
            else -> null
        }
    }

    fun searchCode(value: String, movement: Boolean) {
        val error = validateCode(value)
        if (error != null) {
            errorPopup = error
            return
        }
        resultPopup = if (movement) {
            "Recherche mouvement matière : ${value.trim()}"
        } else {
            "Recherche stock : ${value.trim()}"
        }
    }


    Surface(Modifier.fillMaxSize(), color = Color.White) {
        Column(Modifier.fillMaxSize()) {
            Header()

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Spacer(Modifier.height(4.dp))
                WelcomeBanner()
                Spacer(Modifier.height(7.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    SummaryCard(
                        title = "Nombre d’articles",
                        value = "—",
                        subtitle = "Articles en stock",
                        accent = Green,
                        icon = Icons.Default.Inventory2,
                        modifier = Modifier.weight(1f)
                    )
                    SummaryCard(
                        title = "Valeur de stock global",
                        value = "—",
                        subtitle = "MAD",
                        accent = Blue,
                        icon = Icons.Default.Storage,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(7.dp))

                SearchModule(
                    title = "Synthèse des stocks",
                    icon = Icons.Default.Inventory2,
                    accent = Green,
                    background = GreenSoft,
                    value = stockSearch,
                    onValueChange = { stockSearch = filterCode(it) },
                    onSearch = { searchCode(stockSearch, false) }
                )

                Spacer(Modifier.height(6.dp))

                SearchModule(
                    title = "Mouvement matière",
                    icon = Icons.Default.SwapHoriz,
                    accent = Blue,
                    background = BlueSoft,
                    value = movementSearch,
                    onValueChange = { movementSearch = filterCode(it) },
                    onSearch = { searchCode(movementSearch, true) }
                )

                Spacer(Modifier.height(6.dp))

                SearchModule(
                    title = "Article d’organisation",
                    icon = Icons.Default.Business,
                    accent = Purple,
                    background = PurpleSoft,
                    value = organisationSearch,
                    onValueChange = { organisationSearch = it },
                    onSearch = {
                        if (organisationSearch.trim().isEmpty()) {
                            errorPopup = "Veuillez saisir un code ou une désignation."
                        } else {
                            resultPopup = "Recherche article d’organisation : ${organisationSearch.trim()}"
                        }
                    },
                    organisation = true
                )

                Spacer(Modifier.height(4.dp))
                Text(
                    "Word with love ♥",
                    Modifier.fillMaxWidth(),
                    color = GreenDark,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(3.dp))
            }

            BottomNavigationBar()
        }

        errorPopup?.let { message ->
            AlertDialog(
                onDismissRequest = { errorPopup = null },
                title = { Text("Saisie invalide") },
                text = { Text(message) },
                confirmButton = {
                    TextButton(onClick = { errorPopup = null }) { Text("OK") }
                }
            )
        }

        resultPopup?.let { message ->
            AlertDialog(
                onDismissRequest = { resultPopup = null },
                title = { Text("Recherche") },
                text = { Text(message) },
                confirmButton = {
                    TextButton(onClick = { resultPopup = null }) { Text("OK") }
                }
            )
        }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(23.dp))
                .background(GreenSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Eco, null, tint = Green, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("JORF FERTILIZERS COMPANY I", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("MobiStock", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("Gestion des stocks & mouvements", fontSize = 11.sp, color = Grey)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = GreenDark) }
        IconButton(onClick = {}) { Icon(Icons.Default.Menu, null, tint = GreenDark) }
    }
}

@Composable
private fun WelcomeBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(88.dp)
            .clip(RoundedCornerShape(0.dp, 0.dp, 22.dp, 22.dp))
            .background(
                Brush.horizontalGradient(listOf(Color(0xFFF0FBF7), Color(0xFFDDF3EA), Color(0xFFCDEBDD)))
            )
    ) {
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .size(210.dp)
                .clip(RoundedCornerShape(90.dp, 0.dp, 0.dp, 90.dp))
                .background(Color(0x220B9F55))
        )
        Column(Modifier.padding(start = 16.dp, top = 10.dp, end = 135.dp)) {
            Text("Bonjour,", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Text("Bienvenue sur MobiStock", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(Modifier.height(2.dp))
            Text("Consultez et gérez vos stocks et mouvements en temps réel.", fontSize = 8.sp, color = Grey)
        }
        Icon(
            Icons.Default.Business,
            null,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp).size(58.dp),
            tint = Color(0x6675A98A)
        )
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier
) {
    Card(
        modifier = modifier.height(92.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .25f)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.fillMaxSize().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(21.dp)).background(accent),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(23.dp)) }
            Spacer(Modifier.width(7.dp))
            Column {
                Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(2.dp))
                Text(value, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Text(subtitle, fontSize = 9.sp, color = Grey)
            }
        }
    }
}

@Composable
private fun SearchModule(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    background: Color,
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    organisation: Boolean = false
) {
    Card(
        Modifier.fillMaxWidth().height(104.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = background),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .25f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).clip(RoundedCornerShape(19.dp)).background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = Color.White, modifier = Modifier.size(21.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = accent, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ArrowForwardIos, null, tint = accent, modifier = Modifier.size(15.dp))
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f).height(44.dp),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    placeholder = { Text(if (organisation) "Code article ou Désignation" else "Code SAP ou Code OCP", color = Grey, fontSize = 11.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Grey) },
                    keyboardOptions = KeyboardOptions(keyboardType = if (organisation) KeyboardType.Text else KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
                Button(
                    onClick = onSearch,
                    modifier = Modifier.width(132.dp).height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(Icons.Default.Search, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Rechercher", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


@Composable
private fun BottomNavigationBar() {
    Surface(Modifier.fillMaxWidth(), color = Color.White, shadowElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceAround) {
            NavigationItem(Icons.Default.Home, "Accueil", true, Green)
            NavigationItem(Icons.Default.Settings, "Paramètres", false, Grey)
        }
    }
}

@Composable
private fun NavigationItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(110.dp)) {
        Icon(icon, null, tint = color, modifier = Modifier.size(23.dp))
        Text(label, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, color = color)
        if (active) Spacer(Modifier.height(3.dp))
        if (active) Box(Modifier.width(90.dp).height(2.dp).clip(RoundedCornerShape(2.dp)).background(color))
    }
}
